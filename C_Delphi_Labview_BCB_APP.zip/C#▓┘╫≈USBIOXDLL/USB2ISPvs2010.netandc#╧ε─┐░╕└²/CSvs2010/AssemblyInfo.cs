using System.Diagnostics;
using System;
using System.Windows.Forms;
using System.Collections;
using System.Drawing;
using Microsoft.VisualBasic;
using System.Data;
using Microsoft.VisualBasic.Compatibility;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.


// TODO: Review the values of the assembly attributes


[assembly:AssemblyTitle("USB2I2C DEMO")]
[assembly:AssemblyDescription("")]
[assembly:AssemblyCompany("USBIO Tech.")]
[assembly:AssemblyProduct("USB2I2C DEMO")]
[assembly:AssemblyCopyright("USBIO TECH. ALL COPYRIGHT")]
[assembly:AssemblyTrademark("WWW.USB-I2C-SPI.COM")]
[assembly:AssemblyCulture("")]

// Version information for an assembly consists of the following four values:

//	Major version
//	Minor Version
//	Build Number
//	Revision

// You can specify all the values or you can default the Build and Revision Numbers
// by using the '*' as shown below:

[assembly:AssemblyVersion("1.2.*")]



