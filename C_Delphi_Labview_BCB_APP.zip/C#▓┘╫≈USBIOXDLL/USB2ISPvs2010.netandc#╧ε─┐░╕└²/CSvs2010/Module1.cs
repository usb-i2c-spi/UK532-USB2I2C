using System.Diagnostics;
using System;
using System.Windows.Forms;
using System.Collections;
using System.Drawing;
using Microsoft.VisualBasic;
using System.Data;
using Microsoft.VisualBasic.Compatibility;
using System.Runtime.InteropServices;

//update : 20100528 from vb6 to 2008
namespace USB2ISP
{
	sealed class Module1
	{
		
		public struct arrRBuffer
		{
			[VBFixedArray(USBIOXDLL.mMAX_BUFFER_LENGTH - 1)]public byte[] buf;
			
			//UPGRADE_TODO: "Initialize" must be called to initialize instances of this structure. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="B4BFF9E0-8631-45CF-910E-62AB3970F27B"'
			public void Initialize()
			{
				buf = new byte[USBIOXDLL.mMAX_BUFFER_LENGTH - 1 + 1];
			}
		}
		
		public const int WM_KEYUP = 0x101;
		public const int BN_CLICK = 0x101;
		public static USBIOXDLL.EEPROM_TYPE eepromid; //eeprom型号
		[DllImport("user32",EntryPoint="PostMessageA", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern int PostMessage(int hwnd, int wMsg, int wParam, int lParam);
		
		public static int mIndex;
		public static bool mOpen;
		
		
		public static byte mCharToBcd(string iChar) // 输入的ASCII字符
		{
			byte returnValue;
			byte mBCD;
			if ((String.Compare(iChar, "0") >= 0) && (String.Compare(iChar, "9") <= 0) )
			{
				mBCD =  (byte) ((double.Parse(iChar)) - double.Parse("0"));
			}
			else if ((String.Compare(iChar, "A") >= 0) && (String.Compare(iChar, "F") <= 0) )
			{
				mBCD =  (byte) (Strings.Asc(iChar) - Strings.Asc("A") + 0xA);
			}
			else if ((String.Compare(iChar, "a") >= 0) && (String.Compare(iChar, "f") <= 0) )
			{
				mBCD =  (byte) (Strings.Asc(iChar) - Strings.Asc("a") + 0xA);
			}
			else
			{
				mBCD = 0xFF;
			}
			returnValue = mBCD;
			return returnValue;
		}
		
		//UPGRADE_NOTE: str was upgraded to str_Renamed. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
		static public void mStrtoVal(string str_Renamed, ref byte[] strOut, int strleng)
		{
			int i;
			int j;
			int mLen;
			byte[] strRev = new byte[USBIOXDLL.mMAX_BUFFER_LENGTH - 1 + 1];
			mLen = strleng * 2;
			j = 0;
			for (i = 0; i <= mLen - 1; i += 2)
			{
				//UPGRADE_WARNING: Couldn't resolve default property of object i. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				if (mCharToBcd(str_Renamed.Substring(i + 1 - 1, 1)) == 0xFF || mCharToBcd(str_Renamed.Substring(i + 2 - 1, 1)) == 0xFF)
				{
					goto con;
				}
				//   strRev(j) = mCharToBcd(Mid(str, i + 1, 1)) * 16 + mCharToBcd(Mid(str, i + 2, 1))
				//UPGRADE_WARNING: Couldn't resolve default property of object i. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				strRev[j] =  (byte) (mCharToBcd(str_Renamed.Substring(i + 1 - 1, 1)) * 16 + mCharToBcd(str_Renamed.Substring(i + 2 - 1, 1)));
				Debug.Print(Conversion.Hex(strRev[j]));
				j++;
con:
				1.GetHashCode() ; //VBConversions note: C# requires an executable line here, so a dummy line was added.
			}
			j = 0;
			while (j < strleng)
			{
				strOut[j] = strRev[j];
				j++;
			}
		}
		
		static public string Hex2bit(byte var)
		{
			string returnValue;
			if (var < 16)
			{
				returnValue = "0" + Conversion.Hex(var);
			}
			else
			{
				returnValue = Conversion.Hex(var);
			}
			return returnValue;
		}
		//UPGRADE_NOTE: str was upgraded to str_Renamed. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
		static public int HexToBcd(ref string str_Renamed) //将文本框中输入的十六进制值转换成BCD码
		{
			int returnValue = 0;
			short Length;
			string X;
			int i;
			str_Renamed = str_Renamed.Trim();
			Length = (short) str_Renamed.Length;
			for (i = 0; i <= Length - 1; i++)
			{
				X = str_Renamed.Substring(Length - i - 1, 1);
				if ((X == "a") || (X == "A"))
				{
					returnValue =  (int) (returnValue + 10 * (Math.Pow(16, i)));
				}
				else if ((X == "b") || (X == "B"))
				{
					returnValue =  (int) (returnValue + 11 * (Math.Pow(16, i)));
				}
				else if ((X == "c") || (X == "C"))
				{
					returnValue =  (int) (returnValue + 12 * (Math.Pow(16, i)));
				}
				else if ((X == "d") || (X == "D"))
				{
					returnValue =  (int) (returnValue + 13 * (Math.Pow(16, i)));
				}
				else if ((X == "e") || (X == "E"))
				{
					returnValue =  (int) (returnValue + 14 * (Math.Pow(16, i)));
				}
				else if ((X == "f") || (X == "F"))
				{
					returnValue =  (int) (returnValue + 15 * (Math.Pow(16, i)));
				}
				else if ((String.Compare(X, "0") >= 0) && (String.Compare(X, "9") <= 0) )
				{
					returnValue =  (int) (returnValue + Conversion.Val(X) * Math.Pow(16, i));
				}
				else
				{
					//MsgBox "非十六进制数", vbCritical, "信息提示"
					returnValue = int.Parse("0");
				}
			}
			return returnValue;
		}
		static public int mUSBIO_NOTIFY_ROUTINE(int iEventStatus)
		{
			PostMessage(frmMain.Default.USBIO_NOTIFY_ROUTINE.Handle.ToInt32(), System.Convert.ToInt32(WM_KEYUP), iEventStatus, 0); //将接收到的插拔事件值发到插拔处理程序中
			return 0;
		}
	}
}
