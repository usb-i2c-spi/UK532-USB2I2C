using System.Diagnostics;
using System;
using System.Windows.Forms;
using System.Collections;
using System.Drawing;
using Microsoft.VisualBasic;
using System.Data;
using Microsoft.VisualBasic.Compatibility;

namespace USB2ISP
{
	partial class frmMain : System.Windows.Forms.Form
	{
		
#region Default Instance
		
		private static frmMain defaultInstance;
		
		/// <summary>
		/// Added by the VB.Net to C# Converter to support default instance behavour in C#
		/// </summary>
		public static frmMain Default
		{
			get
			{
				if (defaultInstance == null)
				{
					defaultInstance = new frmMain();
					defaultInstance.FormClosed += new FormClosedEventHandler(defaultInstance_FormClosed);
				}
				
				return defaultInstance;
			}
		}
		
		static void defaultInstance_FormClosed(object sender, FormClosedEventArgs e)
		{
			defaultInstance = null;
		}
		
#endregion
		[STAThread]
		static void Main()
		{
			System.Windows.Forms.Application.Run(new frmMain());
		}
		
		int hopen;
		
		
		public void eepromRdDate_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			int mDataAddr;
			int mLen;
			//UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
			byte[] buffer = new byte[USBIOXDLL.mMAX_BUFFER_LENGTH - 1 + 1];
			System.String temp_SystemString = RdDataLen.Text;
			mLen = Module1.HexToBcd(ref temp_SystemString);
			
			if (RdDataAddr.Text == "")
			{
				Interaction.MsgBox("请输入数据单元起始地址！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				return;
			}
			if (mLen <= 0)
			{
				Interaction.MsgBox("请输入读取长度！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				return;
			}
			System.String temp_SystemString2 = RdDataAddr.Text;
			mDataAddr = Module1.HexToBcd(ref temp_SystemString2);
			string buff = "";
			int i;
			if (Module1.mOpen == true)
			{
				//UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				if (USBIOXDLL.USBIO_ReadEEPROM(Module1.mIndex, Module1.eepromid, mDataAddr, mLen, buffer))
				{
					for (i = 0; i <= mLen - 1; i++)
					{
						buff = buff + Module1.Hex2bit(buffer[i]) + " ";
					}
					RdDataBuf.Text = buff;
				}
				else
				{
					Interaction.MsgBox("读E2PROM数据失败！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				}
				RdDataLen.Text = Conversion.Hex((short) mLen);
			}
			else
			{
				Interaction.MsgBox("设备未打开！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
			}
		}
		
		public void eepromWrDate_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			byte mData;
			int mDataAddr;
			int mLen;
			//UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
			byte[] buffer = new byte[USBIOXDLL.mMAX_BUFFER_LENGTH - 1 + 1];
			
			System.String temp_SystemString = WrDataLen.Text;
			mLen = Module1.HexToBcd(ref temp_SystemString);
			if (WrDataAddr.Text == "")
			{
				Interaction.MsgBox("请输入数据单元起始地址！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				return;
			}
			if (mLen <= 0 || WrDataBuf.Text == "")
			{
				Interaction.MsgBox("请输入要写入的数据,长度！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				return;
			}
			
			if (mLen > (WrDataBuf.Text.Length / 2)) //在输入长度和数据长度中取小值
			{
				mLen = System.Convert.ToInt32(WrDataBuf.Text.Length / 2);
			}
			
			System.String temp_SystemString2 = WrDataAddr.Text;
			mDataAddr = Module1.HexToBcd(ref temp_SystemString2);
			Module1.mStrtoVal((string) (WrDataBuf.Text), ref buffer, mLen); //将输入的十六进制格式字符数据转成数值数据
			
			if (Module1.mOpen == true)
			{
				//UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				if (USBIOXDLL.USBIO_WriteEEPROM(Module1.mIndex, Module1.eepromid, mDataAddr, mLen, buffer) == false)
				{
					Interaction.MsgBox("读E2PROM数据失败！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				}
				WrDataLen.Text = Conversion.Hex((short) mLen);
			}
			else
			{
				Interaction.MsgBox("设备未打开！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
			}
		}
		
		public void eppRead0_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			int mLen;
			//UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
			byte[] buffer = new byte[USBIOXDLL.mMAX_BUFFER_LENGTH - 1 + 1];
			
			System.String temp_SystemString = eppLen0.Text;
			mLen = Module1.HexToBcd(ref temp_SystemString);
			if (mLen <= 0)
			{
				Interaction.MsgBox("请输入读取长度", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				return;
			}
			string buff;
			int i;
			if (Module1.mOpen == true)
			{
				//UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				if (USBIOXDLL.USBIO_EppReadData(Module1.mIndex, ref buffer, ref mLen))
				{
					buff = "";
					for (i = 0; i <= mLen - 1; i++)
					{
						buff = buff + Module1.Hex2bit(buffer[i]) + " ";
					}
					eppData0.Text = buff;
				}
				else
				{
					Interaction.MsgBox("EPP方式读数据失败！ ", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				}
				eppLen0.Text = Conversion.Hex((short) mLen);
			}
			else
			{
				Interaction.MsgBox("设备未打开！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
			}
		}
		
		public void eppRead1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			int mLen;
			//UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
			//Dim buffer As arrRBuffer
			byte[] buffer = new byte[USBIOXDLL.mMAX_BUFFER_LENGTH - 1 + 1];
			
			System.String temp_SystemString = eppLen1.Text;
			mLen = Module1.HexToBcd(ref temp_SystemString);
			if (mLen <= 0)
			{
				Interaction.MsgBox("请输入读取数据的长度", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				return;
			}
			string buff = "";
			object i;
			int j;
			if (Module1.mOpen == true)
			{
				//UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				if (USBIOXDLL.USBIO_EppReadAddr(Module1.mIndex, ref buffer, ref mLen))
				{
					j = 0;
					for (i = 0; System.Convert.ToInt32(i) <= mLen - 1 ; i = System.Convert.ToInt32(i) + 1 )
					{
						//UPGRADE_WARNING: Couldn't resolve default property of object i. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
						buff = buff + Module1.Hex2bit(buffer[ (int) (i)]) + " ";
					}
					eppData1.Text = buff;
				}
				else
				{
					Interaction.MsgBox("EPP读数据块1失败！ ", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				}
				eppLen1.Text = Conversion.Hex((short) mLen);
			}
			else
			{
				Interaction.MsgBox("设备未打开！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
			}
		}
		
		//UPGRADE_WARNING: Event eppromtype.CheckedChanged may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"'
		public void eppromtype_CheckedChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			if (eventSender.Checked) // VBConversions Warning: 'Checked' is late bound, which isn't supported in C#.  Change the object variable to a specific type which implements 'Checked' and convert again.
			{
				short Index = eppromtype.GetIndex((RadioButton) eventSender);
				switch (Index)
				{
					case 0:
						Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C01;
						break;
					case 1:
						Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C02;
						break;
					case 2:
						Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C04;
						break;
					case 3:
						Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C08;
						break;
					case 4:
						Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C16;
						break;
					case 5:
						Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C32;
						break;
					case 6:
						Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C64;
						break;
					case 7:
						Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C128;
						break;
					case 8:
						Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C256;
						break;
					case 9:
						Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C512;
						break;
					case 10:
						Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C1024;
						break;
					case 11:
						Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C2048;
						break;
					case 12:
						Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C4096;
						break;
				}
			}
		}
		
		public void eppWrite0_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			int mLen;
			//UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
			byte[] buffer = new byte[USBIOXDLL.mMAX_BUFFER_LENGTH - 1 + 1];
			
			System.String temp_SystemString = eppLen0.Text;
			mLen = Module1.HexToBcd(ref temp_SystemString);
			if (mLen <= 0 || eppData0.Text.Length == 0)
			{
				Interaction.MsgBox("请输入要写的数据,长度！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				return;
			}
			if (mLen > eppData0.Text.Length / 2)
			{
				mLen = System.Convert.ToInt32(eppData0.Text.Length / 2);
			}
			Module1.mStrtoVal((string) (eppData0.Text), ref buffer, mLen); //将输入的十六进制格式字符数据转成数值数据
			
			if (Module1.mOpen == true)
			{
				//UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				if (USBIOXDLL.USBIO_EppWriteData(Module1.mIndex, buffer, ref mLen) == false)
				{
					Interaction.MsgBox("EPP写数据块0失败！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				}
				eppLen0.Text = Conversion.Hex((short) mLen);
			}
			else
			{
				Interaction.MsgBox("设备未打开！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
			}
		}
		
		public void eppWrite1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			int mLen;
			//UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
			byte[] buffer = new byte[USBIOXDLL.mMAX_BUFFER_LENGTH - 1 + 1];
			
			System.String temp_SystemString = eppLen1.Text;
			mLen = Module1.HexToBcd(ref temp_SystemString);
			
			if (mLen <= 0 || eppData1.Text.Length == 0)
			{
				Interaction.MsgBox("请输入写数据和长度！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				return;
			}
			
			if (mLen > eppData1.Text.Length / 2)
			{
				mLen = System.Convert.ToInt32(eppData1.Text.Length / 2);
			}
			
			Module1.mStrtoVal((string) (eppData1.Text), ref buffer, mLen); //将输入的十六进制格式字符数据转成数值数据
			if (Module1.mOpen == true)
			{
				//UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				object temp_object = buffer;
				if (USBIOXDLL.USBIO_EppWriteAddr(Module1.mIndex, ref temp_object, ref mLen) == false)
				{
					Interaction.MsgBox("EPP写数据块1失败！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				}
				eppLen1.Text = Conversion.Hex((short) mLen);
			}
			else
			{
				Interaction.MsgBox("设备未打开！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
			}
		}
		
		public void evtbtrefresh_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			byte[] mBuf = new byte[1];
			int mLen;
			
			if (Module1.mOpen == true)
			{
				mLen = 1;
				if (memadd0[0].Checked == true)
				{
					if (USBIOXDLL.USBIO_MemReadAddr0(Module1.mIndex, mBuf, ref mLen) == false)
					{
						Interaction.MsgBox("MEM地址方式读拔码开关状态失败！ ", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
						return;
					}
				}
				else if (memadd1[1].Checked == true)
				{
					if (USBIOXDLL.USBIO_MemReadAddr1(Module1.mIndex, mBuf, ref mLen) == false)
					{
						Interaction.MsgBox("MEM地址方式1读拔码开关状态失败！ ", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
						return;
					}
				}
				//按钮状态显示
				if ((mBuf[0] & 1) == 0)
				{
					swit[0].CheckState = System.Windows.Forms.CheckState.Checked;
				}
				else
				{
					swit[0].CheckState = System.Windows.Forms.CheckState.Unchecked;
				}
				if ((mBuf[0] & 2) == 0)
				{
					swit[1].CheckState = System.Windows.Forms.CheckState.Checked;
				}
				else
				{
					swit[1].CheckState = System.Windows.Forms.CheckState.Unchecked;
				}
				if ((mBuf[0] & 4) == 0)
				{
					swit[2].CheckState = System.Windows.Forms.CheckState.Checked;
				}
				else
				{
					swit[2].CheckState = System.Windows.Forms.CheckState.Unchecked;
				}
				if ((mBuf[0] & 8) == 0)
				{
					swit[3].CheckState = System.Windows.Forms.CheckState.Checked;
				}
				else
				{
					swit[3].CheckState = System.Windows.Forms.CheckState.Unchecked;
				}
				if ((mBuf[0] & 16) == 0)
				{
					swit[4].CheckState = System.Windows.Forms.CheckState.Checked;
				}
				else
				{
					swit[4].CheckState = System.Windows.Forms.CheckState.Unchecked;
				}
				if ((mBuf[0] & 32) == 0)
				{
					swit[5].CheckState = System.Windows.Forms.CheckState.Checked;
				}
				else
				{
					swit[5].CheckState = System.Windows.Forms.CheckState.Unchecked;
				}
				if ((mBuf[0] & 64) == 0)
				{
					swit[6].CheckState = System.Windows.Forms.CheckState.Checked;
				}
				else
				{
					swit[6].CheckState = System.Windows.Forms.CheckState.Unchecked;
				}
				if ((mBuf[0] & 128) == 0)
				{
					swit[7].CheckState = System.Windows.Forms.CheckState.Checked;
				}
				else
				{
					swit[7].CheckState = System.Windows.Forms.CheckState.Unchecked;
				}
			}
			else
			{
				Interaction.MsgBox("设备未打开！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
			}
		}
		
		public void frmMain_Load(System.Object eventSender, System.EventArgs eventArgs)
		{
			Module1.mIndex = 0;
			//SSTab1.TabVisible(0) = False
			//SSTab1.TabVisible(1) = False
			//SSTab1.TabVisible(2) = False
			//SSTab1.TabVisible(3) = False
			//SSTab1.TabVisible(1) = False
			//SSTab1.TabVisible(4) = False
			hopen = System.Convert.ToInt32(USBIOXDLL.USBIO_OpenDevice(Module1.mIndex));
			if (hopen == USBIOXDLL.INVALID_HANDLE_VALUE)
			{
				Module1.mOpen = false;
			}
			else
			{
				Module1.mOpen = true;
			}
			//设置设备插拔通知
			//UPGRADE_WARNING: Add a delegate for AddressOf mUSBIO_NOTIFY_ROUTINE Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="E9E157F7-EF0C-4016-87B7-7D7FBBC6EE08"'
			if (USBIOXDLL.USBIO_SetDeviceNotify(Module1.mIndex, ref Constants.vbNullString, new DelegateCallBack(Module1.mUSBIO_NOTIFY_ROUTINE)) == false)
			{
				Interaction.MsgBox("设置设备插拔通知失败", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
			}
			enablebtn(System.Convert.ToBoolean(Module1.mOpen));
		}
		
		public void frmMain_FormClosed(System.Object eventSender, System.Windows.Forms.FormClosedEventArgs eventArgs)
		{
			object temp_object = Constants.vbNullString;
			string temp_string =  (string) (temp_object);
			USBIOXDLL.USBIO_SetDeviceNotify(Module1.mIndex, ref temp_string, null);
			if (Module1.mOpen == true)
			{
				USBIOXDLL.USBIO_CloseDevice(System.Convert.ToInt32(Module1.mIndex));
				
			}
		}
		
		
		
		
		//UPGRADE_WARNING: Event Led.CheckStateChanged may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"'
		public void Led_CheckStateChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			short Index = Led.GetIndex((CheckBox) eventSender);
			byte[] mBuf = new byte[1];
			int mLen;
			if (Module1.mOpen == true)
			{
				mLen = 1;
				mBuf[0] = System.Convert.ToByte((System.Convert.ToInt32(Led[0].CheckState) * System.Convert.ToInt32((System.Windows.Forms.CheckState) (Math.Pow(2, 7)))) + (System.Convert.ToInt32(Led[1].CheckState) * System.Convert.ToInt32((System.Windows.Forms.CheckState) (Math.Pow(2, 6)))) + (System.Convert.ToInt32(Led[2].CheckState) * System.Convert.ToInt32((System.Windows.Forms.CheckState) (Math.Pow(2, 5)))) + (System.Convert.ToInt32(Led[3].CheckState) * System.Convert.ToInt32((System.Windows.Forms.CheckState) (Math.Pow(2, 4)))) + (System.Convert.ToInt32(Led[4].CheckState) * System.Convert.ToInt32((System.Windows.Forms.CheckState) (Math.Pow(2, 3)))) + (System.Convert.ToInt32(Led[5].CheckState) * System.Convert.ToInt32((System.Windows.Forms.CheckState) (Math.Pow(2, 2)))) + (System.Convert.ToInt32(Led[6].CheckState) * System.Convert.ToInt32((System.Windows.Forms.CheckState) (Math.Pow(2, 1)))) + (System.Convert.ToInt32(Led[7].CheckState) * System.Convert.ToInt32((System.Windows.Forms.CheckState) (Math.Pow(2, 0))))); //组合按钮键值
				if (memadd0[0].Checked == true) //地址0
				{
					if (USBIOXDLL.USBIO_MemWriteAddr0(Module1.mIndex, mBuf, ref mLen) == false)
					{
						Interaction.MsgBox("发送LED状态值失败！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
					}
				}
				else if (memadd1[1].Checked == true)
				{
					if (USBIOXDLL.USBIO_MemWriteAddr1(Module1.mIndex, mBuf, ref mLen) == false)
					{
						Interaction.MsgBox("发送LED状态值失败！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
					}
				}
			}
			else
			{
				Interaction.MsgBox("设备未打开！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
			}
		}
		
		
		public void memRead0_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			int mLen;
			//UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
			byte[] buffer = new byte[USBIOXDLL.mMAX_BUFFER_LENGTH - 1 + 1];
			
			System.String temp_SystemString = memLen0.Text;
			mLen = Module1.HexToBcd(ref temp_SystemString);
			
			if (mLen <= 0)
			{
				Interaction.MsgBox("请输入读取长度", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				return;
			}
			
			string buff;
			int i;
			if (Module1.mOpen == true)
			{
				//On Error Resume Next VBConversions Warning: On Error Resume Next not supported in C#
				//UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				if (USBIOXDLL.USBIO_MemReadAddr0(Module1.mIndex, buffer, ref mLen))
				{
					buff = "";
					for (i = 0; i <= mLen - 1; i++)
					{
						System.Windows.Forms.Application.DoEvents();
						buff = buff + Module1.Hex2bit(buffer[i]) + " ";
					}
					memData0.Text = buff;
				}
				else
				{
					Interaction.MsgBox("MEM读数据块0失败！ ", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				}
				memLen0.Text = Conversion.Hex((short) mLen);
			}
			else
			{
				Interaction.MsgBox("设备未打开！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
			}
		}
		
		public void memRead1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			int mLen;
			//UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
			byte[] buffer = new byte[USBIOXDLL.mMAX_BUFFER_LENGTH - 1 + 1];
			
			System.String temp_SystemString = memLen1.Text;
			mLen = Module1.HexToBcd(ref temp_SystemString);
			if (mLen <= 0)
			{
				Interaction.MsgBox("请输入读数据长度", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				return;
			}
			
			string buff = "";
			int i;
			if (Module1.mOpen == true)
			{
				//UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				if (USBIOXDLL.USBIO_MemReadAddr1(Module1.mIndex, buffer, ref mLen))
				{
					for (i = 0; i <= mLen - 1; i++)
					{
						buff = buff + Module1.Hex2bit(buffer[i]) + " ";
					}
					memData1.Text = buff;
				}
				else
				{
					Interaction.MsgBox("MEM读数据块1失败！ ", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				}
				memLen1.Text = Conversion.Hex((short) mLen);
			}
			else
			{
				Interaction.MsgBox("设备未打开！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
			}
		}
		
		public void memWrite0_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			int mLen;
			//UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
			byte[] buffer = new byte[USBIOXDLL.mMAX_BUFFER_LENGTH - 1 + 1];
			
			System.String temp_SystemString = memLen0.Text;
			mLen = Module1.HexToBcd(ref temp_SystemString);
			
			if (mLen <= 0 || memData0.Text.Length == 0)
			{
				Interaction.MsgBox("请输入要写的数据,长度！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				return;
			}
			
			if (mLen > memData0.Text.Length / 2)
			{
				mLen = System.Convert.ToInt32(memData0.Text.Length / 2);
			}
			
			Module1.mStrtoVal((string) (memData0.Text), ref buffer, mLen); //将输入的十六进制格式字符数据转成数值数据
			if (Module1.mOpen == true)
			{
				//UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				if (USBIOXDLL.USBIO_MemWriteAddr0(Module1.mIndex, buffer, ref mLen) == false)
				{
					Interaction.MsgBox("MEM写数据块0失败！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				}
				memLen0.Text = Conversion.Hex((short) mLen);
			}
			else
			{
				Interaction.MsgBox("设备未打开！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
			}
		}
		
		public void memWrite1_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			int mLen;
			//UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
			byte[] buffer = new byte[USBIOXDLL.mMAX_BUFFER_LENGTH - 1 + 1];
			
			System.String temp_SystemString = memLen1.Text;
			mLen = Module1.HexToBcd(ref temp_SystemString);
			
			if (mLen <= 0 || memData1.Text.Length == 0)
			{
				Interaction.MsgBox("请输入要写入的数据,长度！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				return;
			}
			
			if (mLen > memData1.Text.Length / 2)
			{
				mLen = System.Convert.ToInt32(memData1.Text.Length / 2);
			}
			
			Module1.mStrtoVal((string) (memData1.Text), ref buffer, mLen); //将输入的十六进制格式字符数据转成数值数据
			if (Module1.mOpen == true)
			{
				//UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				if (USBIOXDLL.USBIO_MemWriteAddr1(Module1.mIndex, buffer, ref mLen) == false)
				{
					Interaction.MsgBox("MEM写数据块0失败！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				}
				memLen1.Text = Conversion.Hex((short) mLen);
			}
			else
			{
				Interaction.MsgBox("设备未打开！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
			}
		}
		
		private void Option1_Click(short Index)
		{
			
		}
		
		static short SSTab1_SelectedIndexChanged_PreviousTab = (short) sSTab1.SelectedIndexChanged;
		public void SSTab1_SelectedIndexChanged(System.Object eventSender, System.EventArgs eventArgs)
		{
			
			if ((Module1.mOpen == true) && (SSTab1.SelectedIndex == 4))
			{
				evtbtrefresh_Click(evtbtrefresh, new System.EventArgs());
				Led_CheckStateChanged(Led[(short) 0], new System.EventArgs());
			}
			
			SSTab1_SelectedIndexChanged_PreviousTab = (short) SSTab1.SelectedIndex;
		}
		
		public void StreamICRW_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			int mWRLen;
			int mRdLen;
			//UPGRADE_WARNING: Arrays in structure iBuff may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
			//Dim iBuff As arrRBuffer
			byte[] iBuff = new byte[USBIOXDLL.mMAX_BUFFER_LENGTH - 1 + 1];
			//UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
			byte[] buffer = new byte[USBIOXDLL.mMAX_BUFFER_LENGTH - 1 + 1];
			
			System.String temp_SystemString = I2CWRLen.Text;
			mWRLen = Module1.HexToBcd(ref temp_SystemString);
			System.String temp_SystemString2 = I2CRDLen.Text;
			mRdLen = Module1.HexToBcd(ref temp_SystemString2);
			
			//----------------------------------------
			if (I2CM[0].Checked == true)
			{
				if (USBIOXDLL.USBIO_SetStream(Module1.mIndex, 0x80) == false)
				{
					Interaction.MsgBox("设置I2C时钟 = 20KHz失败！ ", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
					return;
				}
			}
			else if (I2CM[1].Checked == true)
			{
				if (USBIOXDLL.USBIO_SetStream(Module1.mIndex, 0x81) == false)
				{
					Interaction.MsgBox("设置I2C时钟 = 100KHz失败！ ", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
					return;
				}
			}
			else if (I2CM[2].Checked == true)
			{
				if (USBIOXDLL.USBIO_SetStream(Module1.mIndex, 0x82) == false)
				{
					Interaction.MsgBox("设置I2C时钟 = 400KHz失败！ ", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
					return;
				}
			}
			else if (I2CM[3].Checked == true)
			{
				if (USBIOXDLL.USBIO_SetStream(Module1.mIndex, 0x83) == false)
				{
					Interaction.MsgBox("设置I2C时钟 = 750KHz失败！ ", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
					return;
				}
			}
			//----------------------------------------
			
			if (mWRLen > 0 && I2CWRBuf.Text == "")
			{
				Interaction.MsgBox("请输入要写的数据,长度！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				return;
			}
			if ((mWRLen == 0) && (mRdLen == 0))
			{
				Interaction.MsgBox("请输入读数据所需的长度！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				return;
			}
			if (mWRLen > I2CWRBuf.Text.Trim().Length / 2)
			{
				mWRLen = System.Convert.ToInt32(I2CWRBuf.Text.Trim().Length / 2);
			}
			
			Module1.mStrtoVal((string) (I2CWRBuf.Text), ref buffer, mWRLen); //将输入的十六进制格式字符数据转成数值数据
			
			string buff = "";
			int i;
			if (Module1.mOpen == true)
			{
				//UPGRADE_WARNING: Couldn't resolve default property of object iBuff. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				//UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				if (USBIOXDLL.USBIO_StreamI2C(Module1.mIndex, mWRLen, ref buffer, mRdLen, ref iBuff) == false)
				{
					Interaction.MsgBox("I2C流模式读写数据失败！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				}
				else
				{
					if (mRdLen > 0) //有数据返回
					{
						for (i = 0; i <= mRdLen - 1; i++)
						{
							buff = buff + Module1.Hex2bit(iBuff[i]) + " ";
						}
						I2CRDBuf.Text = buff;
					}
				}
				I2CWRLen.Text = Conversion.Hex((short) mWRLen);
				I2CRDLen.Text = Conversion.Hex((short) mRdLen);
			}
			else
			{
				Interaction.MsgBox("设备未打开！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
			}
		}
		
		public void StreamSPIRW_Click(System.Object eventSender, System.EventArgs eventArgs)
		{
			int mWRLen;
			//Dim mRdLen As Long
			//UPGRADE_WARNING: Arrays in structure ioBuff may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
			byte[] ioBuff = new byte[USBIOXDLL.mMAX_BUFFER_LENGTH - 1 + 1];
			//Dim iBuff As arrRBuffer
			//Dim buffer As arrRBuffer
			
			System.String temp_SystemString = SPIWRLen.Text;
			mWRLen = Module1.HexToBcd(ref temp_SystemString);
			//mRdLen = HexToBcd(I2CRDLen.Text)
			bool mTheFirst;
			mTheFirst = true;
			
			//If (mTheFirst) Then
			//  If (USBIO_SetStream(mIndex, &H81) = False) Then
			//    MsgBox "设置SPI模式失败!", vbExclamation, "USB2ISP DEMO"
			//  Else
			//    mTheFirst = False
			//Exit Sub
			//    End If
			//End If
			
			//----------------------------------------
			if (SPIMSB[0].Checked == true)
			{
				if (USBIOXDLL.USBIO_SetStream(Module1.mIndex, 0x81) == false)
				{
					Interaction.MsgBox("设置SPI高位在前模式失败！ ", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
					return;
				}
			}
			else if (SPILSB[1].Checked == true)
			{
				if (USBIOXDLL.USBIO_SetStream(Module1.mIndex, 0x1) == false)
				{
					Interaction.MsgBox("设置SPI低位在前模式失败！ ", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
					return;
				}
			}
			//----------------------------------------
			
			if (mWRLen > 0 && SPIWRBuf.Text == "")
			{
				Interaction.MsgBox("请输入要准备传输的数据字节数！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				return;
			}
			//If ((mWRLen = 0) And (mRdLen = 0)) Then
			//  MsgBox "请输入读数据所需的长度！", vbExclamation, "USB2ISP DEMO"
			//  Exit Sub
			//End If
			
			
			if (mWRLen > SPIWRBuf.Text.Trim().Length / 2)
			{
				mWRLen = System.Convert.ToInt32(SPIWRBuf.Text.Trim().Length / 2);
			}
			
			Module1.mStrtoVal((string) (SPIWRBuf.Text), ref ioBuff, mWRLen); //将输入的十六进制格式字符数据转成数值数据
			
			string buff = "";
			int i;
			if (Module1.mOpen == true)
			{
				//UPGRADE_WARNING: Couldn't resolve default property of object ioBuff. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				if (USBIOXDLL.USBIO_StreamSPI4(Module1.mIndex, 0x80, mWRLen, ref ioBuff) == false)
				{
					Interaction.MsgBox("SPI流模式读写数据失败！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
				}
				else
				{
					if (mWRLen > 0) //有数据返回
					{
						for (i = 0; i <= mWRLen - 1; i++)
						{
							buff = buff + Module1.Hex2bit(ioBuff[i]) + " ";
						}
						SPIWRBuf.Text = buff;
					}
				}
				SPIWRLen.Text = Conversion.Hex((short) mWRLen);
				//I2CRDLen.Text = Hex(mRdLen)
			}
			else
			{
				Interaction.MsgBox("设备未打开！", MsgBoxStyle.Exclamation, "USB2ISP DEMO");
			}
		}
		
		public void USBIO_NOTIFY_ROUTINE_KeyUp(System.Object eventSender, System.Windows.Forms.KeyEventArgs eventArgs)
		{
			short KeyCode =  (short) (eventArgs.KeyCode);
			short Shift =  (short) (System.Convert.ToInt32(eventArgs.KeyData) / 0x10000 ); //设备插拔通知处理程序
			int iEventStatus;
			iEventStatus = KeyCode; //插拔事件
			if (iEventStatus == USBIOXDLL.USBIO_DEVICE_ARRIVAL) // 设备插入事件,已经插入
			{
				if (USBIOXDLL.USBIO_OpenDevice(Module1.mIndex) == USBIOXDLL.INVALID_HANDLE_VALUE)
				{
					Interaction.MsgBox("打开设备失败!", (MsgBoxStyle) MsgBoxResult.Ok, "USB2ISP DEMO");
					Module1.mOpen = false;
				}
				else
				{
					Module1.mOpen = true; //打开成功
				}
			}
			else if (iEventStatus == USBIOXDLL.USBIO_DEVICE_REMOVE) // 设备拔出事件,已经拔出
			{
				USBIOXDLL.USBIO_CloseDevice(System.Convert.ToInt32(Module1.mIndex));
				Module1.mOpen = false;
			}
			enablebtn(System.Convert.ToBoolean(Module1.mOpen)); //设备打开,按钮可用,设备没打开,按钮禁用
		}
		
		public void enablebtn(bool bEnable) //bEnable=true :各窗体按钮可用 ;=false:enable:各窗体按钮禁用
		{
			frmMain with_1 = this;
			
			with_1.eppRead0.Enabled = bEnable;
			with_1.eppWrite0.Enabled = bEnable;
			with_1.eppRead1.Enabled = bEnable;
			with_1.eppWrite1.Enabled = bEnable;
			
			with_1.memRead0.Enabled = bEnable;
			with_1.memWrite0.Enabled = bEnable;
			with_1.memRead1.Enabled = bEnable;
			with_1.memWrite1.Enabled = bEnable;
			
			with_1.StreamICRW.Enabled = bEnable;
			
			with_1.StreamSPIRW.Enabled = bEnable;
			
			
			with_1.eepromRdDate.Enabled = bEnable;
			with_1.eepromWrDate.Enabled = bEnable;
			
			with_1.evtbtrefresh.Enabled = bEnable;
			with_1.Led[0].Enabled = bEnable;
			with_1.Led[1].Enabled = bEnable;
			with_1.Led[2].Enabled = bEnable;
			with_1.Led[3].Enabled = bEnable;
			with_1.Led[4].Enabled = bEnable;
			with_1.Led[5].Enabled = bEnable;
			with_1.Led[6].Enabled = bEnable;
			with_1.Led[7].Enabled = bEnable;
			
			if (bEnable == true) //窗体标题显示
			{
				this.Text = "USB2ISP **设备已插上";
				
			}
			else
			{
				this.Text = "USB2ISP **设备已拔出";
				
			}
			
			if (bEnable == true) //数字I/O窗口已初始化,刷新LED,按拔码开关状态
			{
				Led_CheckStateChanged(Led[(short) 0], new System.EventArgs());
				Led_CheckStateChanged(Led[(short) 1], new System.EventArgs());
				Led_CheckStateChanged(Led[(short) 2], new System.EventArgs());
				Led_CheckStateChanged(Led[(short) 3], new System.EventArgs());
				Led_CheckStateChanged(Led[(short) 4], new System.EventArgs());
				Led_CheckStateChanged(Led[(short) 5], new System.EventArgs());
				Led_CheckStateChanged(Led[(short) 6], new System.EventArgs());
				Led_CheckStateChanged(Led[(short) 7], new System.EventArgs());
				evtbtrefresh_Click(evtbtrefresh, new System.EventArgs());
			}
		}
	}
}
