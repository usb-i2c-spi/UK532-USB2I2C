using System.Diagnostics;
using System;
using System.Windows.Forms;
using System.Collections;
using System.Drawing;
using Microsoft.VisualBasic;
using System.Data;
using Microsoft.VisualBasic.Compatibility;
using System.Runtime.InteropServices;

namespace USB2ISP
{
	sealed class USBIOXDLL
	{
		// 2004.05.28, 2004.10.20, 2005.01.08, 2005.03.25, 2005.04.28
		//****************************************
		//**  Copyright  (C)  W.ch  1999-2005   **
		//**  Web:  http://www.USB-I2C-SPI.com  **
		//****************************************
		//**  DLL for USB interface chip USB2ISP**
		//**  C, VC6.0                          **
		//****************************************
		// 2010.05.28   For VB.net 2008
		//
		//
		//****************************************
		public enum EEPROM_TYPE // EEPROM型号定义
		{
			ID_24C01 = 0,
			ID_24C02 = 1,
			ID_24C04 = 2,
			ID_24C08 = 3,
			ID_24C16 = 4,
			ID_24C32 = 5,
			ID_24C64 = 6,
			ID_24C128 = 7,
			ID_24C256 = 8,
			ID_24C512 = 9,
			ID_24C1024 = 10,
			ID_24C2048 = 11,
			ID_24C4096 = 12
		}
		
		public struct mUspValue
		{
			public byte mUspValueLow; // 02H 值参数低字节
			public byte mUspValueHigh; // 03H 值参数高字节
		}
		public struct mUspIndex
		{
			public byte mUspIndexLow; // 04H 索引参数低字节
			public byte mUspIndexHigh; // 05H 索引参数高字节
		}
		public struct USB_SETUP_PKT // USB控制传输的建立阶段的数据请求包结构
		{
			public byte mUspReqType; // 00H 请求类型
			public byte mUspRequest; // 01H 请求代码
			//UPGRADE_NOTE: mUspValue was upgraded to mUspValue_Renamed. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
			public mUspValue mUspValue_Renamed; // 02H-03H 值参数
			//UPGRADE_NOTE: mUspIndex was upgraded to mUspIndex_Renamed. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
			public mUspIndex mUspIndex_Renamed; // 04H-05H 索引参数
			public short mLength; // 06H-07H 数据阶段的数据长度
		}
		
		public const short INVALID_HANDLE_VALUE = -1; //错误码
		public const short mUSBIO_PACKET_LENGTH = 32; // USB2ISP支持的数据包的长度
		public const short mUSBIO_PKT_LEN_SHORT = 8; // USB2ISP支持的短数据包的长度
		
		public struct WIN32_COMMAND //定义WIN32命令接口结构
		{
			public int mFunction; //输入时指定功能代码或者管道号
			//输出时返回操作状态
			public int mLength; //存取长度,返回后续数据的长度
			[VBFixedArray(mUSBIO_PACKET_LENGTH - 1)]public byte[] mBuffer; //数据缓冲区,长度为0至255B
			
			//UPGRADE_TODO: "Initialize" must be called to initialize instances of this structure. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="B4BFF9E0-8631-45CF-910E-62AB3970F27B"'
			public void Initialize()
			{
				mBuffer = new byte[mUSBIO_PACKET_LENGTH - 1 + 1];
			}
		}
		//UPGRADE_WARNING: Arrays in structure mWIN32_COMMAND may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
		public static WIN32_COMMAND mWIN32_COMMAND;
		
		public const int FILE_DEVICE_UNKNOWN = 0x22;
		public const short FILE_ANY_ACCESS = 0;
		public const short METHOD_BUFFERED = 0;
		// WIN32应用层接口命令
		public readonly static double IOCTL_USBIO_COMMAND = (FILE_DEVICE_UNKNOWN * (Math.Pow(2, 16)) + FILE_ANY_ACCESS * Math.Pow(2, 14) + 0xF34 * Math.Pow(2, 2) + METHOD_BUFFERED); // 专用接口
		
		const short mWIN32_COMMAND_HEAD = 8; // WIN32命令接口的头长度
		
		public const short mUSBIO_MAX_NUMBER = 16; // 最多同时连接的USB2ISP数
		
		public const int mMAX_BUFFER_LENGTH = 0x1000; // 数据缓冲区最大长度4096
		
		public const int mMAX_COMMAND_LENGTH = (mWIN32_COMMAND_HEAD + mMAX_BUFFER_LENGTH); // 最大数据长度加上命令结构头的长度
		
		public const int mDEFAULT_BUFFER_LEN = 0x400; // 数据缓冲区默认长度1024
		
		public const int mDEFAULT_COMMAND_LEN = (mWIN32_COMMAND_HEAD + mDEFAULT_BUFFER_LEN); // 默认数据长度加上命令结构头的长度
		
		
		// USB2ISP端点地址
		public const int mUSBIO_ENDP_INTER_UP = 0x81; // USB2ISP的中断数据上传端点的地址
		public const int mUSBIO_ENDP_INTER_DOWN = 0x1; // USB2ISP的中断数据下传端点的地址
		public const int mUSBIO_ENDP_DATA_UP = 0x82; // USB2ISP的数据块上传端点的地址
		public const int mUSBIO_ENDP_DATA_DOWN = 0x2; // USB2ISP的数据块下传端点的地址
		
		// 设备层接口提供的管道操作命令
		public const int mPipeDeviceCtrl = 0x4; // USB2ISP的综合控制管道
		public const int mPipeInterUp = 0x5; // USB2ISP的中断数据上传管道
		public const int mPipeDataUp = 0x6; // USB2ISP的数据块上传管道
		public const int mPipeDataDown = 0x7; // USB2ISP的数据块下传管道
		
		// 应用层接口的功能代码
		public const int mFuncNoOperation = 0x0; // 无操作
		public const int mFuncGetVersion = 0x1; // 获取驱动程序版本号
		public const int mFuncGetConfig = 0x2; // 获取USB设备配置描述符
		public const int mFuncSetTimeout = 0x9; // 设置USB通讯超时
		public const int mFuncSetExclusive = 0xB; // 设置独占使用
		public const int mFuncResetDevice = 0xC; // 复位USB设备
		public const int mFuncResetPipe = 0xD; // 复位USB管道
		public const int mFuncAbortPipe = 0xE; // 取消USB管道的数据请求
		
		// USB2ISP并口专用的功能代码
		public const int mFuncSetParaMode = 0xF; // 设置并口模式
		public const int mFuncReadData0 = 0x10; // 从并口读取数据块0
		public const int mFuncReadData1 = 0x11; // 从并口读取数据块1
		public const int mFuncWriteData0 = 0x12; // 向并口写入数据块0
		public const int mFuncWriteData1 = 0x13; // 向并口写入数据块1
		public const int mFuncWriteRead = 0x14; // 先输出再输入
		
		
		// USB设备标准请求代码
		public const int mUSB_CLR_FEATURE = 0x1;
		public const int mUSB_SET_FEATURE = 0x3;
		public const int mUSB_GET_STATUS = 0x0;
		public const int mUSB_SET_ADDRESS = 0x5;
		public const int mUSB_GET_DESCR = 0x6;
		public const int mUSB_SET_DESCR = 0x7;
		public const int mUSB_GET_CONFIG = 0x8;
		public const int mUSB_SET_CONFIG = 0x9;
		public const int mUSB_GET_INTERF = 0xA;
		public const int mUSB_SET_INTERF = 0xB;
		public const int mUSB_SYNC_FRAME = 0xC;
		
		// USB2ISP控制传输的厂商专用请求类型
		public const int mUSBIO_VENDOR_READ = 0xC0; // 通过控制传输实现的USB2ISP厂商专用读操作
		public const int mUSBIO_VENDOR_WRITE = 0x40; // 通过控制传输实现的USB2ISP厂商专用写操作
		
		// USB2ISP控制传输的厂商专用请求代码
		public const int mUSBIO_PARA_INIT = 0xB1; // 初始化并口
		public const int mUSBIO_I2C_STATUS = 0x52; // 获取I2C接口的状态
		public const int mUSBIO_I2C_COMMAND = 0x53; // 发出I2C接口的命令
		
		
		public const int mUSBIOA_CMD_I2C_STM_STA = 0x74; // I2C接口的命令流:产生起始位
		public const int mUSBIOA_CMD_I2C_STM_STO = 0x75; // I2C接口的命令流:产生停止位
		public const int mUSBIOA_CMD_I2C_STM_OUT = 0x0; //I2C接口的命令流:输出数据,位5-位0为长度,后续字节为数据,0长度则只发送一个字节并返回应答
		public const int mUSBIOA_CMD_I2C_STM_IN = 0xC0; // I2C接口的命令流:输入数据,位5-位0为长度,0长度则只接收一个字节并发送无应答
		public const int mUSBIOA_CMD_I2C_STM_SET = 0x60; // I2C接口的命令流:设置参数,位2=SPI的I/O数(0=单入单出,1=双入双出),位1位0=I2C速度(00=低速,01=标准,10=快速,11=高速)
		public const int mUSBIOA_CMD_I2C_STM_US = 0x40; // I2C接口的命令流:以微秒为单位延时,位3-位0为延时值
		public const int mUSBIOA_CMD_I2C_STM_MS = 0x50; // I2C接口的命令流:以亳秒为单位延时,位3-位0为延时值
		public const int mUSBIOA_CMD_I2C_STM_DLY = 0xF; // I2C接口的命令流单个命令延时的最大值
		public const int mUSBIOA_CMD_I2C_STM_END = 0x0; // I2C接口的命令流:命令包提前结束
		
		
		// 直接输入的状态信号的位定义
		public const int mStateBitERR = 0x100; // 只读,ERR#引脚输入状态,1:高电平,0:低电平
		public const int mStateBitPEMP = 0x200; // 只读,PEMP引脚输入状态,1:高电平,0:低电平
		public const int mStateBitINT = 0x400; // 只读,INT#引脚输入状态,1:高电平,0:低电平
		public const int mStateBitSLCT = 0x800; // 只读,SLCT引脚输入状态,1:高电平,0:低电平
		public const int mStateBitSDA = 0x800000; // 只读,SDA引脚输入状态,1:高电平,0:低电平
		
		
		
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern int USBIO_OpenDevice(int iIndex);
		// 打开USB2ISP设备,返回句柄,出错则无效
		// iIndex  指定USB2ISP设备序号,0对应第一个设备
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern void USBIO_CloseDevice(int iIndex);
		// 关闭USB2ISP设备
		// iIndex    指定USB2ISP设备序号
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern int USBIO_GetVersion();
		
		// 获得DLL版本号,返回版本号
		
		//UPGRADE_WARNING: Structure WIN32_COMMAND may require marshalling attributes to be passed as an argument in this Declare statement. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="C429C3A5-5D47-4CD9-8F51-74A1616405DC"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern int USBIO_DriverCommand(int iIndex, ref WIN32_COMMAND ioCommand);
		// 直接传递命令给驱动程序,出错则返回0,否则返回数据长度
		// iIndex,  ' 指定USB2ISP设备序号,V1.6以上DLL也可以是设备打开后的句柄
		// ioCommand   命令结构的地址
		// 该程序在调用后返回数据长度,并且仍然返回命令结构,如果是读操作,则数据返回在命令结构中,
		// 返回的数据长度在操作失败时为0,操作成功时为整个命令结构的长度,例如读一个字节,则返回mWIN32_COMMAND_HEAD+1,
		// 命令结构在调用前,分别提供:管道号或者命令功能代码,存取数据的长度(可选),数据(可选)
		// 命令结构在调用后,分别返回:操作状态代码,后续数据的长度(可选),
		//   操作状态代码是由WINDOWS定义的代码,可以参考NTSTATUS.H,
		//   后续数据的长度是指读操作返回的数据长度,数据存放在随后的缓冲区中,对于写操作一般为0
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern int USBIO_GetDrvVersion();
		
		// 获得驱动程序版本号,返回版本号,出错则返回0
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_ResetDevice(int iIndex);
		
		//复位USB设备
		// iIndex  指定USB2ISP设备序号
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_GetDeviceDescr(int iIndex, ref byte[] oBuffer, ref int ioLength);
		// 读取设备描述符
		// iIndex,   指定USB2ISP设备序号
		// oBuffer   指向一个足够大的缓冲区,用于保存描述符
		// ioLength   指向长度单元,输入时为准备读取的长度,返回后为实际读取的长度
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_GetConfigDescr(int iIndex, ref byte[] oBuffer, ref int ioLength);
		// 读取配置描述符
		//  iIndex,    指定USB2ISP设备序号
		//  oBuffer,   指向一个足够大的缓冲区,用于保存描述符
		//  ioLength   指向长度单元,输入时为准备读取的长度,返回后为实际读取的长度
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_SetIntRoutine(int iIndex, int iIntRoutine);
		//设定中断服务程序
		// 指定USB2ISP设备序号
		//指定中断服务程序,为NULL则取消中断服务,否则在中断时调用该程序
		
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_ReadInter(int iIndex, ref int iStatus);
		// 读取中断数据
		// iIndex,  指定USB2ISP设备序号
		// iStatus   指向一个双字单元,用于保存读取的中断状态数据,见下行
		// 位7-位0对应USB2ISP的D7-D0引脚
		//  位8对应USB2ISP的ERR#引脚, 位9对应USB2ISP的PEMP引脚, 位10对应USB2ISP的INT#引脚, 位11对应USB2ISP的SLCT引脚
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_AbortInter(int iIndex);
		// 放弃中断数据读操作
		// iIndex   指定USB2ISP设备序号
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_ReadData0(int iIndex, ref byte[] oBuffer, ref int ioLength);
		// 从0#端口读取数据块
		// iIndex     指定USB2ISP设备序号
		// oBuffer   指向一个足够大的缓冲区,用于保存读取的数据
		// ioLength   指向长度单元,输入时为准备读取的长度,返回后为实际读取的长度
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_ReadData1(int iIndex, ref byte[] oBuffer, ref int ioLength);
		// 从1#端口读取数据块
		// iIndex,  指定USB2ISP设备序号
		// oBuffer 指向一个足够大的缓冲区,用于保存读取的数据
		// ioLength   指向长度单元,输入时为准备读取的长度,返回后为实际读取的长度
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_AbortRead(int iIndex);
		// 放弃数据块读操作
		// iIndex    指定USB2ISP设备序号
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_WriteData0(int iIndex, ref byte[] iBuffer, ref int ioLength);
		// 向0#端口写出数据块
		// iIndex,    指定USB2ISP设备序号
		// iBuffer     指向一个缓冲区,放置准备写出的数据
		// ioLength  指向长度单元,输入时为准备写出的长度,返回后为实际写出的长度
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_WriteData1(int iIndex, ref byte[] iBuffer, ref int ioLength);
		// 向1#端口写出数据块
		// iIndex,    指定USB2ISP设备序号
		// iBuffer,    指向一个缓冲区,放置准备写出的数据
		// ioLength   指向长度单元,输入时为准备写出的长度,返回后为实际写出的长度
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_AbortWrite(int iIndex);
		// 放弃数据块写操作
		// iIndex   指定USB2ISP设备序号
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_GetStatus(int iIndex, ref int iStatus);
		//  通过USB2ISP直接输入数据和状态
		//  iIndex,   指定USB2ISP设备序号
		//  iStatus  指向一个双字单元,用于保存状态数据,见下行
		//  位7-位0对应USB2ISP的D7-D0引脚
		//  位8对应USB2ISP的ERR#引脚, 位9对应USB2ISP的PEMP引脚, 位10对应USB2ISP的INT#引脚, 位11对应USB2ISP的SLCT引脚, 位23对应USB2ISP的SDA引脚
		//  位13对应USB2ISP的BUSY/WAIT#引脚, 位14对应USB2ISP的AUTOFD#/DATAS#引脚,位15对应USB2ISP的SLCTIN#/ADDRS#引脚
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_ReadI2C(int iIndex, byte iDevice, byte iAddr, ref byte oByte);
		
		//  从I2C接口读取一个字节数据
		//  iIndex,   指定USB2ISP设备序号
		//  iDevice,    低7位指定I2C设备地址
		//  iAddr,    指定数据单元的地址
		//  oByte    指向一个字节单元,用于保存读取的字节数据
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_WriteI2C(int iIndex, byte iDevice, byte iAddr, byte iByte);
		
		//    向I2C接口写入一个字节数据
		//    iIndex,   指定USB2ISP设备序号
		//    iDevice,   低7位指定I2C设备地址
		//    iAddr,  指定数据单元的地址
		//    iByte  待写入的字节数据
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_EppReadData(int iIndex, ref byte[] oBuffer, ref int ioLength);
		//  EPP方式读数据: WR#=1, DS#=0, AS#=1, D0-D7=input
		//  iIndex,    指定USB2ISP设备序号
		//  oBuffer,    指向一个足够大的缓冲区,用于保存读取的数据
		//  ioLength    指向长度单元,输入时为准备读取的长度,返回后为实际读取的长度
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_EppReadAddr(int iIndex, ref byte[] oBuffer, ref int ioLength);
		//  EPP方式读地址: WR#=1, DS#=1, AS#=0, D0-D7=input
		//  iIndex,    指定USB2ISP设备序号
		//  oBuffer,    指向一个足够大的缓冲区,用于保存读取的地址数据
		//  ioLength   指向长度单元,输入时为准备读取的长度,返回后为实际读取的长度
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_EppWriteData(int iIndex, byte[] iBuffer, ref int ioLength);
		//   EPP方式写数据: WR#=0, DS#=0, AS#=1, D0-D7=output
		//   iIndex,     指定USB2ISP设备序号
		//   iBuffer,    指向一个缓冲区,放置准备写出的数据
		//   ioLength     指向长度单元,输入时为准备写出的长度,返回后为实际写出的长度
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_EppWriteAddr(int iIndex, ref object iBuffer, ref int ioLength);
		//   EPP方式写地址: WR#=0, DS#=1, AS#=0, D0-D7=output
		//   iIndex,    指定USB2ISP设备序号
		//   iBuffer,    指向一个缓冲区,放置准备写出的地址数据
		//   ioLength   指向长度单元,输入时为准备写出的长度,返回后为实际写出的长度
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_MemReadAddr0(int iIndex, byte[] oBuffer, ref int ioLength);
		// MEM方式读地址0: WR#=1, DS#/RD#=0, AS#/ADDR=0, D0-D7=input
		// iIndex,    指定USB2ISP设备序号
		// oBuffer,     指向一个足够大的缓冲区,用于保存从地址0读取的数据
		// ioLength   指向长度单元,输入时为准备读取的长度,返回后为实际读取的长度
		// change to 2008 .net  修改了第二参数   20100527
		
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_MemReadAddr1(int iIndex, byte[] oBuffer, ref int ioLength);
		// MEM方式读地址1: WR#=1, DS#/RD#=0, AS#/ADDR=1, D0-D7=input
		// iIndex,    指定USB2ISP设备序号
		// oBuffer,    指向一个足够大的缓冲区,用于保存从地址1读取的数据
		// ioLength    指向长度单元,输入时为准备读取的长度,返回后为实际读取的长度
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_MemWriteAddr0(int iIndex, byte[] iBuffer, ref int ioLength);
		// MEM方式写地址0: WR#=0, DS#/RD#=1, AS#/ADDR=0, D0-D7=output
		// iIndex,    指定USB2ISP设备序号
		// iBuffer,    指向一个缓冲区,放置准备向地址0写出的数据
		// ioLength    指向长度单元,输入时为准备写出的长度,返回后为实际写出的长度
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_MemWriteAddr1(int iIndex, byte[] iBuffer, ref int ioLength);
		//  MEM方式写地址1: WR#=0, DS#/RD#=1, AS#/ADDR=1, D0-D7=output
		//  iIndex,   指定USB2ISP设备序号
		//  iBuffer,    指向一个缓冲区,放置准备向地址1写出的数据
		//  ioLength      指向长度单元,输入时为准备写出的长度,返回后为实际写出的长度
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_SetExclusive(int iIndex, int iExclusive);
		// 设置独占使用当前USB2ISP设备
		// iIndex,    指定USB2ISP设备序号
		// iExclusive  为0则设备可以共享使用,非0则独占使用
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_SetTimeout(int iIndex, int iWriteTimeout, int iReadTimeout);
		//  设置USB数据读写的超时
		//  iIndex,  // 指定USB2ISP设备序号
		//  iWriteTimeout  指定USB写出数据块的超时时间,以毫秒mS为单位,0xFFFFFFFF指定不超时(默认值)
		//  iReadTimeout  指定USB读取数据块的超时时间,以毫秒mS为单位,0xFFFFFFFF指定不超时(默认值)
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_ReadData(int iIndex, ref byte[] oBuffer, ref int ioLength);
		// 读取数据块
		// iIndex,    指定USB2ISP设备序号
		// oBuffer,    指向一个足够大的缓冲区,用于保存读取的数据
		// ioLength      指向长度单元,输入时为准备读取的长度,返回后为实际读取的长度
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_WriteData(int iIndex, ref byte[] iBuffer, ref int ioLength);
		//  写出数据块
		//  iIndex,    指定USB2ISP设备序号
		//  iBuffer,    指向一个缓冲区,放置准备写出的数据
		//  ioLength   指向长度单元,输入时为准备写出的长度,返回后为实际写出的长度
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)] //'''
		public static extern int USBIO_GetDeviceName(int iIndex);
		// 返回指向USB2ISP设备名称的缓冲区,出错则返回NULL
		// iIndex   指定USB2ISP设备序号,0对应第一个设备
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_FlushBuffer(int iIndex);
		// 清空USB2ISP的缓冲区
		// iIndex   指定USB2ISP设备序号
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_WriteRead(int iIndex, int iWriteLength, ref byte[] iWriteBuffer, int iReadStep, int iReadTimes, ref int oReadLength, ref byte[] oReadBuffer);
		// USBIO_WriteRead   执行数据流命令,先输出再输入
		// iIndex,    指定USB2ISP设备序号
		// iWriteLength,   写长度,准备写出的长度
		// iWriteBuffer,    指向一个缓冲区,放置准备写出的数据
		// iReadStep,    准备读取的单个块的长度, 准备读取的总长度为(iReadStep*iReadTimes)
		// iReadTimes,    准备读取的次数
		// oReadLength,    指向长度单元,返回后为实际读取的长度
		// oReadBuffer      指向一个足够大的缓冲区,用于保存读取的数据
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_SetStream(int iIndex, int iMode);
		// USBIO_SetStream   设置串口流模式
		// iIndex,    指定USB2ISP设备序号
		// iMode      指定模式,见下行
		// 位1-位0: I2C接口速度/SCL频率, 00=低速/20KHz,01=标准/100KHz,10=快速/400KHz,11=高速/750KHz
		// 位2:     SPI的I/O数/IO引脚, 0=单入单出(D5出/D7入),1=双入双出(D5出D4出/D7入D6入)
		// 位7:     SPI字节中的位顺序, 0=低位在前, 1=高位在前
		// 其它保留,必须为0
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_SetDelaymS(int iIndex, int iDelay);
		//  USBIO_SetDelaymS     设置硬件异步延时,调用后很快返回,而在下一个流操作之前延时指定毫秒数
		// iIndex,    指定USB2ISP设备序号
		// iDelay      指定延时的毫秒数
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_StreamI2C(int iIndex, int iWriteLength, ref byte[] iWriteBuffer, int iReadLength, ref byte[] oReadBuffer);
		// USBIO_StreamI2C     处理I2C数据流,2线接口,时钟线为SCL引脚,数据线为SDA引脚(准双向I/O),速度约56K字节
		// iIndex,    指定USB2ISP设备序号
		// iWriteLength,    准备写出的数据字节数
		// iWriteBuffer,    指向一个缓冲区,放置准备写出的数据,首字节通常是I2C设备地址及读写方向位
		// iReadLength,     准备读取的数据字节数
		// oReadBuffer     指向一个缓冲区,返回后是读入的数据
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		//UPGRADE_WARNING: Structure EEPROM_TYPE may require marshalling attributes to be passed as an argument in this Declare statement. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="C429C3A5-5D47-4CD9-8F51-74A1616405DC"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_ReadEEPROM(int iIndexas, EEPROM_TYPE iEepromID, int iAddr, int iLength, byte[] oBuffer);
		// i    Index  指定USB2ISP设备序号
		// iEepromID   指定EEPROM型号
		// iAddr       指定数据单元的地址
		// iLength     准备读取的数据字节数
		// oBuffer     指向一个缓冲区,返回后是读入的数据
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		//UPGRADE_WARNING: Structure EEPROM_TYPE may require marshalling attributes to be passed as an argument in this Declare statement. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="C429C3A5-5D47-4CD9-8F51-74A1616405DC"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_WriteEEPROM(int iIndex, EEPROM_TYPE iEepromID, int iAddr, int iLength, byte[] iBuffer);
		// iIndex,    指定USB2ISP设备序号
		// iEepromID, 指定EEPROM型号
		// iAddr,     指定数据单元的地址
		// iLength,   准备写出的数据字节数
		// iBuffer    指向一个缓冲区,放置准备写出的数据
		//----------------------------------------------------------------------------------------
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_GetInput(int iIndex, ref int iStatus);
		// USBIO_GetInput 通过USB2ISP直接输入数据和状态,效率比USBIO_GetStatus更高
		// iIndex,  指定USB2ISP设备序号
		// iStatus  指向一个双字单元,用于保存状态数据,参考下面的位说明
		// 位7-位0对应USB2ISP的D7-D0引脚
		// 位8对应USB2ISP的ERR#引脚, 位9对应USB2ISP的PEMP引脚, 位10对应USB2ISP的INT#引脚, 位11对应USB2ISP的SLCT引脚, 位23对应USB2ISP的SDA引脚
		// 位13对应USB2ISP的BUSY/WAIT#引脚, 位14对应USB2ISP的AUTOFD#/DATAS#引脚,位15对应USB2ISP的SLCTIN#/ADDRS#引脚
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_SetOutput(int iIndex, int iEnable, int iSetDirOut, int iSetDataOut);
		// USBIO_SetOutput 设置USB2ISP的I/O方向,并通过USBIO_直接输出数据
		// ***** 谨慎使用该API, 防止修改I/O方向使输入引脚变为输出引脚导致与其它输出引脚之间短路而损坏芯片 *****
		// iIndex,  指定USB2ISP设备序号
		// iEnable, 数据有效标志,参考下面的位说明
		//// 位0为1说明iSetDataOut的位15-位8有效,否则忽略
		//// 位1为1说明iSetDirOut的位15-位8有效,否则忽略
		//// 位2为1说明iSetDataOut的7-位0有效,否则忽略
		//// 位3为1说明iSetDirOut的位7-位0有效,否则忽略
		//// 位4为1说明iSetDataOut的位23-位16有效,否则忽略
		// iSetDirOut, 设置I/O方向,某位清0则对应引脚为输入,某位置1则对应引脚为输出,并口方式下默认值为0x000FC000,参考下面的位说明
		// iSetDataOut 输出数据,如果I/O方向为输出,那么某位清0时对应引脚输出低电平,某位置1时对应引脚输出高电平,参考下面的位说明
		//// 位7-位0对应USB2ISP的D7-D0引脚
		//// 位8对应USB2ISP的ERR#引脚, 位9对应USB2ISP的PEMP引脚, 位10对应USB2ISP的INT#引脚, 位11对应USB2ISP的SLCT引脚
		//// 位13对应USB2ISP的WAIT#引脚, 位14对应USB2ISP的DATAS#/READ#引脚,位15对应USB2ISP的ADDRS#/ADDR/ALE引脚
		//// 以下引脚只能输出,不考虑I/O方向: 位16对应USB2ISP的RESET#引脚, 位17对应USB2ISP的WRITE#引脚, 位18对应USB2ISP的SCL引脚, 位29对应USB2ISP的SDA引脚
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_Set_D5_D0(int iIndex, int iSetDirOut, int iSetDataOut);
		// USBIO_Set_D5_D0 设置USB2ISP的D5-D0引脚的I/O方向,并通过USB2ISP的D5-D0引脚直接输出数据,效率比USBIO_SetOutput更高
		// ***** 谨慎使用该API, 防止修改I/O方向使输入引脚变为输出引脚导致与其它输出引脚之间短路而损坏芯片 *****
		// iIndex,      指定USB2ISP设备序号
		// iSetDirOut,  设置D5-D0各引脚的I/O方向,某位清0则对应引脚为输入,某位置1则对应引脚为输出,并口方式下默认值为0x00全部输入
		// iSetDataOut  设置D5-D0各引脚的输出数据,如果I/O方向为输出,那么某位清0时对应引脚输出低电平,某位置1时对应引脚输出高电平
		//// 以上数据的位5-位0分别对应USB2ISP的D5-D0引脚
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_StreamSPI3(int iIndex, int iChipSelect, int iLength, ref byte[] ioBuffer);
		// USBIO_StreamSPI3 处理SPI数据流,3线接口,时钟线为SCK/SCL引脚,数据线为DIO/SDA引脚(准双向I/O),片选线为D0/D1/D2,速度约51K字节
		// SPI时序: SCK2/SCL引脚为时钟输出, 默认为低电平, DIO/SDA引脚在时钟上升沿之前输出, DIO/SDA引脚在时钟下降沿之后输入
		// iIndex,   指定USB2ISP设备序号
		// iChipSelect,片选控制, 位7为0则忽略片选控制, 位7为1则参数有效: 位1位0为00/01/10分别选择D0/D1/D2引脚作为低电平有效片选
		// iLength,    准备传输的数据字节数
		// ioBuffer    指向一个缓冲区,放置准备从DIO写出的数据,返回后是从DIO读入的数据
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_StreamSPI4(int iIndex, int iChipSelect, int iLength, ref byte[] ioBuffer);
		// USBIO_StreamSPI4 处理SPI数据流,4线接口,时钟线为SCK/D3引脚,输出数据线为DOUT/D5/MOSI引脚,输入数据线为DIN/D7/MISO引脚,片选线为D0/D1/D2,速度约68K字节
		// SPI时序: SCK/D3引脚为时钟输出, 默认为低电平, DOUT/D5/MOSI引脚在时钟上升沿之前输出, DIN/D7/MISO引脚在时钟下降沿之后输入
		// iIndex,   指定USB2ISP设备序号
		// iChipSelect,片选控制, 位7为0则忽略片选控制, 位7为1则参数有效: 位1位0为00/01/10分别选择D0/D1/D2引脚作为低电平有效片选
		// iLength,    准备传输的数据字节数
		// ioBuffer    指向一个缓冲区,放置准备从DOUT/MOSI写出的数据,返回后是从DIN/MISO读入的数据
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_StreamSPI5(int iIndex, int iChipSelect, int iLength, ref byte[] ioBuffer, ref byte[] ioBuffer2);
		// USBIO_StreamSPI5 处理SPI数据流,5线接口,时钟线为SCK/D3引脚,输出数据线为DOUT/D5/MOSI和DOUT2/D4引脚,输入数据线为DIN/D7/MISO和DIN2/D6引脚,片选线为D0/D1/D2,速度约30K字节*2
		// SPI时序: SCK/D3引脚为时钟输出, 默认为低电平, DOUT/D5/MOSI和DOUT2/D4引脚在时钟上升沿之前输出, DIN/D7/MISO和DIN2/D6引脚在时钟下降沿之后输入
		// iIndex,   指定USB2ISP设备序号
		// iChipSelect,片选控制, 位7为0则忽略片选控制, 位7为1则参数有效: 位1位0为00/01/10分别选择D0/D1/D2引脚作为低电平有效片选
		// iLength,    准备传输的数据字节数
		// ioBuffer,   指向一个缓冲区,放置准备从DOUT/MOSI写出的数据,返回后是从DIN/MISO读入的数据
		// ioBuffer2   指向第二个缓冲区,放置准备从DOUT/MOSI2写出的数据,返回后是从DIN/MISO2读入的数据
		
		//UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_BitStreamSPI(int iIndex, int iLength, ref byte[] ioBuffer);
		// USBIO_BitStreamSPI 处理SPI位数据流,4线/5线接口,时钟线为SCK/D3引脚,输出数据线为DOUT/DOUT2引脚,输入数据线为DIN/DIN2引脚,片选线为D0/D1/D2,速度约8K位*2
		// iIndex,  指定USB2ISP设备序号
		// iLength, 准备传输的数据位数,一次最多896,建议不超过256
		// ioBuffer 指向一个缓冲区,放置准备从DOUT/MOSI/DOUT2/D2-D0写出的数据,返回后是从DIN/MISO/DIN2读入的数据
		///* SPI时序: SCK/D3引脚为时钟输出, 默认为低电平, DOUT/D5/MOSI和DOUT2/D4引脚在时钟上升沿之前输出, DIN/D7/MISO和DIN2/D6引脚在时钟下降沿之后输入 */
		///* ioBuffer中的一个字节共8位分别对应D7-D0引脚, 位5输出到DOUT, 位4输出到DOUT2, 位2-位0输出到D2-D0, 位7从DIN/MISO输入, 位6从DIN/MISO2输入, 位3数据忽略 */
		///* 在调用该API之前,应该先调用USBIO_Set_D5_D0设置USB2ISP的D5-D0引脚的I/O方向,并设置引脚的默认电平 */
		
		//-------------------------------------------------------------------------
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)] // 为0则禁止内部缓冲上传模式,使用直接上传,非0则启用内部缓冲上传模式并清除缓冲区中的已有数据
		public static extern bool USBIO_SetBufUpload(int iIndex, int iEnableOrClear);
		// USBIO_SetBufUpload  ' 设定内部缓冲上传模式
		// iIndex,          0指定USB2ISP设备序号,0对应第一个设备
		// iEnableOrClear  为0则禁止内部缓冲上传模式,使用直接上传,非0则启用内部缓冲上传模式并清除缓冲区中的已有数据
		// 如果启用内部缓冲上传模式,那么USB2ISP驱动程序创建线程自动接收USB上传数据到内部缓冲区,同时清除缓冲区中的已有数据,当应用程序调用USBIO_ReadData后将立即返回缓冲区中的已有数据
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern int USBIO_QueryBufUpload(int iIndex);
		// USBIO_QueryBufUpload   查询内部上传缓冲区中的已有数据包个数,成功返回数据包个数,出错返回-1
		// iIndex                指定USB2ISP设备序号,0对应第一个设备
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_SetBufDownload(int iIndex, int iEnableOrClear);
		//  USBIO_SetBufDownload  设定内部缓冲下传模式
		//  iIndex,              指定USB2ISP设备序号,0对应第一个设备
		//  iEnableOrClear       为0则禁止内部缓冲下传模式,使用直接下传,非0则启用内部缓冲下传模式并清除缓冲区中的已有数据
		//  如果启用内部缓冲下传模式,那么当应用程序调用USBIO_WriteData后将仅仅是将USB下传数据放到内部缓冲区并立即返回,而由USB2ISP驱动程序创建的线程自动发送直到完毕
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)] // 指定USB2ISP设备序号,0对应第一个设备
		public static extern int USBIO_QueryBufDownload(int iIndex);
		//  USBIO_QueryBufDownload  查询内部下传缓冲区中的剩余数据包个数(尚未发送),成功返回数据包个数,出错返回-1
		//  iIndex                 指定USB2ISP设备序号,0对应第一个设备
		
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_ResetInter(int iIndex);
		//  USBIO_ResetInter   复位中断数据读操作
		//  iIndex            指定USB2ISP设备序号
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_ResetRead(int iIndex);
		//  USBIO_ResetRead  复位数据块读操作
		//  iIndex          指定USB2ISP设备序号
		
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_ResetWrite(int iIndex);
		//    USBIO_ResetRead    复位数据块读操作
		//    iIndex            指定USB2ISP设备序号
		
		//typedef     VOID    ( CALLBACK  * mUSBIO_NOTIFY_ROUTINE ) (  ' 设备事件通知回调程序
		//    ULONG           iEventStatus );  ' 设备事件和当前状态(在下行定义): 0=设备拔出事件, 3=设备插入事件
		
		public const short USBIO_DEVICE_ARRIVAL = 3; // 设备插入事件,已经插入
		public const short USBIO_DEVICE_REMOVE_PEND = 1; // 设备将要拔出
		public const short USBIO_DEVICE_REMOVE = 0; // 设备拔出事件,已经拔出
		
		public delegate int  DelegateCallBack(int lparam);
		[DllImport("USBIOX.DLL", ExactSpelling=true, CharSet=CharSet.Ansi, SetLastError=true)]
		public static extern bool USBIO_SetDeviceNotify(int iIndex, ref string iDeviceID, DelegateCallBack iNotifyRoutine);
		//  USBIO_SetDeviceNotify     设定设备事件通知程序
		//  iIndex,                  指定USB2ISP设备序号,0对应第一个设备
		//  iDeviceID,               可选参数,指向字符串,指定被监控的设备的ID,字符串以\0终止
		//  iNotifyRoutine           (函数地址)指定设备事件回调程序, 为NULL则取消事件通知, 否则在检测到事件时调用该程序
	}
}
