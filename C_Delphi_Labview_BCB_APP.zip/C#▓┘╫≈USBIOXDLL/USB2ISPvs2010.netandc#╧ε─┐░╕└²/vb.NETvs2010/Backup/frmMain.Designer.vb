<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmMain
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents USBIO_NOTIFY_ROUTINE As System.Windows.Forms.Button
	Public WithEvents eppData0 As System.Windows.Forms.TextBox
	Public WithEvents eppLen0 As System.Windows.Forms.TextBox
	Public WithEvents eppRead0 As System.Windows.Forms.Button
	Public WithEvents eppWrite0 As System.Windows.Forms.Button
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents Label2 As System.Windows.Forms.Label
	Public WithEvents Label3 As System.Windows.Forms.Label
	Public WithEvents Label4 As System.Windows.Forms.Label
	Public WithEvents Label20 As System.Windows.Forms.Label
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
	Public WithEvents eppData1 As System.Windows.Forms.TextBox
	Public WithEvents eppLen1 As System.Windows.Forms.TextBox
	Public WithEvents eppRead1 As System.Windows.Forms.Button
	Public WithEvents eppWrite1 As System.Windows.Forms.Button
	Public WithEvents Label5 As System.Windows.Forms.Label
	Public WithEvents Label6 As System.Windows.Forms.Label
	Public WithEvents Label7 As System.Windows.Forms.Label
	Public WithEvents Label8 As System.Windows.Forms.Label
	Public WithEvents Label21 As System.Windows.Forms.Label
	Public WithEvents Frame2 As System.Windows.Forms.GroupBox
	Public WithEvents _SSTab1_TabPage0 As System.Windows.Forms.TabPage
	Public WithEvents memData0 As System.Windows.Forms.TextBox
	Public WithEvents memLen0 As System.Windows.Forms.TextBox
	Public WithEvents memRead0 As System.Windows.Forms.Button
	Public WithEvents memWrite0 As System.Windows.Forms.Button
	Public WithEvents Label10 As System.Windows.Forms.Label
	Public WithEvents Label11 As System.Windows.Forms.Label
	Public WithEvents Label12 As System.Windows.Forms.Label
	Public WithEvents Label9 As System.Windows.Forms.Label
	Public WithEvents Label22 As System.Windows.Forms.Label
	Public WithEvents Frame3 As System.Windows.Forms.GroupBox
	Public WithEvents memLen1 As System.Windows.Forms.TextBox
	Public WithEvents memData1 As System.Windows.Forms.TextBox
	Public WithEvents memRead1 As System.Windows.Forms.Button
	Public WithEvents memWrite1 As System.Windows.Forms.Button
	Public WithEvents Label13 As System.Windows.Forms.Label
	Public WithEvents Label14 As System.Windows.Forms.Label
	Public WithEvents Label15 As System.Windows.Forms.Label
	Public WithEvents Label16 As System.Windows.Forms.Label
	Public WithEvents Label23 As System.Windows.Forms.Label
	Public WithEvents Frame4 As System.Windows.Forms.GroupBox
	Public WithEvents _SSTab1_TabPage1 As System.Windows.Forms.TabPage
	Public WithEvents _I2CM_3 As System.Windows.Forms.RadioButton
	Public WithEvents _I2CM_2 As System.Windows.Forms.RadioButton
	Public WithEvents _I2CM_1 As System.Windows.Forms.RadioButton
	Public WithEvents _I2CM_0 As System.Windows.Forms.RadioButton
	Public WithEvents Frame17 As System.Windows.Forms.GroupBox
	Public WithEvents StreamICRW As System.Windows.Forms.Button
	Public WithEvents I2CWRBuf As System.Windows.Forms.TextBox
	Public WithEvents I2CWRLen As System.Windows.Forms.TextBox
	Public WithEvents Label17 As System.Windows.Forms.Label
	Public WithEvents Label24 As System.Windows.Forms.Label
	Public WithEvents Label25 As System.Windows.Forms.Label
	Public WithEvents Frame7 As System.Windows.Forms.GroupBox
	Public WithEvents I2CRDLen As System.Windows.Forms.TextBox
	Public WithEvents I2CRDBuf As System.Windows.Forms.TextBox
	Public WithEvents Label26 As System.Windows.Forms.Label
	Public WithEvents Label27 As System.Windows.Forms.Label
	Public WithEvents Label30 As System.Windows.Forms.Label
	Public WithEvents Frame6 As System.Windows.Forms.GroupBox
	Public WithEvents Frame5 As System.Windows.Forms.GroupBox
	Public WithEvents _SSTab1_TabPage2 As System.Windows.Forms.TabPage
	Public WithEvents WrDataLen As System.Windows.Forms.TextBox
	Public WithEvents WrDataBuf As System.Windows.Forms.TextBox
	Public WithEvents WrDataAddr As System.Windows.Forms.TextBox
	Public WithEvents eepromWrDate As System.Windows.Forms.Button
	Public WithEvents Label38 As System.Windows.Forms.Label
	Public WithEvents Label37 As System.Windows.Forms.Label
	Public WithEvents Label36 As System.Windows.Forms.Label
	Public WithEvents Label33 As System.Windows.Forms.Label
	Public WithEvents Frame8 As System.Windows.Forms.GroupBox
	Public WithEvents eepromRdDate As System.Windows.Forms.Button
	Public WithEvents RdDataAddr As System.Windows.Forms.TextBox
	Public WithEvents RdDataBuf As System.Windows.Forms.TextBox
	Public WithEvents RdDataLen As System.Windows.Forms.TextBox
	Public WithEvents Label39 As System.Windows.Forms.Label
	Public WithEvents Label35 As System.Windows.Forms.Label
	Public WithEvents Label34 As System.Windows.Forms.Label
	Public WithEvents Label32 As System.Windows.Forms.Label
	Public WithEvents Frame9 As System.Windows.Forms.GroupBox
	Public WithEvents _eppromtype_12 As System.Windows.Forms.RadioButton
	Public WithEvents _eppromtype_11 As System.Windows.Forms.RadioButton
	Public WithEvents _eppromtype_10 As System.Windows.Forms.RadioButton
	Public WithEvents _eppromtype_9 As System.Windows.Forms.RadioButton
	Public WithEvents _eppromtype_8 As System.Windows.Forms.RadioButton
	Public WithEvents _eppromtype_7 As System.Windows.Forms.RadioButton
	Public WithEvents _eppromtype_6 As System.Windows.Forms.RadioButton
	Public WithEvents _eppromtype_5 As System.Windows.Forms.RadioButton
	Public WithEvents _eppromtype_4 As System.Windows.Forms.RadioButton
	Public WithEvents _eppromtype_3 As System.Windows.Forms.RadioButton
	Public WithEvents _eppromtype_2 As System.Windows.Forms.RadioButton
	Public WithEvents _eppromtype_1 As System.Windows.Forms.RadioButton
	Public WithEvents _eppromtype_0 As System.Windows.Forms.RadioButton
	Public WithEvents Frame10 As System.Windows.Forms.GroupBox
	Public WithEvents _SSTab1_TabPage3 As System.Windows.Forms.TabPage
	Public WithEvents _Led_0 As System.Windows.Forms.CheckBox
	Public WithEvents _Led_1 As System.Windows.Forms.CheckBox
	Public WithEvents _Led_2 As System.Windows.Forms.CheckBox
	Public WithEvents _Led_3 As System.Windows.Forms.CheckBox
	Public WithEvents _Led_4 As System.Windows.Forms.CheckBox
	Public WithEvents _Led_5 As System.Windows.Forms.CheckBox
	Public WithEvents _Led_6 As System.Windows.Forms.CheckBox
	Public WithEvents _Led_7 As System.Windows.Forms.CheckBox
	Public WithEvents Label40 As System.Windows.Forms.Label
	Public WithEvents Frame14 As System.Windows.Forms.GroupBox
	Public WithEvents _swit_0 As System.Windows.Forms.CheckBox
	Public WithEvents _swit_1 As System.Windows.Forms.CheckBox
	Public WithEvents _swit_2 As System.Windows.Forms.CheckBox
	Public WithEvents _swit_3 As System.Windows.Forms.CheckBox
	Public WithEvents _swit_4 As System.Windows.Forms.CheckBox
	Public WithEvents _swit_5 As System.Windows.Forms.CheckBox
	Public WithEvents _swit_6 As System.Windows.Forms.CheckBox
	Public WithEvents _swit_7 As System.Windows.Forms.CheckBox
	Public WithEvents evtbtrefresh As System.Windows.Forms.Button
	Public WithEvents Label41 As System.Windows.Forms.Label
	Public WithEvents Frame12 As System.Windows.Forms.GroupBox
	Public WithEvents _memadd0_0 As System.Windows.Forms.RadioButton
	Public WithEvents _memadd1_1 As System.Windows.Forms.RadioButton
	Public WithEvents Frame13 As System.Windows.Forms.GroupBox
	Public WithEvents Label42 As System.Windows.Forms.Label
	Public WithEvents Label43 As System.Windows.Forms.Label
	Public WithEvents Label44 As System.Windows.Forms.Label
	Public WithEvents Frame11 As System.Windows.Forms.GroupBox
	Public WithEvents _SSTab1_TabPage4 As System.Windows.Forms.TabPage
	Public WithEvents _SPIMSB_0 As System.Windows.Forms.RadioButton
	Public WithEvents _SPILSB_1 As System.Windows.Forms.RadioButton
	Public WithEvents Frame16 As System.Windows.Forms.GroupBox
	Public WithEvents StreamSPIRW As System.Windows.Forms.Button
	Public WithEvents SPIWRBuf As System.Windows.Forms.TextBox
	Public WithEvents SPIWRLen As System.Windows.Forms.TextBox
	Public WithEvents _Label31_0 As System.Windows.Forms.Label
	Public WithEvents _Label28_0 As System.Windows.Forms.Label
	Public WithEvents Label29 As System.Windows.Forms.Label
	Public WithEvents _Label19_0 As System.Windows.Forms.Label
	Public WithEvents _Label18_0 As System.Windows.Forms.Label
	Public WithEvents Frame15 As System.Windows.Forms.GroupBox
	Public WithEvents _SSTab1_TabPage5 As System.Windows.Forms.TabPage
	Public WithEvents SSTab1 As System.Windows.Forms.TabControl
	Public WithEvents I2CM As Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray
	Public WithEvents Label18 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
	Public WithEvents Label19 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
	Public WithEvents Label28 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
	Public WithEvents Label31 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
	Public WithEvents Led As Microsoft.VisualBasic.Compatibility.VB6.CheckBoxArray
	Public WithEvents SPILSB As Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray
	Public WithEvents SPIMSB As Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray
	Public WithEvents eppromtype As Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray
	Public WithEvents memadd0 As Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray
	Public WithEvents memadd1 As Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray
	Public WithEvents swit As Microsoft.VisualBasic.Compatibility.VB6.CheckBoxArray
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMain))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.USBIO_NOTIFY_ROUTINE = New System.Windows.Forms.Button
		Me.SSTab1 = New System.Windows.Forms.TabControl
		Me._SSTab1_TabPage0 = New System.Windows.Forms.TabPage
		Me.Frame1 = New System.Windows.Forms.GroupBox
		Me.eppData0 = New System.Windows.Forms.TextBox
		Me.eppLen0 = New System.Windows.Forms.TextBox
		Me.eppRead0 = New System.Windows.Forms.Button
		Me.eppWrite0 = New System.Windows.Forms.Button
		Me.Label1 = New System.Windows.Forms.Label
		Me.Label2 = New System.Windows.Forms.Label
		Me.Label3 = New System.Windows.Forms.Label
		Me.Label4 = New System.Windows.Forms.Label
		Me.Label20 = New System.Windows.Forms.Label
		Me.Frame2 = New System.Windows.Forms.GroupBox
		Me.eppData1 = New System.Windows.Forms.TextBox
		Me.eppLen1 = New System.Windows.Forms.TextBox
		Me.eppRead1 = New System.Windows.Forms.Button
		Me.eppWrite1 = New System.Windows.Forms.Button
		Me.Label5 = New System.Windows.Forms.Label
		Me.Label6 = New System.Windows.Forms.Label
		Me.Label7 = New System.Windows.Forms.Label
		Me.Label8 = New System.Windows.Forms.Label
		Me.Label21 = New System.Windows.Forms.Label
		Me._SSTab1_TabPage1 = New System.Windows.Forms.TabPage
		Me.Frame3 = New System.Windows.Forms.GroupBox
		Me.memData0 = New System.Windows.Forms.TextBox
		Me.memLen0 = New System.Windows.Forms.TextBox
		Me.memRead0 = New System.Windows.Forms.Button
		Me.memWrite0 = New System.Windows.Forms.Button
		Me.Label10 = New System.Windows.Forms.Label
		Me.Label11 = New System.Windows.Forms.Label
		Me.Label12 = New System.Windows.Forms.Label
		Me.Label9 = New System.Windows.Forms.Label
		Me.Label22 = New System.Windows.Forms.Label
		Me.Frame4 = New System.Windows.Forms.GroupBox
		Me.memLen1 = New System.Windows.Forms.TextBox
		Me.memData1 = New System.Windows.Forms.TextBox
		Me.memRead1 = New System.Windows.Forms.Button
		Me.memWrite1 = New System.Windows.Forms.Button
		Me.Label13 = New System.Windows.Forms.Label
		Me.Label14 = New System.Windows.Forms.Label
		Me.Label15 = New System.Windows.Forms.Label
		Me.Label16 = New System.Windows.Forms.Label
		Me.Label23 = New System.Windows.Forms.Label
		Me._SSTab1_TabPage2 = New System.Windows.Forms.TabPage
		Me.Frame5 = New System.Windows.Forms.GroupBox
		Me.Frame17 = New System.Windows.Forms.GroupBox
		Me._I2CM_3 = New System.Windows.Forms.RadioButton
		Me._I2CM_2 = New System.Windows.Forms.RadioButton
		Me._I2CM_1 = New System.Windows.Forms.RadioButton
		Me._I2CM_0 = New System.Windows.Forms.RadioButton
		Me.Frame7 = New System.Windows.Forms.GroupBox
		Me.StreamICRW = New System.Windows.Forms.Button
		Me.I2CWRBuf = New System.Windows.Forms.TextBox
		Me.I2CWRLen = New System.Windows.Forms.TextBox
		Me.Label17 = New System.Windows.Forms.Label
		Me.Label24 = New System.Windows.Forms.Label
		Me.Label25 = New System.Windows.Forms.Label
		Me.Frame6 = New System.Windows.Forms.GroupBox
		Me.I2CRDLen = New System.Windows.Forms.TextBox
		Me.I2CRDBuf = New System.Windows.Forms.TextBox
		Me.Label26 = New System.Windows.Forms.Label
		Me.Label27 = New System.Windows.Forms.Label
		Me.Label30 = New System.Windows.Forms.Label
		Me._SSTab1_TabPage3 = New System.Windows.Forms.TabPage
		Me.Frame8 = New System.Windows.Forms.GroupBox
		Me.WrDataLen = New System.Windows.Forms.TextBox
		Me.WrDataBuf = New System.Windows.Forms.TextBox
		Me.WrDataAddr = New System.Windows.Forms.TextBox
		Me.eepromWrDate = New System.Windows.Forms.Button
		Me.Label38 = New System.Windows.Forms.Label
		Me.Label37 = New System.Windows.Forms.Label
		Me.Label36 = New System.Windows.Forms.Label
		Me.Label33 = New System.Windows.Forms.Label
		Me.Frame9 = New System.Windows.Forms.GroupBox
		Me.eepromRdDate = New System.Windows.Forms.Button
		Me.RdDataAddr = New System.Windows.Forms.TextBox
		Me.RdDataBuf = New System.Windows.Forms.TextBox
		Me.RdDataLen = New System.Windows.Forms.TextBox
		Me.Label39 = New System.Windows.Forms.Label
		Me.Label35 = New System.Windows.Forms.Label
		Me.Label34 = New System.Windows.Forms.Label
		Me.Label32 = New System.Windows.Forms.Label
		Me.Frame10 = New System.Windows.Forms.GroupBox
		Me._eppromtype_12 = New System.Windows.Forms.RadioButton
		Me._eppromtype_11 = New System.Windows.Forms.RadioButton
		Me._eppromtype_10 = New System.Windows.Forms.RadioButton
		Me._eppromtype_9 = New System.Windows.Forms.RadioButton
		Me._eppromtype_8 = New System.Windows.Forms.RadioButton
		Me._eppromtype_7 = New System.Windows.Forms.RadioButton
		Me._eppromtype_6 = New System.Windows.Forms.RadioButton
		Me._eppromtype_5 = New System.Windows.Forms.RadioButton
		Me._eppromtype_4 = New System.Windows.Forms.RadioButton
		Me._eppromtype_3 = New System.Windows.Forms.RadioButton
		Me._eppromtype_2 = New System.Windows.Forms.RadioButton
		Me._eppromtype_1 = New System.Windows.Forms.RadioButton
		Me._eppromtype_0 = New System.Windows.Forms.RadioButton
		Me._SSTab1_TabPage4 = New System.Windows.Forms.TabPage
		Me.Frame11 = New System.Windows.Forms.GroupBox
		Me.Frame14 = New System.Windows.Forms.GroupBox
		Me._Led_0 = New System.Windows.Forms.CheckBox
		Me._Led_1 = New System.Windows.Forms.CheckBox
		Me._Led_2 = New System.Windows.Forms.CheckBox
		Me._Led_3 = New System.Windows.Forms.CheckBox
		Me._Led_4 = New System.Windows.Forms.CheckBox
		Me._Led_5 = New System.Windows.Forms.CheckBox
		Me._Led_6 = New System.Windows.Forms.CheckBox
		Me._Led_7 = New System.Windows.Forms.CheckBox
		Me.Label40 = New System.Windows.Forms.Label
		Me.Frame12 = New System.Windows.Forms.GroupBox
		Me._swit_0 = New System.Windows.Forms.CheckBox
		Me._swit_1 = New System.Windows.Forms.CheckBox
		Me._swit_2 = New System.Windows.Forms.CheckBox
		Me._swit_3 = New System.Windows.Forms.CheckBox
		Me._swit_4 = New System.Windows.Forms.CheckBox
		Me._swit_5 = New System.Windows.Forms.CheckBox
		Me._swit_6 = New System.Windows.Forms.CheckBox
		Me._swit_7 = New System.Windows.Forms.CheckBox
		Me.evtbtrefresh = New System.Windows.Forms.Button
		Me.Label41 = New System.Windows.Forms.Label
		Me.Frame13 = New System.Windows.Forms.GroupBox
		Me._memadd0_0 = New System.Windows.Forms.RadioButton
		Me._memadd1_1 = New System.Windows.Forms.RadioButton
		Me.Label42 = New System.Windows.Forms.Label
		Me.Label43 = New System.Windows.Forms.Label
		Me.Label44 = New System.Windows.Forms.Label
		Me._SSTab1_TabPage5 = New System.Windows.Forms.TabPage
		Me.Frame15 = New System.Windows.Forms.GroupBox
		Me.Frame16 = New System.Windows.Forms.GroupBox
		Me._SPIMSB_0 = New System.Windows.Forms.RadioButton
		Me._SPILSB_1 = New System.Windows.Forms.RadioButton
		Me.StreamSPIRW = New System.Windows.Forms.Button
		Me.SPIWRBuf = New System.Windows.Forms.TextBox
		Me.SPIWRLen = New System.Windows.Forms.TextBox
		Me._Label31_0 = New System.Windows.Forms.Label
		Me._Label28_0 = New System.Windows.Forms.Label
		Me.Label29 = New System.Windows.Forms.Label
		Me._Label19_0 = New System.Windows.Forms.Label
		Me._Label18_0 = New System.Windows.Forms.Label
		Me.I2CM = New Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray(components)
		Me.Label18 = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(components)
		Me.Label19 = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(components)
		Me.Label28 = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(components)
		Me.Label31 = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(components)
		Me.Led = New Microsoft.VisualBasic.Compatibility.VB6.CheckBoxArray(components)
		Me.SPILSB = New Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray(components)
		Me.SPIMSB = New Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray(components)
		Me.eppromtype = New Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray(components)
		Me.memadd0 = New Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray(components)
		Me.memadd1 = New Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray(components)
		Me.swit = New Microsoft.VisualBasic.Compatibility.VB6.CheckBoxArray(components)
		Me.SSTab1.SuspendLayout()
		Me._SSTab1_TabPage0.SuspendLayout()
		Me.Frame1.SuspendLayout()
		Me.Frame2.SuspendLayout()
		Me._SSTab1_TabPage1.SuspendLayout()
		Me.Frame3.SuspendLayout()
		Me.Frame4.SuspendLayout()
		Me._SSTab1_TabPage2.SuspendLayout()
		Me.Frame5.SuspendLayout()
		Me.Frame17.SuspendLayout()
		Me.Frame7.SuspendLayout()
		Me.Frame6.SuspendLayout()
		Me._SSTab1_TabPage3.SuspendLayout()
		Me.Frame8.SuspendLayout()
		Me.Frame9.SuspendLayout()
		Me.Frame10.SuspendLayout()
		Me._SSTab1_TabPage4.SuspendLayout()
		Me.Frame11.SuspendLayout()
		Me.Frame14.SuspendLayout()
		Me.Frame12.SuspendLayout()
		Me.Frame13.SuspendLayout()
		Me._SSTab1_TabPage5.SuspendLayout()
		Me.Frame15.SuspendLayout()
		Me.Frame16.SuspendLayout()
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		CType(Me.I2CM, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.Label18, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.Label19, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.Label28, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.Label31, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.Led, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.SPILSB, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.SPIMSB, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.eppromtype, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.memadd0, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.memadd1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.swit, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.Text = "USB2ISP DEMO    WWW.USB-I2C-SPI.COM"
		Me.ClientSize = New System.Drawing.Size(501, 482)
		Me.Location = New System.Drawing.Point(4, 30)
		Me.Icon = CType(resources.GetObject("frmMain.Icon"), System.Drawing.Icon)
		Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable
		Me.ControlBox = True
		Me.Enabled = True
		Me.KeyPreview = False
		Me.MaximizeBox = True
		Me.MinimizeBox = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmMain"
		Me.USBIO_NOTIFY_ROUTINE.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.USBIO_NOTIFY_ROUTINE.Text = "ģ�⴦���豸ͦ���ж��¼�"
		Me.USBIO_NOTIFY_ROUTINE.Enabled = False
		Me.USBIO_NOTIFY_ROUTINE.Size = New System.Drawing.Size(217, 22)
		Me.USBIO_NOTIFY_ROUTINE.Location = New System.Drawing.Point(169, 444)
		Me.USBIO_NOTIFY_ROUTINE.TabIndex = 115
		Me.USBIO_NOTIFY_ROUTINE.Visible = False
		Me.USBIO_NOTIFY_ROUTINE.BackColor = System.Drawing.SystemColors.Control
		Me.USBIO_NOTIFY_ROUTINE.CausesValidation = True
		Me.USBIO_NOTIFY_ROUTINE.ForeColor = System.Drawing.SystemColors.ControlText
		Me.USBIO_NOTIFY_ROUTINE.Cursor = System.Windows.Forms.Cursors.Default
		Me.USBIO_NOTIFY_ROUTINE.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.USBIO_NOTIFY_ROUTINE.TabStop = True
		Me.USBIO_NOTIFY_ROUTINE.Name = "USBIO_NOTIFY_ROUTINE"
		Me.SSTab1.Size = New System.Drawing.Size(487, 461)
		Me.SSTab1.Location = New System.Drawing.Point(7, 6)
		Me.SSTab1.TabIndex = 0
		Me.SSTab1.SelectedIndex = 5
		Me.SSTab1.ItemSize = New System.Drawing.Size(42, 18)
		Me.SSTab1.Font = New System.Drawing.Font("����", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
		Me.SSTab1.Name = "SSTab1"
		Me._SSTab1_TabPage0.Text = "EPP����"
		Me.Frame1.Text = "��д���ݣ�API=USBIO_EppReadData��USBIO_EppWriteData"
		Me.Frame1.Size = New System.Drawing.Size(456, 191)
		Me.Frame1.Location = New System.Drawing.Point(16, 39)
		Me.Frame1.TabIndex = 31
		Me.Frame1.BackColor = System.Drawing.SystemColors.Control
		Me.Frame1.Enabled = True
		Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame1.Visible = True
		Me.Frame1.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame1.Name = "Frame1"
		Me.eppData0.AutoSize = False
		Me.eppData0.Size = New System.Drawing.Size(313, 68)
		Me.eppData0.Location = New System.Drawing.Point(68, 85)
		Me.eppData0.MultiLine = True
		Me.eppData0.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.eppData0.TabIndex = 35
		Me.eppData0.AcceptsReturn = True
		Me.eppData0.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.eppData0.BackColor = System.Drawing.SystemColors.Window
		Me.eppData0.CausesValidation = True
		Me.eppData0.Enabled = True
		Me.eppData0.ForeColor = System.Drawing.SystemColors.WindowText
		Me.eppData0.HideSelection = True
		Me.eppData0.ReadOnly = False
		Me.eppData0.Maxlength = 0
		Me.eppData0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.eppData0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.eppData0.TabStop = True
		Me.eppData0.Visible = True
		Me.eppData0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.eppData0.Name = "eppData0"
		Me.eppLen0.AutoSize = False
		Me.eppLen0.Size = New System.Drawing.Size(127, 25)
		Me.eppLen0.Location = New System.Drawing.Point(69, 55)
		Me.eppLen0.TabIndex = 34
		Me.eppLen0.AcceptsReturn = True
		Me.eppLen0.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.eppLen0.BackColor = System.Drawing.SystemColors.Window
		Me.eppLen0.CausesValidation = True
		Me.eppLen0.Enabled = True
		Me.eppLen0.ForeColor = System.Drawing.SystemColors.WindowText
		Me.eppLen0.HideSelection = True
		Me.eppLen0.ReadOnly = False
		Me.eppLen0.Maxlength = 0
		Me.eppLen0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.eppLen0.MultiLine = False
		Me.eppLen0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.eppLen0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.eppLen0.TabStop = True
		Me.eppLen0.Visible = True
		Me.eppLen0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.eppLen0.Name = "eppLen0"
		Me.eppRead0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.eppRead0.Text = "Read"
		Me.eppRead0.Size = New System.Drawing.Size(65, 25)
		Me.eppRead0.Location = New System.Drawing.Point(240, 159)
		Me.eppRead0.TabIndex = 33
		Me.eppRead0.BackColor = System.Drawing.SystemColors.Control
		Me.eppRead0.CausesValidation = True
		Me.eppRead0.Enabled = True
		Me.eppRead0.ForeColor = System.Drawing.SystemColors.ControlText
		Me.eppRead0.Cursor = System.Windows.Forms.Cursors.Default
		Me.eppRead0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.eppRead0.TabStop = True
		Me.eppRead0.Name = "eppRead0"
		Me.eppWrite0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.eppWrite0.Text = "Write"
		Me.eppWrite0.Size = New System.Drawing.Size(65, 26)
		Me.eppWrite0.Location = New System.Drawing.Point(316, 158)
		Me.eppWrite0.TabIndex = 32
		Me.eppWrite0.BackColor = System.Drawing.SystemColors.Control
		Me.eppWrite0.CausesValidation = True
		Me.eppWrite0.Enabled = True
		Me.eppWrite0.ForeColor = System.Drawing.SystemColors.ControlText
		Me.eppWrite0.Cursor = System.Windows.Forms.Cursors.Default
		Me.eppWrite0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.eppWrite0.TabStop = True
		Me.eppWrite0.Name = "eppWrite0"
		Me.Label1.Text = "EPP��ʽ������: WR#=1, DS#=0, AS#=1, D0-D7=input"
		Me.Label1.Size = New System.Drawing.Size(297, 12)
		Me.Label1.Location = New System.Drawing.Point(27, 17)
		Me.Label1.TabIndex = 40
		Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label1.BackColor = System.Drawing.SystemColors.Control
		Me.Label1.Enabled = True
		Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label1.UseMnemonic = True
		Me.Label1.Visible = True
		Me.Label1.AutoSize = False
		Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label1.Name = "Label1"
		Me.Label2.Text = "EPP��ʽд����: WR#=0, DS#=0, AS#=1, D0-D7=output"
		Me.Label2.Size = New System.Drawing.Size(305, 17)
		Me.Label2.Location = New System.Drawing.Point(27, 36)
		Me.Label2.TabIndex = 39
		Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label2.BackColor = System.Drawing.SystemColors.Control
		Me.Label2.Enabled = True
		Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label2.UseMnemonic = True
		Me.Label2.Visible = True
		Me.Label2.AutoSize = False
		Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label2.Name = "Label2"
		Me.Label3.Text = "����"
		Me.Label3.Size = New System.Drawing.Size(41, 17)
		Me.Label3.Location = New System.Drawing.Point(26, 89)
		Me.Label3.TabIndex = 38
		Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label3.BackColor = System.Drawing.SystemColors.Control
		Me.Label3.Enabled = True
		Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label3.UseMnemonic = True
		Me.Label3.Visible = True
		Me.Label3.AutoSize = False
		Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label3.Name = "Label3"
		Me.Label4.Text = "����"
		Me.Label4.Size = New System.Drawing.Size(33, 17)
		Me.Label4.Location = New System.Drawing.Point(27, 59)
		Me.Label4.TabIndex = 37
		Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label4.BackColor = System.Drawing.SystemColors.Control
		Me.Label4.Enabled = True
		Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label4.UseMnemonic = True
		Me.Label4.Visible = True
		Me.Label4.AutoSize = False
		Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label4.Name = "Label4"
		Me.Label20.Text = "(<1000H)"
		Me.Label20.Size = New System.Drawing.Size(57, 19)
		Me.Label20.Location = New System.Drawing.Point(201, 59)
		Me.Label20.TabIndex = 36
		Me.Label20.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label20.BackColor = System.Drawing.SystemColors.Control
		Me.Label20.Enabled = True
		Me.Label20.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label20.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label20.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label20.UseMnemonic = True
		Me.Label20.Visible = True
		Me.Label20.AutoSize = False
		Me.Label20.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label20.Name = "Label20"
		Me.Frame2.Text = "��д��ַ��API=USBIO_EppReadAddr��USBIO_EppWriteAddr"
		Me.Frame2.Size = New System.Drawing.Size(456, 191)
		Me.Frame2.Location = New System.Drawing.Point(16, 244)
		Me.Frame2.TabIndex = 21
		Me.Frame2.BackColor = System.Drawing.SystemColors.Control
		Me.Frame2.Enabled = True
		Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame2.Visible = True
		Me.Frame2.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame2.Name = "Frame2"
		Me.eppData1.AutoSize = False
		Me.eppData1.Size = New System.Drawing.Size(313, 69)
		Me.eppData1.Location = New System.Drawing.Point(69, 87)
		Me.eppData1.MultiLine = True
		Me.eppData1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.eppData1.TabIndex = 25
		Me.eppData1.AcceptsReturn = True
		Me.eppData1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.eppData1.BackColor = System.Drawing.SystemColors.Window
		Me.eppData1.CausesValidation = True
		Me.eppData1.Enabled = True
		Me.eppData1.ForeColor = System.Drawing.SystemColors.WindowText
		Me.eppData1.HideSelection = True
		Me.eppData1.ReadOnly = False
		Me.eppData1.Maxlength = 0
		Me.eppData1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.eppData1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.eppData1.TabStop = True
		Me.eppData1.Visible = True
		Me.eppData1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.eppData1.Name = "eppData1"
		Me.eppLen1.AutoSize = False
		Me.eppLen1.Size = New System.Drawing.Size(161, 25)
		Me.eppLen1.Location = New System.Drawing.Point(69, 57)
		Me.eppLen1.TabIndex = 24
		Me.eppLen1.AcceptsReturn = True
		Me.eppLen1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.eppLen1.BackColor = System.Drawing.SystemColors.Window
		Me.eppLen1.CausesValidation = True
		Me.eppLen1.Enabled = True
		Me.eppLen1.ForeColor = System.Drawing.SystemColors.WindowText
		Me.eppLen1.HideSelection = True
		Me.eppLen1.ReadOnly = False
		Me.eppLen1.Maxlength = 0
		Me.eppLen1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.eppLen1.MultiLine = False
		Me.eppLen1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.eppLen1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.eppLen1.TabStop = True
		Me.eppLen1.Visible = True
		Me.eppLen1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.eppLen1.Name = "eppLen1"
		Me.eppRead1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.eppRead1.Text = "Read"
		Me.eppRead1.Size = New System.Drawing.Size(65, 25)
		Me.eppRead1.Location = New System.Drawing.Point(244, 160)
		Me.eppRead1.TabIndex = 23
		Me.eppRead1.BackColor = System.Drawing.SystemColors.Control
		Me.eppRead1.CausesValidation = True
		Me.eppRead1.Enabled = True
		Me.eppRead1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.eppRead1.Cursor = System.Windows.Forms.Cursors.Default
		Me.eppRead1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.eppRead1.TabStop = True
		Me.eppRead1.Name = "eppRead1"
		Me.eppWrite1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.eppWrite1.Text = "Write"
		Me.eppWrite1.Size = New System.Drawing.Size(65, 25)
		Me.eppWrite1.Location = New System.Drawing.Point(317, 160)
		Me.eppWrite1.TabIndex = 22
		Me.eppWrite1.BackColor = System.Drawing.SystemColors.Control
		Me.eppWrite1.CausesValidation = True
		Me.eppWrite1.Enabled = True
		Me.eppWrite1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.eppWrite1.Cursor = System.Windows.Forms.Cursors.Default
		Me.eppWrite1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.eppWrite1.TabStop = True
		Me.eppWrite1.Name = "eppWrite1"
		Me.Label5.Text = "EPP��ʽ����ַ: WR#=1, DS#=1, AS#=0, D0-D7=input"
		Me.Label5.Size = New System.Drawing.Size(297, 12)
		Me.Label5.Location = New System.Drawing.Point(23, 19)
		Me.Label5.TabIndex = 30
		Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label5.BackColor = System.Drawing.SystemColors.Control
		Me.Label5.Enabled = True
		Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label5.UseMnemonic = True
		Me.Label5.Visible = True
		Me.Label5.AutoSize = False
		Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label5.Name = "Label5"
		Me.Label6.Text = "EPP��ʽд��ַ: WR#=0, DS#=1, AS#=0, D0-D7=output"
		Me.Label6.Size = New System.Drawing.Size(297, 12)
		Me.Label6.Location = New System.Drawing.Point(23, 38)
		Me.Label6.TabIndex = 29
		Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label6.BackColor = System.Drawing.SystemColors.Control
		Me.Label6.Enabled = True
		Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label6.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label6.UseMnemonic = True
		Me.Label6.Visible = True
		Me.Label6.AutoSize = False
		Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label6.Name = "Label6"
		Me.Label7.Text = "����"
		Me.Label7.Size = New System.Drawing.Size(41, 17)
		Me.Label7.Location = New System.Drawing.Point(25, 88)
		Me.Label7.TabIndex = 28
		Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label7.BackColor = System.Drawing.SystemColors.Control
		Me.Label7.Enabled = True
		Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label7.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label7.UseMnemonic = True
		Me.Label7.Visible = True
		Me.Label7.AutoSize = False
		Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label7.Name = "Label7"
		Me.Label8.Text = "����"
		Me.Label8.Size = New System.Drawing.Size(33, 17)
		Me.Label8.Location = New System.Drawing.Point(23, 60)
		Me.Label8.TabIndex = 27
		Me.Label8.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label8.BackColor = System.Drawing.SystemColors.Control
		Me.Label8.Enabled = True
		Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label8.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label8.UseMnemonic = True
		Me.Label8.Visible = True
		Me.Label8.AutoSize = False
		Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label8.Name = "Label8"
		Me.Label21.Text = "(<1000H)"
		Me.Label21.Size = New System.Drawing.Size(57, 19)
		Me.Label21.Location = New System.Drawing.Point(234, 62)
		Me.Label21.TabIndex = 26
		Me.Label21.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label21.BackColor = System.Drawing.SystemColors.Control
		Me.Label21.Enabled = True
		Me.Label21.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label21.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label21.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label21.UseMnemonic = True
		Me.Label21.Visible = True
		Me.Label21.AutoSize = False
		Me.Label21.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label21.Name = "Label21"
		Me._SSTab1_TabPage1.Text = "MEM����"
		Me.Frame3.Text = "��д��ַ0��API=USBIO_MemReadAddr0��USBIO_MemWriteAddr0"
		Me.Frame3.Size = New System.Drawing.Size(456, 191)
		Me.Frame3.Location = New System.Drawing.Point(15, 36)
		Me.Frame3.TabIndex = 11
		Me.Frame3.BackColor = System.Drawing.SystemColors.Control
		Me.Frame3.Enabled = True
		Me.Frame3.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame3.Visible = True
		Me.Frame3.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame3.Name = "Frame3"
		Me.memData0.AutoSize = False
		Me.memData0.Size = New System.Drawing.Size(313, 69)
		Me.memData0.Location = New System.Drawing.Point(76, 85)
		Me.memData0.MultiLine = True
		Me.memData0.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.memData0.TabIndex = 15
		Me.memData0.AcceptsReturn = True
		Me.memData0.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.memData0.BackColor = System.Drawing.SystemColors.Window
		Me.memData0.CausesValidation = True
		Me.memData0.Enabled = True
		Me.memData0.ForeColor = System.Drawing.SystemColors.WindowText
		Me.memData0.HideSelection = True
		Me.memData0.ReadOnly = False
		Me.memData0.Maxlength = 0
		Me.memData0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.memData0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.memData0.TabStop = True
		Me.memData0.Visible = True
		Me.memData0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.memData0.Name = "memData0"
		Me.memLen0.AutoSize = False
		Me.memLen0.Size = New System.Drawing.Size(161, 25)
		Me.memLen0.Location = New System.Drawing.Point(76, 55)
		Me.memLen0.TabIndex = 14
		Me.memLen0.AcceptsReturn = True
		Me.memLen0.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.memLen0.BackColor = System.Drawing.SystemColors.Window
		Me.memLen0.CausesValidation = True
		Me.memLen0.Enabled = True
		Me.memLen0.ForeColor = System.Drawing.SystemColors.WindowText
		Me.memLen0.HideSelection = True
		Me.memLen0.ReadOnly = False
		Me.memLen0.Maxlength = 0
		Me.memLen0.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.memLen0.MultiLine = False
		Me.memLen0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.memLen0.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.memLen0.TabStop = True
		Me.memLen0.Visible = True
		Me.memLen0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.memLen0.Name = "memLen0"
		Me.memRead0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.memRead0.Text = "Read"
		Me.memRead0.Size = New System.Drawing.Size(65, 25)
		Me.memRead0.Location = New System.Drawing.Point(248, 158)
		Me.memRead0.TabIndex = 13
		Me.memRead0.BackColor = System.Drawing.SystemColors.Control
		Me.memRead0.CausesValidation = True
		Me.memRead0.Enabled = True
		Me.memRead0.ForeColor = System.Drawing.SystemColors.ControlText
		Me.memRead0.Cursor = System.Windows.Forms.Cursors.Default
		Me.memRead0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.memRead0.TabStop = True
		Me.memRead0.Name = "memRead0"
		Me.memWrite0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.memWrite0.Text = "Write"
		Me.memWrite0.Size = New System.Drawing.Size(65, 25)
		Me.memWrite0.Location = New System.Drawing.Point(325, 158)
		Me.memWrite0.TabIndex = 12
		Me.memWrite0.BackColor = System.Drawing.SystemColors.Control
		Me.memWrite0.CausesValidation = True
		Me.memWrite0.Enabled = True
		Me.memWrite0.ForeColor = System.Drawing.SystemColors.ControlText
		Me.memWrite0.Cursor = System.Windows.Forms.Cursors.Default
		Me.memWrite0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.memWrite0.TabStop = True
		Me.memWrite0.Name = "memWrite0"
		Me.Label10.Text = "����"
		Me.Label10.Size = New System.Drawing.Size(41, 17)
		Me.Label10.Location = New System.Drawing.Point(20, 85)
		Me.Label10.TabIndex = 20
		Me.Label10.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label10.BackColor = System.Drawing.SystemColors.Control
		Me.Label10.Enabled = True
		Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label10.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label10.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label10.UseMnemonic = True
		Me.Label10.Visible = True
		Me.Label10.AutoSize = False
		Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label10.Name = "Label10"
		Me.Label11.Text = "MEM��ʽд��ַ0: WR#=0, DS#/RD#=1,AS#/ADDR=0,D0-D7=output"
		Me.Label11.Size = New System.Drawing.Size(353, 17)
		Me.Label11.Location = New System.Drawing.Point(20, 36)
		Me.Label11.TabIndex = 19
		Me.Label11.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label11.BackColor = System.Drawing.SystemColors.Control
		Me.Label11.Enabled = True
		Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label11.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label11.UseMnemonic = True
		Me.Label11.Visible = True
		Me.Label11.AutoSize = False
		Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label11.Name = "Label11"
		Me.Label12.Text = "MEM��ʽ����ַ0: WR#=1, DS#/RD#=0,AS#/ADDR=0,D0-D7=input"
		Me.Label12.Size = New System.Drawing.Size(361, 12)
		Me.Label12.Location = New System.Drawing.Point(20, 17)
		Me.Label12.TabIndex = 18
		Me.Label12.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label12.BackColor = System.Drawing.SystemColors.Control
		Me.Label12.Enabled = True
		Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label12.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label12.UseMnemonic = True
		Me.Label12.Visible = True
		Me.Label12.AutoSize = False
		Me.Label12.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label12.Name = "Label12"
		Me.Label9.Text = "����"
		Me.Label9.Size = New System.Drawing.Size(33, 17)
		Me.Label9.Location = New System.Drawing.Point(20, 59)
		Me.Label9.TabIndex = 17
		Me.Label9.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label9.BackColor = System.Drawing.SystemColors.Control
		Me.Label9.Enabled = True
		Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label9.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label9.UseMnemonic = True
		Me.Label9.Visible = True
		Me.Label9.AutoSize = False
		Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label9.Name = "Label9"
		Me.Label22.Text = "(<1000H)"
		Me.Label22.Size = New System.Drawing.Size(57, 19)
		Me.Label22.Location = New System.Drawing.Point(239, 58)
		Me.Label22.TabIndex = 16
		Me.Label22.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label22.BackColor = System.Drawing.SystemColors.Control
		Me.Label22.Enabled = True
		Me.Label22.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label22.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label22.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label22.UseMnemonic = True
		Me.Label22.Visible = True
		Me.Label22.AutoSize = False
		Me.Label22.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label22.Name = "Label22"
		Me.Frame4.Text = "��д��ַ1��API=USBIO_MemReadAddr1��USBIO_MemWriteAddr1"
		Me.Frame4.Size = New System.Drawing.Size(455, 191)
		Me.Frame4.Location = New System.Drawing.Point(18, 248)
		Me.Frame4.TabIndex = 1
		Me.Frame4.BackColor = System.Drawing.SystemColors.Control
		Me.Frame4.Enabled = True
		Me.Frame4.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame4.Visible = True
		Me.Frame4.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame4.Name = "Frame4"
		Me.memLen1.AutoSize = False
		Me.memLen1.Size = New System.Drawing.Size(161, 25)
		Me.memLen1.Location = New System.Drawing.Point(70, 56)
		Me.memLen1.TabIndex = 5
		Me.memLen1.AcceptsReturn = True
		Me.memLen1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.memLen1.BackColor = System.Drawing.SystemColors.Window
		Me.memLen1.CausesValidation = True
		Me.memLen1.Enabled = True
		Me.memLen1.ForeColor = System.Drawing.SystemColors.WindowText
		Me.memLen1.HideSelection = True
		Me.memLen1.ReadOnly = False
		Me.memLen1.Maxlength = 0
		Me.memLen1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.memLen1.MultiLine = False
		Me.memLen1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.memLen1.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.memLen1.TabStop = True
		Me.memLen1.Visible = True
		Me.memLen1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.memLen1.Name = "memLen1"
		Me.memData1.AutoSize = False
		Me.memData1.Size = New System.Drawing.Size(313, 69)
		Me.memData1.Location = New System.Drawing.Point(70, 86)
		Me.memData1.MultiLine = True
		Me.memData1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.memData1.TabIndex = 4
		Me.memData1.AcceptsReturn = True
		Me.memData1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.memData1.BackColor = System.Drawing.SystemColors.Window
		Me.memData1.CausesValidation = True
		Me.memData1.Enabled = True
		Me.memData1.ForeColor = System.Drawing.SystemColors.WindowText
		Me.memData1.HideSelection = True
		Me.memData1.ReadOnly = False
		Me.memData1.Maxlength = 0
		Me.memData1.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.memData1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.memData1.TabStop = True
		Me.memData1.Visible = True
		Me.memData1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.memData1.Name = "memData1"
		Me.memRead1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.memRead1.Text = "Read"
		Me.memRead1.Size = New System.Drawing.Size(65, 25)
		Me.memRead1.Location = New System.Drawing.Point(243, 159)
		Me.memRead1.TabIndex = 3
		Me.memRead1.BackColor = System.Drawing.SystemColors.Control
		Me.memRead1.CausesValidation = True
		Me.memRead1.Enabled = True
		Me.memRead1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.memRead1.Cursor = System.Windows.Forms.Cursors.Default
		Me.memRead1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.memRead1.TabStop = True
		Me.memRead1.Name = "memRead1"
		Me.memWrite1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.memWrite1.Text = "Write"
		Me.memWrite1.Size = New System.Drawing.Size(65, 25)
		Me.memWrite1.Location = New System.Drawing.Point(314, 159)
		Me.memWrite1.TabIndex = 2
		Me.memWrite1.BackColor = System.Drawing.SystemColors.Control
		Me.memWrite1.CausesValidation = True
		Me.memWrite1.Enabled = True
		Me.memWrite1.ForeColor = System.Drawing.SystemColors.ControlText
		Me.memWrite1.Cursor = System.Windows.Forms.Cursors.Default
		Me.memWrite1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.memWrite1.TabStop = True
		Me.memWrite1.Name = "memWrite1"
		Me.Label13.Text = "����"
		Me.Label13.Size = New System.Drawing.Size(33, 17)
		Me.Label13.Location = New System.Drawing.Point(22, 60)
		Me.Label13.TabIndex = 10
		Me.Label13.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label13.BackColor = System.Drawing.SystemColors.Control
		Me.Label13.Enabled = True
		Me.Label13.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label13.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label13.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label13.UseMnemonic = True
		Me.Label13.Visible = True
		Me.Label13.AutoSize = False
		Me.Label13.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label13.Name = "Label13"
		Me.Label14.Text = "����"
		Me.Label14.Size = New System.Drawing.Size(41, 17)
		Me.Label14.Location = New System.Drawing.Point(22, 86)
		Me.Label14.TabIndex = 9
		Me.Label14.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label14.BackColor = System.Drawing.SystemColors.Control
		Me.Label14.Enabled = True
		Me.Label14.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label14.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label14.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label14.UseMnemonic = True
		Me.Label14.Visible = True
		Me.Label14.AutoSize = False
		Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label14.Name = "Label14"
		Me.Label15.Text = "MEM��ʽд��ַ1: WR#=0, DS#/RD#=1, AS#/ADDR=1, D0-D7=output"
		Me.Label15.Size = New System.Drawing.Size(377, 12)
		Me.Label15.Location = New System.Drawing.Point(25, 40)
		Me.Label15.TabIndex = 8
		Me.Label15.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label15.BackColor = System.Drawing.SystemColors.Control
		Me.Label15.Enabled = True
		Me.Label15.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label15.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label15.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label15.UseMnemonic = True
		Me.Label15.Visible = True
		Me.Label15.AutoSize = False
		Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label15.Name = "Label15"
		Me.Label16.Text = "MEM��ʽ����ַ1: WR#=1, DS#/RD#=0, AS#/ADDR=1, D0-D7=input"
		Me.Label16.Size = New System.Drawing.Size(369, 12)
		Me.Label16.Location = New System.Drawing.Point(25, 21)
		Me.Label16.TabIndex = 7
		Me.Label16.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label16.BackColor = System.Drawing.SystemColors.Control
		Me.Label16.Enabled = True
		Me.Label16.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label16.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label16.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label16.UseMnemonic = True
		Me.Label16.Visible = True
		Me.Label16.AutoSize = False
		Me.Label16.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label16.Name = "Label16"
		Me.Label23.Text = "(<1000H)"
		Me.Label23.Size = New System.Drawing.Size(57, 19)
		Me.Label23.Location = New System.Drawing.Point(237, 57)
		Me.Label23.TabIndex = 6
		Me.Label23.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label23.BackColor = System.Drawing.SystemColors.Control
		Me.Label23.Enabled = True
		Me.Label23.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label23.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label23.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label23.UseMnemonic = True
		Me.Label23.Visible = True
		Me.Label23.AutoSize = False
		Me.Label23.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label23.Name = "Label23"
		Me._SSTab1_TabPage2.Text = "I2C�ӿ�"
		Me.Frame5.Text = "����ģʽ��д����I2C������ͬ�����ڣ�API=USBIO_StreamI2C"
		Me.Frame5.Size = New System.Drawing.Size(465, 429)
		Me.Frame5.Location = New System.Drawing.Point(11, 30)
		Me.Frame5.TabIndex = 101
		Me.Frame5.BackColor = System.Drawing.SystemColors.Control
		Me.Frame5.Enabled = True
		Me.Frame5.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame5.Visible = True
		Me.Frame5.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame5.Name = "Frame5"
		Me.Frame17.Text = "����I2C/IIC���ߵĶ�д�ٶ�"
		Me.Frame17.Size = New System.Drawing.Size(441, 49)
		Me.Frame17.Location = New System.Drawing.Point(16, 360)
		Me.Frame17.TabIndex = 128
		Me.Frame17.BackColor = System.Drawing.SystemColors.Control
		Me.Frame17.Enabled = True
		Me.Frame17.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame17.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame17.Visible = True
		Me.Frame17.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame17.Name = "Frame17"
		Me._I2CM_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._I2CM_3.Text = "750KHz"
		Me._I2CM_3.Size = New System.Drawing.Size(65, 17)
		Me._I2CM_3.Location = New System.Drawing.Point(328, 24)
		Me._I2CM_3.TabIndex = 132
		Me._I2CM_3.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._I2CM_3.BackColor = System.Drawing.SystemColors.Control
		Me._I2CM_3.CausesValidation = True
		Me._I2CM_3.Enabled = True
		Me._I2CM_3.ForeColor = System.Drawing.SystemColors.ControlText
		Me._I2CM_3.Cursor = System.Windows.Forms.Cursors.Default
		Me._I2CM_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._I2CM_3.Appearance = System.Windows.Forms.Appearance.Normal
		Me._I2CM_3.TabStop = True
		Me._I2CM_3.Checked = False
		Me._I2CM_3.Visible = True
		Me._I2CM_3.Name = "_I2CM_3"
		Me._I2CM_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._I2CM_2.Text = "400KHz"
		Me._I2CM_2.Size = New System.Drawing.Size(65, 17)
		Me._I2CM_2.Location = New System.Drawing.Point(232, 24)
		Me._I2CM_2.TabIndex = 131
		Me._I2CM_2.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._I2CM_2.BackColor = System.Drawing.SystemColors.Control
		Me._I2CM_2.CausesValidation = True
		Me._I2CM_2.Enabled = True
		Me._I2CM_2.ForeColor = System.Drawing.SystemColors.ControlText
		Me._I2CM_2.Cursor = System.Windows.Forms.Cursors.Default
		Me._I2CM_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._I2CM_2.Appearance = System.Windows.Forms.Appearance.Normal
		Me._I2CM_2.TabStop = True
		Me._I2CM_2.Checked = False
		Me._I2CM_2.Visible = True
		Me._I2CM_2.Name = "_I2CM_2"
		Me._I2CM_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._I2CM_1.Text = "100KHz"
		Me._I2CM_1.Size = New System.Drawing.Size(65, 17)
		Me._I2CM_1.Location = New System.Drawing.Point(144, 24)
		Me._I2CM_1.TabIndex = 130
		Me._I2CM_1.Checked = True
		Me._I2CM_1.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._I2CM_1.BackColor = System.Drawing.SystemColors.Control
		Me._I2CM_1.CausesValidation = True
		Me._I2CM_1.Enabled = True
		Me._I2CM_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._I2CM_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._I2CM_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._I2CM_1.Appearance = System.Windows.Forms.Appearance.Normal
		Me._I2CM_1.TabStop = True
		Me._I2CM_1.Visible = True
		Me._I2CM_1.Name = "_I2CM_1"
		Me._I2CM_0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._I2CM_0.Text = "20KHz"
		Me._I2CM_0.Size = New System.Drawing.Size(57, 17)
		Me._I2CM_0.Location = New System.Drawing.Point(56, 24)
		Me._I2CM_0.TabIndex = 129
		Me._I2CM_0.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._I2CM_0.BackColor = System.Drawing.SystemColors.Control
		Me._I2CM_0.CausesValidation = True
		Me._I2CM_0.Enabled = True
		Me._I2CM_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._I2CM_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._I2CM_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._I2CM_0.Appearance = System.Windows.Forms.Appearance.Normal
		Me._I2CM_0.TabStop = True
		Me._I2CM_0.Checked = False
		Me._I2CM_0.Visible = True
		Me._I2CM_0.Name = "_I2CM_0"
		Me.Frame7.Text = "д������"
		Me.Frame7.Size = New System.Drawing.Size(440, 167)
		Me.Frame7.Location = New System.Drawing.Point(14, 16)
		Me.Frame7.TabIndex = 108
		Me.Frame7.BackColor = System.Drawing.SystemColors.Control
		Me.Frame7.Enabled = True
		Me.Frame7.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame7.Visible = True
		Me.Frame7.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame7.Name = "Frame7"
		Me.StreamICRW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.StreamICRW.Text = "Write\Read"
		Me.StreamICRW.Size = New System.Drawing.Size(79, 25)
		Me.StreamICRW.Location = New System.Drawing.Point(305, 22)
		Me.StreamICRW.TabIndex = 114
		Me.StreamICRW.BackColor = System.Drawing.SystemColors.Control
		Me.StreamICRW.CausesValidation = True
		Me.StreamICRW.Enabled = True
		Me.StreamICRW.ForeColor = System.Drawing.SystemColors.ControlText
		Me.StreamICRW.Cursor = System.Windows.Forms.Cursors.Default
		Me.StreamICRW.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.StreamICRW.TabStop = True
		Me.StreamICRW.Name = "StreamICRW"
		Me.I2CWRBuf.AutoSize = False
		Me.I2CWRBuf.Size = New System.Drawing.Size(313, 102)
		Me.I2CWRBuf.Location = New System.Drawing.Point(75, 56)
		Me.I2CWRBuf.MultiLine = True
		Me.I2CWRBuf.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.I2CWRBuf.TabIndex = 110
		Me.I2CWRBuf.AcceptsReturn = True
		Me.I2CWRBuf.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.I2CWRBuf.BackColor = System.Drawing.SystemColors.Window
		Me.I2CWRBuf.CausesValidation = True
		Me.I2CWRBuf.Enabled = True
		Me.I2CWRBuf.ForeColor = System.Drawing.SystemColors.WindowText
		Me.I2CWRBuf.HideSelection = True
		Me.I2CWRBuf.ReadOnly = False
		Me.I2CWRBuf.Maxlength = 0
		Me.I2CWRBuf.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.I2CWRBuf.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.I2CWRBuf.TabStop = True
		Me.I2CWRBuf.Visible = True
		Me.I2CWRBuf.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.I2CWRBuf.Name = "I2CWRBuf"
		Me.I2CWRLen.AutoSize = False
		Me.I2CWRLen.Size = New System.Drawing.Size(161, 25)
		Me.I2CWRLen.Location = New System.Drawing.Point(76, 22)
		Me.I2CWRLen.TabIndex = 109
		Me.I2CWRLen.AcceptsReturn = True
		Me.I2CWRLen.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.I2CWRLen.BackColor = System.Drawing.SystemColors.Window
		Me.I2CWRLen.CausesValidation = True
		Me.I2CWRLen.Enabled = True
		Me.I2CWRLen.ForeColor = System.Drawing.SystemColors.WindowText
		Me.I2CWRLen.HideSelection = True
		Me.I2CWRLen.ReadOnly = False
		Me.I2CWRLen.Maxlength = 0
		Me.I2CWRLen.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.I2CWRLen.MultiLine = False
		Me.I2CWRLen.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.I2CWRLen.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.I2CWRLen.TabStop = True
		Me.I2CWRLen.Visible = True
		Me.I2CWRLen.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.I2CWRLen.Name = "I2CWRLen"
		Me.Label17.Text = "����"
		Me.Label17.Size = New System.Drawing.Size(41, 17)
		Me.Label17.Location = New System.Drawing.Point(20, 56)
		Me.Label17.TabIndex = 113
		Me.Label17.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label17.BackColor = System.Drawing.SystemColors.Control
		Me.Label17.Enabled = True
		Me.Label17.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label17.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label17.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label17.UseMnemonic = True
		Me.Label17.Visible = True
		Me.Label17.AutoSize = False
		Me.Label17.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label17.Name = "Label17"
		Me.Label24.Text = "����"
		Me.Label24.Size = New System.Drawing.Size(33, 17)
		Me.Label24.Location = New System.Drawing.Point(20, 26)
		Me.Label24.TabIndex = 112
		Me.Label24.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label24.BackColor = System.Drawing.SystemColors.Control
		Me.Label24.Enabled = True
		Me.Label24.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label24.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label24.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label24.UseMnemonic = True
		Me.Label24.Visible = True
		Me.Label24.AutoSize = False
		Me.Label24.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label24.Name = "Label24"
		Me.Label25.Text = "(<400H)"
		Me.Label25.Size = New System.Drawing.Size(57, 12)
		Me.Label25.Location = New System.Drawing.Point(242, 29)
		Me.Label25.TabIndex = 111
		Me.Label25.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label25.BackColor = System.Drawing.SystemColors.Control
		Me.Label25.Enabled = True
		Me.Label25.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label25.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label25.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label25.UseMnemonic = True
		Me.Label25.Visible = True
		Me.Label25.AutoSize = False
		Me.Label25.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label25.Name = "Label25"
		Me.Frame6.Text = "��ȡ����"
		Me.Frame6.Size = New System.Drawing.Size(440, 167)
		Me.Frame6.Location = New System.Drawing.Point(16, 184)
		Me.Frame6.TabIndex = 102
		Me.Frame6.BackColor = System.Drawing.SystemColors.Control
		Me.Frame6.Enabled = True
		Me.Frame6.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame6.Visible = True
		Me.Frame6.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame6.Name = "Frame6"
		Me.I2CRDLen.AutoSize = False
		Me.I2CRDLen.Size = New System.Drawing.Size(161, 25)
		Me.I2CRDLen.Location = New System.Drawing.Point(70, 21)
		Me.I2CRDLen.TabIndex = 104
		Me.I2CRDLen.AcceptsReturn = True
		Me.I2CRDLen.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.I2CRDLen.BackColor = System.Drawing.SystemColors.Window
		Me.I2CRDLen.CausesValidation = True
		Me.I2CRDLen.Enabled = True
		Me.I2CRDLen.ForeColor = System.Drawing.SystemColors.WindowText
		Me.I2CRDLen.HideSelection = True
		Me.I2CRDLen.ReadOnly = False
		Me.I2CRDLen.Maxlength = 0
		Me.I2CRDLen.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.I2CRDLen.MultiLine = False
		Me.I2CRDLen.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.I2CRDLen.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.I2CRDLen.TabStop = True
		Me.I2CRDLen.Visible = True
		Me.I2CRDLen.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.I2CRDLen.Name = "I2CRDLen"
		Me.I2CRDBuf.AutoSize = False
		Me.I2CRDBuf.Size = New System.Drawing.Size(313, 102)
		Me.I2CRDBuf.Location = New System.Drawing.Point(70, 55)
		Me.I2CRDBuf.MultiLine = True
		Me.I2CRDBuf.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.I2CRDBuf.TabIndex = 103
		Me.I2CRDBuf.AcceptsReturn = True
		Me.I2CRDBuf.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.I2CRDBuf.BackColor = System.Drawing.SystemColors.Window
		Me.I2CRDBuf.CausesValidation = True
		Me.I2CRDBuf.Enabled = True
		Me.I2CRDBuf.ForeColor = System.Drawing.SystemColors.WindowText
		Me.I2CRDBuf.HideSelection = True
		Me.I2CRDBuf.ReadOnly = False
		Me.I2CRDBuf.Maxlength = 0
		Me.I2CRDBuf.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.I2CRDBuf.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.I2CRDBuf.TabStop = True
		Me.I2CRDBuf.Visible = True
		Me.I2CRDBuf.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.I2CRDBuf.Name = "I2CRDBuf"
		Me.Label26.Text = "����"
		Me.Label26.Size = New System.Drawing.Size(33, 17)
		Me.Label26.Location = New System.Drawing.Point(22, 25)
		Me.Label26.TabIndex = 107
		Me.Label26.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label26.BackColor = System.Drawing.SystemColors.Control
		Me.Label26.Enabled = True
		Me.Label26.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label26.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label26.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label26.UseMnemonic = True
		Me.Label26.Visible = True
		Me.Label26.AutoSize = False
		Me.Label26.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label26.Name = "Label26"
		Me.Label27.Text = "����"
		Me.Label27.Size = New System.Drawing.Size(41, 17)
		Me.Label27.Location = New System.Drawing.Point(22, 55)
		Me.Label27.TabIndex = 106
		Me.Label27.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label27.BackColor = System.Drawing.SystemColors.Control
		Me.Label27.Enabled = True
		Me.Label27.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label27.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label27.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label27.UseMnemonic = True
		Me.Label27.Visible = True
		Me.Label27.AutoSize = False
		Me.Label27.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label27.Name = "Label27"
		Me.Label30.Text = "(<400H)"
		Me.Label30.Size = New System.Drawing.Size(57, 12)
		Me.Label30.Location = New System.Drawing.Point(237, 28)
		Me.Label30.TabIndex = 105
		Me.Label30.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label30.BackColor = System.Drawing.SystemColors.Control
		Me.Label30.Enabled = True
		Me.Label30.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label30.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label30.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label30.UseMnemonic = True
		Me.Label30.Visible = True
		Me.Label30.AutoSize = False
		Me.Label30.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label30.Name = "Label30"
		Me._SSTab1_TabPage3.Text = "EEPROM��д"
		Me.Frame8.Text = "д�����ݣ�API=USBIO_WriteEEPROM"
		Me.Frame8.Size = New System.Drawing.Size(361, 212)
		Me.Frame8.Location = New System.Drawing.Point(119, 28)
		Me.Frame8.TabIndex = 64
		Me.Frame8.BackColor = System.Drawing.SystemColors.Control
		Me.Frame8.Enabled = True
		Me.Frame8.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame8.Visible = True
		Me.Frame8.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame8.Name = "Frame8"
		Me.WrDataLen.AutoSize = False
		Me.WrDataLen.Size = New System.Drawing.Size(161, 25)
		Me.WrDataLen.Location = New System.Drawing.Point(23, 87)
		Me.WrDataLen.TabIndex = 68
		Me.WrDataLen.Text = "0"
		Me.WrDataLen.AcceptsReturn = True
		Me.WrDataLen.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.WrDataLen.BackColor = System.Drawing.SystemColors.Window
		Me.WrDataLen.CausesValidation = True
		Me.WrDataLen.Enabled = True
		Me.WrDataLen.ForeColor = System.Drawing.SystemColors.WindowText
		Me.WrDataLen.HideSelection = True
		Me.WrDataLen.ReadOnly = False
		Me.WrDataLen.Maxlength = 0
		Me.WrDataLen.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.WrDataLen.MultiLine = False
		Me.WrDataLen.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.WrDataLen.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.WrDataLen.TabStop = True
		Me.WrDataLen.Visible = True
		Me.WrDataLen.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.WrDataLen.Name = "WrDataLen"
		Me.WrDataBuf.AutoSize = False
		Me.WrDataBuf.Size = New System.Drawing.Size(313, 69)
		Me.WrDataBuf.Location = New System.Drawing.Point(23, 133)
		Me.WrDataBuf.MultiLine = True
		Me.WrDataBuf.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.WrDataBuf.TabIndex = 67
		Me.WrDataBuf.AcceptsReturn = True
		Me.WrDataBuf.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.WrDataBuf.BackColor = System.Drawing.SystemColors.Window
		Me.WrDataBuf.CausesValidation = True
		Me.WrDataBuf.Enabled = True
		Me.WrDataBuf.ForeColor = System.Drawing.SystemColors.WindowText
		Me.WrDataBuf.HideSelection = True
		Me.WrDataBuf.ReadOnly = False
		Me.WrDataBuf.Maxlength = 0
		Me.WrDataBuf.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.WrDataBuf.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.WrDataBuf.TabStop = True
		Me.WrDataBuf.Visible = True
		Me.WrDataBuf.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.WrDataBuf.Name = "WrDataBuf"
		Me.WrDataAddr.AutoSize = False
		Me.WrDataAddr.Size = New System.Drawing.Size(161, 25)
		Me.WrDataAddr.Location = New System.Drawing.Point(22, 38)
		Me.WrDataAddr.TabIndex = 66
		Me.WrDataAddr.Text = "0"
		Me.WrDataAddr.AcceptsReturn = True
		Me.WrDataAddr.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.WrDataAddr.BackColor = System.Drawing.SystemColors.Window
		Me.WrDataAddr.CausesValidation = True
		Me.WrDataAddr.Enabled = True
		Me.WrDataAddr.ForeColor = System.Drawing.SystemColors.WindowText
		Me.WrDataAddr.HideSelection = True
		Me.WrDataAddr.ReadOnly = False
		Me.WrDataAddr.Maxlength = 0
		Me.WrDataAddr.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.WrDataAddr.MultiLine = False
		Me.WrDataAddr.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.WrDataAddr.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.WrDataAddr.TabStop = True
		Me.WrDataAddr.Visible = True
		Me.WrDataAddr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.WrDataAddr.Name = "WrDataAddr"
		Me.eepromWrDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.eepromWrDate.Text = "Write"
		Me.eepromWrDate.Size = New System.Drawing.Size(65, 25)
		Me.eepromWrDate.Location = New System.Drawing.Point(269, 82)
		Me.eepromWrDate.TabIndex = 65
		Me.eepromWrDate.BackColor = System.Drawing.SystemColors.Control
		Me.eepromWrDate.CausesValidation = True
		Me.eepromWrDate.Enabled = True
		Me.eepromWrDate.ForeColor = System.Drawing.SystemColors.ControlText
		Me.eepromWrDate.Cursor = System.Windows.Forms.Cursors.Default
		Me.eepromWrDate.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.eepromWrDate.TabStop = True
		Me.eepromWrDate.Name = "eepromWrDate"
		Me.Label38.Text = "д�볤��"
		Me.Label38.Size = New System.Drawing.Size(54, 17)
		Me.Label38.Location = New System.Drawing.Point(22, 68)
		Me.Label38.TabIndex = 72
		Me.Label38.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label38.BackColor = System.Drawing.SystemColors.Control
		Me.Label38.Enabled = True
		Me.Label38.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label38.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label38.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label38.UseMnemonic = True
		Me.Label38.Visible = True
		Me.Label38.AutoSize = False
		Me.Label38.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label38.Name = "Label38"
		Me.Label37.Text = "(<400H)"
		Me.Label37.Size = New System.Drawing.Size(51, 17)
		Me.Label37.Location = New System.Drawing.Point(75, 68)
		Me.Label37.TabIndex = 71
		Me.Label37.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label37.BackColor = System.Drawing.SystemColors.Control
		Me.Label37.Enabled = True
		Me.Label37.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label37.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label37.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label37.UseMnemonic = True
		Me.Label37.Visible = True
		Me.Label37.AutoSize = False
		Me.Label37.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label37.Name = "Label37"
		Me.Label36.Text = "������ݣ�16���ƣ����ַ�һ�飩"
		Me.Label36.Size = New System.Drawing.Size(205, 15)
		Me.Label36.Location = New System.Drawing.Point(22, 115)
		Me.Label36.TabIndex = 70
		Me.Label36.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label36.BackColor = System.Drawing.SystemColors.Control
		Me.Label36.Enabled = True
		Me.Label36.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label36.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label36.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label36.UseMnemonic = True
		Me.Label36.Visible = True
		Me.Label36.AutoSize = False
		Me.Label36.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label36.Name = "Label36"
		Me.Label33.Text = "���ݵ�Ԫ��ʼ��ַ"
		Me.Label33.Size = New System.Drawing.Size(110, 17)
		Me.Label33.Location = New System.Drawing.Point(21, 18)
		Me.Label33.TabIndex = 69
		Me.Label33.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label33.BackColor = System.Drawing.SystemColors.Control
		Me.Label33.Enabled = True
		Me.Label33.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label33.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label33.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label33.UseMnemonic = True
		Me.Label33.Visible = True
		Me.Label33.AutoSize = False
		Me.Label33.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label33.Name = "Label33"
		Me.Frame9.Text = "�������ݣ�API=USBIO_ReadEEPROM"
		Me.Frame9.Size = New System.Drawing.Size(361, 212)
		Me.Frame9.Location = New System.Drawing.Point(118, 243)
		Me.Frame9.TabIndex = 55
		Me.Frame9.BackColor = System.Drawing.SystemColors.Control
		Me.Frame9.Enabled = True
		Me.Frame9.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame9.Visible = True
		Me.Frame9.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame9.Name = "Frame9"
		Me.eepromRdDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.eepromRdDate.Text = "Read"
		Me.eepromRdDate.Size = New System.Drawing.Size(65, 25)
		Me.eepromRdDate.Location = New System.Drawing.Point(269, 83)
		Me.eepromRdDate.TabIndex = 59
		Me.eepromRdDate.BackColor = System.Drawing.SystemColors.Control
		Me.eepromRdDate.CausesValidation = True
		Me.eepromRdDate.Enabled = True
		Me.eepromRdDate.ForeColor = System.Drawing.SystemColors.ControlText
		Me.eepromRdDate.Cursor = System.Windows.Forms.Cursors.Default
		Me.eepromRdDate.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.eepromRdDate.TabStop = True
		Me.eepromRdDate.Name = "eepromRdDate"
		Me.RdDataAddr.AutoSize = False
		Me.RdDataAddr.Size = New System.Drawing.Size(161, 25)
		Me.RdDataAddr.Location = New System.Drawing.Point(21, 36)
		Me.RdDataAddr.TabIndex = 58
		Me.RdDataAddr.Text = "0"
		Me.RdDataAddr.AcceptsReturn = True
		Me.RdDataAddr.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.RdDataAddr.BackColor = System.Drawing.SystemColors.Window
		Me.RdDataAddr.CausesValidation = True
		Me.RdDataAddr.Enabled = True
		Me.RdDataAddr.ForeColor = System.Drawing.SystemColors.WindowText
		Me.RdDataAddr.HideSelection = True
		Me.RdDataAddr.ReadOnly = False
		Me.RdDataAddr.Maxlength = 0
		Me.RdDataAddr.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.RdDataAddr.MultiLine = False
		Me.RdDataAddr.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.RdDataAddr.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.RdDataAddr.TabStop = True
		Me.RdDataAddr.Visible = True
		Me.RdDataAddr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.RdDataAddr.Name = "RdDataAddr"
		Me.RdDataBuf.AutoSize = False
		Me.RdDataBuf.Size = New System.Drawing.Size(313, 69)
		Me.RdDataBuf.Location = New System.Drawing.Point(21, 133)
		Me.RdDataBuf.MultiLine = True
		Me.RdDataBuf.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.RdDataBuf.TabIndex = 57
		Me.RdDataBuf.AcceptsReturn = True
		Me.RdDataBuf.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.RdDataBuf.BackColor = System.Drawing.SystemColors.Window
		Me.RdDataBuf.CausesValidation = True
		Me.RdDataBuf.Enabled = True
		Me.RdDataBuf.ForeColor = System.Drawing.SystemColors.WindowText
		Me.RdDataBuf.HideSelection = True
		Me.RdDataBuf.ReadOnly = False
		Me.RdDataBuf.Maxlength = 0
		Me.RdDataBuf.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.RdDataBuf.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.RdDataBuf.TabStop = True
		Me.RdDataBuf.Visible = True
		Me.RdDataBuf.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.RdDataBuf.Name = "RdDataBuf"
		Me.RdDataLen.AutoSize = False
		Me.RdDataLen.Size = New System.Drawing.Size(161, 25)
		Me.RdDataLen.Location = New System.Drawing.Point(21, 87)
		Me.RdDataLen.TabIndex = 56
		Me.RdDataLen.Text = "0"
		Me.RdDataLen.AcceptsReturn = True
		Me.RdDataLen.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.RdDataLen.BackColor = System.Drawing.SystemColors.Window
		Me.RdDataLen.CausesValidation = True
		Me.RdDataLen.Enabled = True
		Me.RdDataLen.ForeColor = System.Drawing.SystemColors.WindowText
		Me.RdDataLen.HideSelection = True
		Me.RdDataLen.ReadOnly = False
		Me.RdDataLen.Maxlength = 0
		Me.RdDataLen.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.RdDataLen.MultiLine = False
		Me.RdDataLen.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.RdDataLen.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.RdDataLen.TabStop = True
		Me.RdDataLen.Visible = True
		Me.RdDataLen.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.RdDataLen.Name = "RdDataLen"
		Me.Label39.Text = "���ݵ�Ԫ��ʼ��ַ"
		Me.Label39.Size = New System.Drawing.Size(110, 17)
		Me.Label39.Location = New System.Drawing.Point(21, 18)
		Me.Label39.TabIndex = 63
		Me.Label39.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label39.BackColor = System.Drawing.SystemColors.Control
		Me.Label39.Enabled = True
		Me.Label39.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label39.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label39.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label39.UseMnemonic = True
		Me.Label39.Visible = True
		Me.Label39.AutoSize = False
		Me.Label39.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label39.Name = "Label39"
		Me.Label35.Text = "������ݣ�16���ƣ����ַ�һ�飩"
		Me.Label35.Size = New System.Drawing.Size(205, 15)
		Me.Label35.Location = New System.Drawing.Point(22, 115)
		Me.Label35.TabIndex = 62
		Me.Label35.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label35.BackColor = System.Drawing.SystemColors.Control
		Me.Label35.Enabled = True
		Me.Label35.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label35.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label35.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label35.UseMnemonic = True
		Me.Label35.Visible = True
		Me.Label35.AutoSize = False
		Me.Label35.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label35.Name = "Label35"
		Me.Label34.Text = "(<400H)"
		Me.Label34.Size = New System.Drawing.Size(51, 17)
		Me.Label34.Location = New System.Drawing.Point(75, 68)
		Me.Label34.TabIndex = 61
		Me.Label34.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label34.BackColor = System.Drawing.SystemColors.Control
		Me.Label34.Enabled = True
		Me.Label34.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label34.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label34.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label34.UseMnemonic = True
		Me.Label34.Visible = True
		Me.Label34.AutoSize = False
		Me.Label34.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label34.Name = "Label34"
		Me.Label32.Text = "��ȡ����"
		Me.Label32.Size = New System.Drawing.Size(53, 17)
		Me.Label32.Location = New System.Drawing.Point(22, 68)
		Me.Label32.TabIndex = 60
		Me.Label32.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label32.BackColor = System.Drawing.SystemColors.Control
		Me.Label32.Enabled = True
		Me.Label32.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label32.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label32.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label32.UseMnemonic = True
		Me.Label32.Visible = True
		Me.Label32.AutoSize = False
		Me.Label32.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label32.Name = "Label32"
		Me.Frame10.Text = "EEPROM�ͺ�"
		Me.Frame10.Size = New System.Drawing.Size(108, 427)
		Me.Frame10.Location = New System.Drawing.Point(7, 28)
		Me.Frame10.TabIndex = 41
		Me.Frame10.BackColor = System.Drawing.SystemColors.Control
		Me.Frame10.Enabled = True
		Me.Frame10.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame10.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame10.Visible = True
		Me.Frame10.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame10.Name = "Frame10"
		Me._eppromtype_12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_12.Text = "24C4096"
		Me._eppromtype_12.Size = New System.Drawing.Size(88, 17)
		Me._eppromtype_12.Location = New System.Drawing.Point(12, 346)
		Me._eppromtype_12.TabIndex = 54
		Me._eppromtype_12.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_12.BackColor = System.Drawing.SystemColors.Control
		Me._eppromtype_12.CausesValidation = True
		Me._eppromtype_12.Enabled = True
		Me._eppromtype_12.ForeColor = System.Drawing.SystemColors.ControlText
		Me._eppromtype_12.Cursor = System.Windows.Forms.Cursors.Default
		Me._eppromtype_12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._eppromtype_12.Appearance = System.Windows.Forms.Appearance.Normal
		Me._eppromtype_12.TabStop = True
		Me._eppromtype_12.Checked = False
		Me._eppromtype_12.Visible = True
		Me._eppromtype_12.Name = "_eppromtype_12"
		Me._eppromtype_11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_11.Text = "24C2048"
		Me._eppromtype_11.Size = New System.Drawing.Size(88, 17)
		Me._eppromtype_11.Location = New System.Drawing.Point(12, 319)
		Me._eppromtype_11.TabIndex = 53
		Me._eppromtype_11.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_11.BackColor = System.Drawing.SystemColors.Control
		Me._eppromtype_11.CausesValidation = True
		Me._eppromtype_11.Enabled = True
		Me._eppromtype_11.ForeColor = System.Drawing.SystemColors.ControlText
		Me._eppromtype_11.Cursor = System.Windows.Forms.Cursors.Default
		Me._eppromtype_11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._eppromtype_11.Appearance = System.Windows.Forms.Appearance.Normal
		Me._eppromtype_11.TabStop = True
		Me._eppromtype_11.Checked = False
		Me._eppromtype_11.Visible = True
		Me._eppromtype_11.Name = "_eppromtype_11"
		Me._eppromtype_10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_10.Text = "24C1024"
		Me._eppromtype_10.Size = New System.Drawing.Size(88, 17)
		Me._eppromtype_10.Location = New System.Drawing.Point(12, 292)
		Me._eppromtype_10.TabIndex = 52
		Me._eppromtype_10.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_10.BackColor = System.Drawing.SystemColors.Control
		Me._eppromtype_10.CausesValidation = True
		Me._eppromtype_10.Enabled = True
		Me._eppromtype_10.ForeColor = System.Drawing.SystemColors.ControlText
		Me._eppromtype_10.Cursor = System.Windows.Forms.Cursors.Default
		Me._eppromtype_10.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._eppromtype_10.Appearance = System.Windows.Forms.Appearance.Normal
		Me._eppromtype_10.TabStop = True
		Me._eppromtype_10.Checked = False
		Me._eppromtype_10.Visible = True
		Me._eppromtype_10.Name = "_eppromtype_10"
		Me._eppromtype_9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_9.Text = "24C512"
		Me._eppromtype_9.Size = New System.Drawing.Size(88, 17)
		Me._eppromtype_9.Location = New System.Drawing.Point(12, 265)
		Me._eppromtype_9.TabIndex = 51
		Me._eppromtype_9.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_9.BackColor = System.Drawing.SystemColors.Control
		Me._eppromtype_9.CausesValidation = True
		Me._eppromtype_9.Enabled = True
		Me._eppromtype_9.ForeColor = System.Drawing.SystemColors.ControlText
		Me._eppromtype_9.Cursor = System.Windows.Forms.Cursors.Default
		Me._eppromtype_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._eppromtype_9.Appearance = System.Windows.Forms.Appearance.Normal
		Me._eppromtype_9.TabStop = True
		Me._eppromtype_9.Checked = False
		Me._eppromtype_9.Visible = True
		Me._eppromtype_9.Name = "_eppromtype_9"
		Me._eppromtype_8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_8.Text = "24C256"
		Me._eppromtype_8.Size = New System.Drawing.Size(88, 17)
		Me._eppromtype_8.Location = New System.Drawing.Point(12, 238)
		Me._eppromtype_8.TabIndex = 50
		Me._eppromtype_8.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_8.BackColor = System.Drawing.SystemColors.Control
		Me._eppromtype_8.CausesValidation = True
		Me._eppromtype_8.Enabled = True
		Me._eppromtype_8.ForeColor = System.Drawing.SystemColors.ControlText
		Me._eppromtype_8.Cursor = System.Windows.Forms.Cursors.Default
		Me._eppromtype_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._eppromtype_8.Appearance = System.Windows.Forms.Appearance.Normal
		Me._eppromtype_8.TabStop = True
		Me._eppromtype_8.Checked = False
		Me._eppromtype_8.Visible = True
		Me._eppromtype_8.Name = "_eppromtype_8"
		Me._eppromtype_7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_7.Text = "24C128"
		Me._eppromtype_7.Size = New System.Drawing.Size(88, 17)
		Me._eppromtype_7.Location = New System.Drawing.Point(12, 210)
		Me._eppromtype_7.TabIndex = 49
		Me._eppromtype_7.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_7.BackColor = System.Drawing.SystemColors.Control
		Me._eppromtype_7.CausesValidation = True
		Me._eppromtype_7.Enabled = True
		Me._eppromtype_7.ForeColor = System.Drawing.SystemColors.ControlText
		Me._eppromtype_7.Cursor = System.Windows.Forms.Cursors.Default
		Me._eppromtype_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._eppromtype_7.Appearance = System.Windows.Forms.Appearance.Normal
		Me._eppromtype_7.TabStop = True
		Me._eppromtype_7.Checked = False
		Me._eppromtype_7.Visible = True
		Me._eppromtype_7.Name = "_eppromtype_7"
		Me._eppromtype_6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_6.Text = "24C64"
		Me._eppromtype_6.Size = New System.Drawing.Size(88, 17)
		Me._eppromtype_6.Location = New System.Drawing.Point(12, 183)
		Me._eppromtype_6.TabIndex = 48
		Me._eppromtype_6.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_6.BackColor = System.Drawing.SystemColors.Control
		Me._eppromtype_6.CausesValidation = True
		Me._eppromtype_6.Enabled = True
		Me._eppromtype_6.ForeColor = System.Drawing.SystemColors.ControlText
		Me._eppromtype_6.Cursor = System.Windows.Forms.Cursors.Default
		Me._eppromtype_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._eppromtype_6.Appearance = System.Windows.Forms.Appearance.Normal
		Me._eppromtype_6.TabStop = True
		Me._eppromtype_6.Checked = False
		Me._eppromtype_6.Visible = True
		Me._eppromtype_6.Name = "_eppromtype_6"
		Me._eppromtype_5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_5.Text = "24C32"
		Me._eppromtype_5.Size = New System.Drawing.Size(88, 17)
		Me._eppromtype_5.Location = New System.Drawing.Point(12, 156)
		Me._eppromtype_5.TabIndex = 47
		Me._eppromtype_5.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_5.BackColor = System.Drawing.SystemColors.Control
		Me._eppromtype_5.CausesValidation = True
		Me._eppromtype_5.Enabled = True
		Me._eppromtype_5.ForeColor = System.Drawing.SystemColors.ControlText
		Me._eppromtype_5.Cursor = System.Windows.Forms.Cursors.Default
		Me._eppromtype_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._eppromtype_5.Appearance = System.Windows.Forms.Appearance.Normal
		Me._eppromtype_5.TabStop = True
		Me._eppromtype_5.Checked = False
		Me._eppromtype_5.Visible = True
		Me._eppromtype_5.Name = "_eppromtype_5"
		Me._eppromtype_4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_4.Text = "24C16"
		Me._eppromtype_4.Size = New System.Drawing.Size(88, 17)
		Me._eppromtype_4.Location = New System.Drawing.Point(12, 129)
		Me._eppromtype_4.TabIndex = 46
		Me._eppromtype_4.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_4.BackColor = System.Drawing.SystemColors.Control
		Me._eppromtype_4.CausesValidation = True
		Me._eppromtype_4.Enabled = True
		Me._eppromtype_4.ForeColor = System.Drawing.SystemColors.ControlText
		Me._eppromtype_4.Cursor = System.Windows.Forms.Cursors.Default
		Me._eppromtype_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._eppromtype_4.Appearance = System.Windows.Forms.Appearance.Normal
		Me._eppromtype_4.TabStop = True
		Me._eppromtype_4.Checked = False
		Me._eppromtype_4.Visible = True
		Me._eppromtype_4.Name = "_eppromtype_4"
		Me._eppromtype_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_3.Text = "24C08"
		Me._eppromtype_3.Size = New System.Drawing.Size(88, 17)
		Me._eppromtype_3.Location = New System.Drawing.Point(12, 102)
		Me._eppromtype_3.TabIndex = 45
		Me._eppromtype_3.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_3.BackColor = System.Drawing.SystemColors.Control
		Me._eppromtype_3.CausesValidation = True
		Me._eppromtype_3.Enabled = True
		Me._eppromtype_3.ForeColor = System.Drawing.SystemColors.ControlText
		Me._eppromtype_3.Cursor = System.Windows.Forms.Cursors.Default
		Me._eppromtype_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._eppromtype_3.Appearance = System.Windows.Forms.Appearance.Normal
		Me._eppromtype_3.TabStop = True
		Me._eppromtype_3.Checked = False
		Me._eppromtype_3.Visible = True
		Me._eppromtype_3.Name = "_eppromtype_3"
		Me._eppromtype_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_2.Text = "24C04"
		Me._eppromtype_2.Size = New System.Drawing.Size(88, 17)
		Me._eppromtype_2.Location = New System.Drawing.Point(12, 75)
		Me._eppromtype_2.TabIndex = 44
		Me._eppromtype_2.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_2.BackColor = System.Drawing.SystemColors.Control
		Me._eppromtype_2.CausesValidation = True
		Me._eppromtype_2.Enabled = True
		Me._eppromtype_2.ForeColor = System.Drawing.SystemColors.ControlText
		Me._eppromtype_2.Cursor = System.Windows.Forms.Cursors.Default
		Me._eppromtype_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._eppromtype_2.Appearance = System.Windows.Forms.Appearance.Normal
		Me._eppromtype_2.TabStop = True
		Me._eppromtype_2.Checked = False
		Me._eppromtype_2.Visible = True
		Me._eppromtype_2.Name = "_eppromtype_2"
		Me._eppromtype_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_1.Text = "24C02"
		Me._eppromtype_1.Size = New System.Drawing.Size(88, 17)
		Me._eppromtype_1.Location = New System.Drawing.Point(11, 48)
		Me._eppromtype_1.TabIndex = 43
		Me._eppromtype_1.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_1.BackColor = System.Drawing.SystemColors.Control
		Me._eppromtype_1.CausesValidation = True
		Me._eppromtype_1.Enabled = True
		Me._eppromtype_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._eppromtype_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._eppromtype_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._eppromtype_1.Appearance = System.Windows.Forms.Appearance.Normal
		Me._eppromtype_1.TabStop = True
		Me._eppromtype_1.Checked = False
		Me._eppromtype_1.Visible = True
		Me._eppromtype_1.Name = "_eppromtype_1"
		Me._eppromtype_0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_0.Text = "24C01"
		Me._eppromtype_0.Size = New System.Drawing.Size(88, 17)
		Me._eppromtype_0.Location = New System.Drawing.Point(12, 20)
		Me._eppromtype_0.TabIndex = 42
		Me._eppromtype_0.Checked = True
		Me._eppromtype_0.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._eppromtype_0.BackColor = System.Drawing.SystemColors.Control
		Me._eppromtype_0.CausesValidation = True
		Me._eppromtype_0.Enabled = True
		Me._eppromtype_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._eppromtype_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._eppromtype_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._eppromtype_0.Appearance = System.Windows.Forms.Appearance.Normal
		Me._eppromtype_0.TabStop = True
		Me._eppromtype_0.Visible = True
		Me._eppromtype_0.Name = "_eppromtype_0"
		Me._SSTab1_TabPage4.Text = "����I/O"
		Me.Frame11.Size = New System.Drawing.Size(476, 409)
		Me.Frame11.Location = New System.Drawing.Point(5, 32)
		Me.Frame11.TabIndex = 73
		Me.Frame11.BackColor = System.Drawing.SystemColors.Control
		Me.Frame11.Enabled = True
		Me.Frame11.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame11.Visible = True
		Me.Frame11.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame11.Name = "Frame11"
		Me.Frame14.Text = "�����LED��ʾ����"
		Me.Frame14.Size = New System.Drawing.Size(122, 365)
		Me.Frame14.Location = New System.Drawing.Point(189, 18)
		Me.Frame14.TabIndex = 88
		Me.Frame14.BackColor = System.Drawing.SystemColors.Control
		Me.Frame14.Enabled = True
		Me.Frame14.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame14.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame14.Visible = True
		Me.Frame14.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame14.Name = "Frame14"
		Me._Led_0.Text = "LED1"
		Me._Led_0.Size = New System.Drawing.Size(63, 17)
		Me._Led_0.Location = New System.Drawing.Point(41, 20)
		Me._Led_0.TabIndex = 96
		Me._Led_0.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._Led_0.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me._Led_0.BackColor = System.Drawing.SystemColors.Control
		Me._Led_0.CausesValidation = True
		Me._Led_0.Enabled = True
		Me._Led_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Led_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._Led_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Led_0.Appearance = System.Windows.Forms.Appearance.Normal
		Me._Led_0.TabStop = True
		Me._Led_0.CheckState = System.Windows.Forms.CheckState.Unchecked
		Me._Led_0.Visible = True
		Me._Led_0.Name = "_Led_0"
		Me._Led_1.Text = "LED2"
		Me._Led_1.Size = New System.Drawing.Size(63, 17)
		Me._Led_1.Location = New System.Drawing.Point(41, 55)
		Me._Led_1.TabIndex = 95
		Me._Led_1.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._Led_1.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me._Led_1.BackColor = System.Drawing.SystemColors.Control
		Me._Led_1.CausesValidation = True
		Me._Led_1.Enabled = True
		Me._Led_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Led_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._Led_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Led_1.Appearance = System.Windows.Forms.Appearance.Normal
		Me._Led_1.TabStop = True
		Me._Led_1.CheckState = System.Windows.Forms.CheckState.Unchecked
		Me._Led_1.Visible = True
		Me._Led_1.Name = "_Led_1"
		Me._Led_2.Text = "LED3"
		Me._Led_2.Size = New System.Drawing.Size(63, 17)
		Me._Led_2.Location = New System.Drawing.Point(41, 91)
		Me._Led_2.TabIndex = 94
		Me._Led_2.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._Led_2.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me._Led_2.BackColor = System.Drawing.SystemColors.Control
		Me._Led_2.CausesValidation = True
		Me._Led_2.Enabled = True
		Me._Led_2.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Led_2.Cursor = System.Windows.Forms.Cursors.Default
		Me._Led_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Led_2.Appearance = System.Windows.Forms.Appearance.Normal
		Me._Led_2.TabStop = True
		Me._Led_2.CheckState = System.Windows.Forms.CheckState.Unchecked
		Me._Led_2.Visible = True
		Me._Led_2.Name = "_Led_2"
		Me._Led_3.Text = "LED4"
		Me._Led_3.Size = New System.Drawing.Size(63, 17)
		Me._Led_3.Location = New System.Drawing.Point(41, 126)
		Me._Led_3.TabIndex = 93
		Me._Led_3.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._Led_3.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me._Led_3.BackColor = System.Drawing.SystemColors.Control
		Me._Led_3.CausesValidation = True
		Me._Led_3.Enabled = True
		Me._Led_3.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Led_3.Cursor = System.Windows.Forms.Cursors.Default
		Me._Led_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Led_3.Appearance = System.Windows.Forms.Appearance.Normal
		Me._Led_3.TabStop = True
		Me._Led_3.CheckState = System.Windows.Forms.CheckState.Unchecked
		Me._Led_3.Visible = True
		Me._Led_3.Name = "_Led_3"
		Me._Led_4.Text = "LED5"
		Me._Led_4.Size = New System.Drawing.Size(63, 17)
		Me._Led_4.Location = New System.Drawing.Point(40, 161)
		Me._Led_4.TabIndex = 92
		Me._Led_4.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._Led_4.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me._Led_4.BackColor = System.Drawing.SystemColors.Control
		Me._Led_4.CausesValidation = True
		Me._Led_4.Enabled = True
		Me._Led_4.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Led_4.Cursor = System.Windows.Forms.Cursors.Default
		Me._Led_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Led_4.Appearance = System.Windows.Forms.Appearance.Normal
		Me._Led_4.TabStop = True
		Me._Led_4.CheckState = System.Windows.Forms.CheckState.Unchecked
		Me._Led_4.Visible = True
		Me._Led_4.Name = "_Led_4"
		Me._Led_5.Text = "LED6"
		Me._Led_5.Size = New System.Drawing.Size(63, 17)
		Me._Led_5.Location = New System.Drawing.Point(41, 196)
		Me._Led_5.TabIndex = 91
		Me._Led_5.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._Led_5.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me._Led_5.BackColor = System.Drawing.SystemColors.Control
		Me._Led_5.CausesValidation = True
		Me._Led_5.Enabled = True
		Me._Led_5.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Led_5.Cursor = System.Windows.Forms.Cursors.Default
		Me._Led_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Led_5.Appearance = System.Windows.Forms.Appearance.Normal
		Me._Led_5.TabStop = True
		Me._Led_5.CheckState = System.Windows.Forms.CheckState.Unchecked
		Me._Led_5.Visible = True
		Me._Led_5.Name = "_Led_5"
		Me._Led_6.Text = "LED7"
		Me._Led_6.Size = New System.Drawing.Size(63, 17)
		Me._Led_6.Location = New System.Drawing.Point(41, 232)
		Me._Led_6.TabIndex = 90
		Me._Led_6.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._Led_6.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me._Led_6.BackColor = System.Drawing.SystemColors.Control
		Me._Led_6.CausesValidation = True
		Me._Led_6.Enabled = True
		Me._Led_6.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Led_6.Cursor = System.Windows.Forms.Cursors.Default
		Me._Led_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Led_6.Appearance = System.Windows.Forms.Appearance.Normal
		Me._Led_6.TabStop = True
		Me._Led_6.CheckState = System.Windows.Forms.CheckState.Unchecked
		Me._Led_6.Visible = True
		Me._Led_6.Name = "_Led_6"
		Me._Led_7.Text = "LED8"
		Me._Led_7.Size = New System.Drawing.Size(63, 17)
		Me._Led_7.Location = New System.Drawing.Point(41, 267)
		Me._Led_7.TabIndex = 89
		Me._Led_7.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._Led_7.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me._Led_7.BackColor = System.Drawing.SystemColors.Control
		Me._Led_7.CausesValidation = True
		Me._Led_7.Enabled = True
		Me._Led_7.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Led_7.Cursor = System.Windows.Forms.Cursors.Default
		Me._Led_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Led_7.Appearance = System.Windows.Forms.Appearance.Normal
		Me._Led_7.TabStop = True
		Me._Led_7.CheckState = System.Windows.Forms.CheckState.Unchecked
		Me._Led_7.Visible = True
		Me._Led_7.Name = "_Led_7"
		Me.Label40.Text = "  ѡ��:����  δѡ��:����"
		Me.Label40.Size = New System.Drawing.Size(74, 32)
		Me.Label40.Location = New System.Drawing.Point(27, 300)
		Me.Label40.TabIndex = 97
		Me.Label40.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label40.BackColor = System.Drawing.SystemColors.Control
		Me.Label40.Enabled = True
		Me.Label40.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label40.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label40.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label40.UseMnemonic = True
		Me.Label40.Visible = True
		Me.Label40.AutoSize = False
		Me.Label40.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label40.Name = "Label40"
		Me.Frame12.Text = "���룺8λ����״̬"
		Me.Frame12.Size = New System.Drawing.Size(122, 362)
		Me.Frame12.Location = New System.Drawing.Point(337, 20)
		Me.Frame12.TabIndex = 77
		Me.Frame12.BackColor = System.Drawing.SystemColors.Control
		Me.Frame12.Enabled = True
		Me.Frame12.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame12.Visible = True
		Me.Frame12.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame12.Name = "Frame12"
		Me._swit_0.Text = "ON1"
		Me._swit_0.Enabled = False
		Me._swit_0.Size = New System.Drawing.Size(48, 15)
		Me._swit_0.Location = New System.Drawing.Point(38, 20)
		Me._swit_0.TabIndex = 86
		Me._swit_0.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._swit_0.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me._swit_0.BackColor = System.Drawing.SystemColors.Control
		Me._swit_0.CausesValidation = True
		Me._swit_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._swit_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._swit_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._swit_0.Appearance = System.Windows.Forms.Appearance.Normal
		Me._swit_0.TabStop = True
		Me._swit_0.CheckState = System.Windows.Forms.CheckState.Unchecked
		Me._swit_0.Visible = True
		Me._swit_0.Name = "_swit_0"
		Me._swit_1.Text = "ON2"
		Me._swit_1.Enabled = False
		Me._swit_1.Size = New System.Drawing.Size(48, 15)
		Me._swit_1.Location = New System.Drawing.Point(38, 55)
		Me._swit_1.TabIndex = 85
		Me._swit_1.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._swit_1.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me._swit_1.BackColor = System.Drawing.SystemColors.Control
		Me._swit_1.CausesValidation = True
		Me._swit_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._swit_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._swit_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._swit_1.Appearance = System.Windows.Forms.Appearance.Normal
		Me._swit_1.TabStop = True
		Me._swit_1.CheckState = System.Windows.Forms.CheckState.Unchecked
		Me._swit_1.Visible = True
		Me._swit_1.Name = "_swit_1"
		Me._swit_2.Text = "ON3"
		Me._swit_2.Enabled = False
		Me._swit_2.Size = New System.Drawing.Size(48, 15)
		Me._swit_2.Location = New System.Drawing.Point(38, 90)
		Me._swit_2.TabIndex = 84
		Me._swit_2.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._swit_2.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me._swit_2.BackColor = System.Drawing.SystemColors.Control
		Me._swit_2.CausesValidation = True
		Me._swit_2.ForeColor = System.Drawing.SystemColors.ControlText
		Me._swit_2.Cursor = System.Windows.Forms.Cursors.Default
		Me._swit_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._swit_2.Appearance = System.Windows.Forms.Appearance.Normal
		Me._swit_2.TabStop = True
		Me._swit_2.CheckState = System.Windows.Forms.CheckState.Unchecked
		Me._swit_2.Visible = True
		Me._swit_2.Name = "_swit_2"
		Me._swit_3.Text = "ON4"
		Me._swit_3.Enabled = False
		Me._swit_3.Size = New System.Drawing.Size(48, 15)
		Me._swit_3.Location = New System.Drawing.Point(38, 125)
		Me._swit_3.TabIndex = 83
		Me._swit_3.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._swit_3.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me._swit_3.BackColor = System.Drawing.SystemColors.Control
		Me._swit_3.CausesValidation = True
		Me._swit_3.ForeColor = System.Drawing.SystemColors.ControlText
		Me._swit_3.Cursor = System.Windows.Forms.Cursors.Default
		Me._swit_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._swit_3.Appearance = System.Windows.Forms.Appearance.Normal
		Me._swit_3.TabStop = True
		Me._swit_3.CheckState = System.Windows.Forms.CheckState.Unchecked
		Me._swit_3.Visible = True
		Me._swit_3.Name = "_swit_3"
		Me._swit_4.Text = "ON5"
		Me._swit_4.Enabled = False
		Me._swit_4.Size = New System.Drawing.Size(48, 15)
		Me._swit_4.Location = New System.Drawing.Point(38, 161)
		Me._swit_4.TabIndex = 82
		Me._swit_4.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._swit_4.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me._swit_4.BackColor = System.Drawing.SystemColors.Control
		Me._swit_4.CausesValidation = True
		Me._swit_4.ForeColor = System.Drawing.SystemColors.ControlText
		Me._swit_4.Cursor = System.Windows.Forms.Cursors.Default
		Me._swit_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._swit_4.Appearance = System.Windows.Forms.Appearance.Normal
		Me._swit_4.TabStop = True
		Me._swit_4.CheckState = System.Windows.Forms.CheckState.Unchecked
		Me._swit_4.Visible = True
		Me._swit_4.Name = "_swit_4"
		Me._swit_5.Text = "ON6"
		Me._swit_5.Enabled = False
		Me._swit_5.Size = New System.Drawing.Size(48, 15)
		Me._swit_5.Location = New System.Drawing.Point(38, 196)
		Me._swit_5.TabIndex = 81
		Me._swit_5.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._swit_5.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me._swit_5.BackColor = System.Drawing.SystemColors.Control
		Me._swit_5.CausesValidation = True
		Me._swit_5.ForeColor = System.Drawing.SystemColors.ControlText
		Me._swit_5.Cursor = System.Windows.Forms.Cursors.Default
		Me._swit_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._swit_5.Appearance = System.Windows.Forms.Appearance.Normal
		Me._swit_5.TabStop = True
		Me._swit_5.CheckState = System.Windows.Forms.CheckState.Unchecked
		Me._swit_5.Visible = True
		Me._swit_5.Name = "_swit_5"
		Me._swit_6.Text = "ON7"
		Me._swit_6.Enabled = False
		Me._swit_6.Size = New System.Drawing.Size(48, 15)
		Me._swit_6.Location = New System.Drawing.Point(38, 231)
		Me._swit_6.TabIndex = 80
		Me._swit_6.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._swit_6.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me._swit_6.BackColor = System.Drawing.SystemColors.Control
		Me._swit_6.CausesValidation = True
		Me._swit_6.ForeColor = System.Drawing.SystemColors.ControlText
		Me._swit_6.Cursor = System.Windows.Forms.Cursors.Default
		Me._swit_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._swit_6.Appearance = System.Windows.Forms.Appearance.Normal
		Me._swit_6.TabStop = True
		Me._swit_6.CheckState = System.Windows.Forms.CheckState.Unchecked
		Me._swit_6.Visible = True
		Me._swit_6.Name = "_swit_6"
		Me._swit_7.Text = "ON8"
		Me._swit_7.Enabled = False
		Me._swit_7.Size = New System.Drawing.Size(48, 15)
		Me._swit_7.Location = New System.Drawing.Point(38, 266)
		Me._swit_7.TabIndex = 79
		Me._swit_7.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._swit_7.FlatStyle = System.Windows.Forms.FlatStyle.Standard
		Me._swit_7.BackColor = System.Drawing.SystemColors.Control
		Me._swit_7.CausesValidation = True
		Me._swit_7.ForeColor = System.Drawing.SystemColors.ControlText
		Me._swit_7.Cursor = System.Windows.Forms.Cursors.Default
		Me._swit_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._swit_7.Appearance = System.Windows.Forms.Appearance.Normal
		Me._swit_7.TabStop = True
		Me._swit_7.CheckState = System.Windows.Forms.CheckState.Unchecked
		Me._swit_7.Visible = True
		Me._swit_7.Name = "_swit_7"
		Me.evtbtrefresh.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.evtbtrefresh.Text = "���ˢ��״̬"
		Me.evtbtrefresh.Size = New System.Drawing.Size(87, 21)
		Me.evtbtrefresh.Location = New System.Drawing.Point(16, 327)
		Me.evtbtrefresh.TabIndex = 78
		Me.evtbtrefresh.BackColor = System.Drawing.SystemColors.Control
		Me.evtbtrefresh.CausesValidation = True
		Me.evtbtrefresh.Enabled = True
		Me.evtbtrefresh.ForeColor = System.Drawing.SystemColors.ControlText
		Me.evtbtrefresh.Cursor = System.Windows.Forms.Cursors.Default
		Me.evtbtrefresh.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.evtbtrefresh.TabStop = True
		Me.evtbtrefresh.Name = "evtbtrefresh"
		Me.Label41.Text = " ON:ѡ�� OFF:��ѡ��"
		Me.Label41.Size = New System.Drawing.Size(71, 29)
		Me.Label41.Location = New System.Drawing.Point(30, 296)
		Me.Label41.TabIndex = 87
		Me.Label41.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label41.BackColor = System.Drawing.SystemColors.Control
		Me.Label41.Enabled = True
		Me.Label41.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label41.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label41.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label41.UseMnemonic = True
		Me.Label41.Visible = True
		Me.Label41.AutoSize = False
		Me.Label41.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label41.Name = "Label41"
		Me.Frame13.Text = "ѡ��MEM��д��ַ"
		Me.Frame13.Size = New System.Drawing.Size(129, 68)
		Me.Frame13.Location = New System.Drawing.Point(24, 160)
		Me.Frame13.TabIndex = 74
		Me.Frame13.BackColor = System.Drawing.SystemColors.Control
		Me.Frame13.Enabled = True
		Me.Frame13.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame13.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame13.Visible = True
		Me.Frame13.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame13.Name = "Frame13"
		Me._memadd0_0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._memadd0_0.Text = "��ַ0"
		Me._memadd0_0.Size = New System.Drawing.Size(56, 14)
		Me._memadd0_0.Location = New System.Drawing.Point(18, 21)
		Me._memadd0_0.TabIndex = 76
		Me._memadd0_0.Checked = True
		Me._memadd0_0.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._memadd0_0.BackColor = System.Drawing.SystemColors.Control
		Me._memadd0_0.CausesValidation = True
		Me._memadd0_0.Enabled = True
		Me._memadd0_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._memadd0_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._memadd0_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._memadd0_0.Appearance = System.Windows.Forms.Appearance.Normal
		Me._memadd0_0.TabStop = True
		Me._memadd0_0.Visible = True
		Me._memadd0_0.Name = "_memadd0_0"
		Me._memadd1_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._memadd1_1.Text = "��ַ1"
		Me._memadd1_1.Size = New System.Drawing.Size(56, 14)
		Me._memadd1_1.Location = New System.Drawing.Point(18, 43)
		Me._memadd1_1.TabIndex = 75
		Me._memadd1_1.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._memadd1_1.BackColor = System.Drawing.SystemColors.Control
		Me._memadd1_1.CausesValidation = True
		Me._memadd1_1.Enabled = True
		Me._memadd1_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._memadd1_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._memadd1_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._memadd1_1.Appearance = System.Windows.Forms.Appearance.Normal
		Me._memadd1_1.TabStop = True
		Me._memadd1_1.Checked = False
		Me._memadd1_1.Visible = True
		Me._memadd1_1.Name = "_memadd1_1"
		Me.Label42.Text = "IO���:LED��ѡ�����DEMO����8��LED״̬"
		Me.Label42.Size = New System.Drawing.Size(123, 34)
		Me.Label42.Location = New System.Drawing.Point(18, 24)
		Me.Label42.TabIndex = 100
		Me.Label42.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label42.BackColor = System.Drawing.SystemColors.Control
		Me.Label42.Enabled = True
		Me.Label42.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label42.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label42.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label42.UseMnemonic = True
		Me.Label42.Visible = True
		Me.Label42.AutoSize = False
		Me.Label42.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label42.Name = "Label42"
		Me.Label43.Text = "IO����:8λ����״̬���� ""ˢ��""��Ŧ���DEMO���в��뿪�صĵ�ǰ״̬"
		Me.Label43.Size = New System.Drawing.Size(155, 59)
		Me.Label43.Location = New System.Drawing.Point(18, 82)
		Me.Label43.TabIndex = 99
		Me.Label43.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label43.BackColor = System.Drawing.SystemColors.Control
		Me.Label43.Enabled = True
		Me.Label43.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label43.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label43.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label43.UseMnemonic = True
		Me.Label43.Visible = True
		Me.Label43.AutoSize = False
		Me.Label43.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label43.Name = "Label43"
		Me.Label44.Text = "����API��MEM������ͬ��ֻ�ǳ�������1�ֽ�"
		Me.Label44.Size = New System.Drawing.Size(154, 30)
		Me.Label44.Location = New System.Drawing.Point(21, 267)
		Me.Label44.TabIndex = 98
		Me.Label44.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label44.BackColor = System.Drawing.SystemColors.Control
		Me.Label44.Enabled = True
		Me.Label44.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label44.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label44.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label44.UseMnemonic = True
		Me.Label44.Visible = True
		Me.Label44.AutoSize = False
		Me.Label44.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label44.Name = "Label44"
		Me._SSTab1_TabPage5.Text = "SPI�ӿ�"
		Me.Frame15.Text = "����ģʽ��д����SPI��4����ͬ�����ڣ�API=USBIO_StreamSPI4"
		Me.Frame15.Size = New System.Drawing.Size(465, 409)
		Me.Frame15.Location = New System.Drawing.Point(8, 32)
		Me.Frame15.TabIndex = 116
		Me.Frame15.BackColor = System.Drawing.SystemColors.Control
		Me.Frame15.Enabled = True
		Me.Frame15.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame15.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame15.Visible = True
		Me.Frame15.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame15.Name = "Frame15"
		Me.Frame16.Text = "SPI�ֽ��е�λ˳��"
		Me.Frame16.Size = New System.Drawing.Size(425, 41)
		Me.Frame16.Location = New System.Drawing.Point(24, 320)
		Me.Frame16.TabIndex = 125
		Me.Frame16.BackColor = System.Drawing.SystemColors.Control
		Me.Frame16.Enabled = True
		Me.Frame16.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Frame16.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Frame16.Visible = True
		Me.Frame16.Padding = New System.Windows.Forms.Padding(0)
		Me.Frame16.Name = "Frame16"
		Me._SPIMSB_0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._SPIMSB_0.Text = "��λ��ǰ"
		Me._SPIMSB_0.Size = New System.Drawing.Size(73, 17)
		Me._SPIMSB_0.Location = New System.Drawing.Point(152, 16)
		Me._SPIMSB_0.TabIndex = 127
		Me._SPIMSB_0.Checked = True
		Me._SPIMSB_0.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._SPIMSB_0.BackColor = System.Drawing.SystemColors.Control
		Me._SPIMSB_0.CausesValidation = True
		Me._SPIMSB_0.Enabled = True
		Me._SPIMSB_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._SPIMSB_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._SPIMSB_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._SPIMSB_0.Appearance = System.Windows.Forms.Appearance.Normal
		Me._SPIMSB_0.TabStop = True
		Me._SPIMSB_0.Visible = True
		Me._SPIMSB_0.Name = "_SPIMSB_0"
		Me._SPILSB_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._SPILSB_1.Text = "��λ��ǰ"
		Me._SPILSB_1.Size = New System.Drawing.Size(73, 17)
		Me._SPILSB_1.Location = New System.Drawing.Point(272, 16)
		Me._SPILSB_1.TabIndex = 126
		Me._SPILSB_1.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._SPILSB_1.BackColor = System.Drawing.SystemColors.Control
		Me._SPILSB_1.CausesValidation = True
		Me._SPILSB_1.Enabled = True
		Me._SPILSB_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._SPILSB_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._SPILSB_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._SPILSB_1.Appearance = System.Windows.Forms.Appearance.Normal
		Me._SPILSB_1.TabStop = True
		Me._SPILSB_1.Checked = False
		Me._SPILSB_1.Visible = True
		Me._SPILSB_1.Name = "_SPILSB_1"
		Me.StreamSPIRW.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.StreamSPIRW.Text = "Read\Write"
		Me.StreamSPIRW.Size = New System.Drawing.Size(113, 25)
		Me.StreamSPIRW.Location = New System.Drawing.Point(152, 280)
		Me.StreamSPIRW.TabIndex = 123
		Me.StreamSPIRW.BackColor = System.Drawing.SystemColors.Control
		Me.StreamSPIRW.CausesValidation = True
		Me.StreamSPIRW.Enabled = True
		Me.StreamSPIRW.ForeColor = System.Drawing.SystemColors.ControlText
		Me.StreamSPIRW.Cursor = System.Windows.Forms.Cursors.Default
		Me.StreamSPIRW.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.StreamSPIRW.TabStop = True
		Me.StreamSPIRW.Name = "StreamSPIRW"
		Me.SPIWRBuf.AutoSize = False
		Me.SPIWRBuf.Size = New System.Drawing.Size(425, 217)
		Me.SPIWRBuf.Location = New System.Drawing.Point(24, 64)
		Me.SPIWRBuf.MultiLine = True
		Me.SPIWRBuf.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.SPIWRBuf.TabIndex = 122
		Me.SPIWRBuf.AcceptsReturn = True
		Me.SPIWRBuf.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.SPIWRBuf.BackColor = System.Drawing.SystemColors.Window
		Me.SPIWRBuf.CausesValidation = True
		Me.SPIWRBuf.Enabled = True
		Me.SPIWRBuf.ForeColor = System.Drawing.SystemColors.WindowText
		Me.SPIWRBuf.HideSelection = True
		Me.SPIWRBuf.ReadOnly = False
		Me.SPIWRBuf.Maxlength = 0
		Me.SPIWRBuf.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.SPIWRBuf.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.SPIWRBuf.TabStop = True
		Me.SPIWRBuf.Visible = True
		Me.SPIWRBuf.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.SPIWRBuf.Name = "SPIWRBuf"
		Me.SPIWRLen.AutoSize = False
		Me.SPIWRLen.Size = New System.Drawing.Size(105, 19)
		Me.SPIWRLen.Location = New System.Drawing.Point(152, 24)
		Me.SPIWRLen.TabIndex = 121
		Me.SPIWRLen.AcceptsReturn = True
		Me.SPIWRLen.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.SPIWRLen.BackColor = System.Drawing.SystemColors.Window
		Me.SPIWRLen.CausesValidation = True
		Me.SPIWRLen.Enabled = True
		Me.SPIWRLen.ForeColor = System.Drawing.SystemColors.WindowText
		Me.SPIWRLen.HideSelection = True
		Me.SPIWRLen.ReadOnly = False
		Me.SPIWRLen.Maxlength = 0
		Me.SPIWRLen.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.SPIWRLen.MultiLine = False
		Me.SPIWRLen.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.SPIWRLen.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.SPIWRLen.TabStop = True
		Me.SPIWRLen.Visible = True
		Me.SPIWRLen.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.SPIWRLen.Name = "SPIWRLen"
		Me._Label31_0.Text = "(<40H)"
		Me._Label31_0.Size = New System.Drawing.Size(49, 17)
		Me._Label31_0.Location = New System.Drawing.Point(272, 24)
		Me._Label31_0.TabIndex = 124
		Me._Label31_0.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label31_0.BackColor = System.Drawing.SystemColors.Control
		Me._Label31_0.Enabled = True
		Me._Label31_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label31_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label31_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label31_0.UseMnemonic = True
		Me._Label31_0.Visible = True
		Me._Label31_0.AutoSize = False
		Me._Label31_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label31_0.Name = "_Label31_0"
		Me._Label28_0.Text = "����׼����DO/MOSI/D5д��������,���غ��Ǵ�DI/MISO/D7���������"
		Me._Label28_0.Size = New System.Drawing.Size(377, 17)
		Me._Label28_0.Location = New System.Drawing.Point(24, 48)
		Me._Label28_0.TabIndex = 120
		Me._Label28_0.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label28_0.BackColor = System.Drawing.SystemColors.Control
		Me._Label28_0.Enabled = True
		Me._Label28_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label28_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label28_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label28_0.UseMnemonic = True
		Me._Label28_0.Visible = True
		Me._Label28_0.AutoSize = False
		Me._Label28_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label28_0.Name = "_Label28_0"
		Me.Label29.Text = "SPIʱ��: SCK/D3����Ϊʱ�����, Ĭ��Ϊ�͵�ƽ, DO/MOSI/D5������ʱ��������֮ǰ���, DI/MISO/D7������ʱ���½���֮������."
		Me.Label29.Size = New System.Drawing.Size(425, 33)
		Me.Label29.Location = New System.Drawing.Point(24, 368)
		Me.Label29.TabIndex = 119
		Me.Label29.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Label29.BackColor = System.Drawing.SystemColors.Control
		Me.Label29.Enabled = True
		Me.Label29.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Label29.Cursor = System.Windows.Forms.Cursors.Default
		Me.Label29.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Label29.UseMnemonic = True
		Me.Label29.Visible = True
		Me.Label29.AutoSize = False
		Me.Label29.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Label29.Name = "Label29"
		Me._Label19_0.Text = "���ݻ�����ioBuffer"
		Me._Label19_0.Size = New System.Drawing.Size(105, 17)
		Me._Label19_0.Location = New System.Drawing.Point(24, 288)
		Me._Label19_0.TabIndex = 118
		Me._Label19_0.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label19_0.BackColor = System.Drawing.SystemColors.Control
		Me._Label19_0.Enabled = True
		Me._Label19_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label19_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label19_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label19_0.UseMnemonic = True
		Me._Label19_0.Visible = True
		Me._Label19_0.AutoSize = False
		Me._Label19_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label19_0.Name = "_Label19_0"
		Me._Label18_0.Text = "׼������������ֽ���"
		Me._Label18_0.Size = New System.Drawing.Size(129, 17)
		Me._Label18_0.Location = New System.Drawing.Point(24, 24)
		Me._Label18_0.TabIndex = 117
		Me._Label18_0.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._Label18_0.BackColor = System.Drawing.SystemColors.Control
		Me._Label18_0.Enabled = True
		Me._Label18_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._Label18_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._Label18_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._Label18_0.UseMnemonic = True
		Me._Label18_0.Visible = True
		Me._Label18_0.AutoSize = False
		Me._Label18_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._Label18_0.Name = "_Label18_0"
		Me.Controls.Add(USBIO_NOTIFY_ROUTINE)
		Me.Controls.Add(SSTab1)
		Me.SSTab1.Controls.Add(_SSTab1_TabPage0)
		Me.SSTab1.Controls.Add(_SSTab1_TabPage1)
		Me.SSTab1.Controls.Add(_SSTab1_TabPage2)
		Me.SSTab1.Controls.Add(_SSTab1_TabPage3)
		Me.SSTab1.Controls.Add(_SSTab1_TabPage4)
		Me.SSTab1.Controls.Add(_SSTab1_TabPage5)
		Me._SSTab1_TabPage0.Controls.Add(Frame1)
		Me._SSTab1_TabPage0.Controls.Add(Frame2)
		Me.Frame1.Controls.Add(eppData0)
		Me.Frame1.Controls.Add(eppLen0)
		Me.Frame1.Controls.Add(eppRead0)
		Me.Frame1.Controls.Add(eppWrite0)
		Me.Frame1.Controls.Add(Label1)
		Me.Frame1.Controls.Add(Label2)
		Me.Frame1.Controls.Add(Label3)
		Me.Frame1.Controls.Add(Label4)
		Me.Frame1.Controls.Add(Label20)
		Me.Frame2.Controls.Add(eppData1)
		Me.Frame2.Controls.Add(eppLen1)
		Me.Frame2.Controls.Add(eppRead1)
		Me.Frame2.Controls.Add(eppWrite1)
		Me.Frame2.Controls.Add(Label5)
		Me.Frame2.Controls.Add(Label6)
		Me.Frame2.Controls.Add(Label7)
		Me.Frame2.Controls.Add(Label8)
		Me.Frame2.Controls.Add(Label21)
		Me._SSTab1_TabPage1.Controls.Add(Frame3)
		Me._SSTab1_TabPage1.Controls.Add(Frame4)
		Me.Frame3.Controls.Add(memData0)
		Me.Frame3.Controls.Add(memLen0)
		Me.Frame3.Controls.Add(memRead0)
		Me.Frame3.Controls.Add(memWrite0)
		Me.Frame3.Controls.Add(Label10)
		Me.Frame3.Controls.Add(Label11)
		Me.Frame3.Controls.Add(Label12)
		Me.Frame3.Controls.Add(Label9)
		Me.Frame3.Controls.Add(Label22)
		Me.Frame4.Controls.Add(memLen1)
		Me.Frame4.Controls.Add(memData1)
		Me.Frame4.Controls.Add(memRead1)
		Me.Frame4.Controls.Add(memWrite1)
		Me.Frame4.Controls.Add(Label13)
		Me.Frame4.Controls.Add(Label14)
		Me.Frame4.Controls.Add(Label15)
		Me.Frame4.Controls.Add(Label16)
		Me.Frame4.Controls.Add(Label23)
		Me._SSTab1_TabPage2.Controls.Add(Frame5)
		Me.Frame5.Controls.Add(Frame17)
		Me.Frame5.Controls.Add(Frame7)
		Me.Frame5.Controls.Add(Frame6)
		Me.Frame17.Controls.Add(_I2CM_3)
		Me.Frame17.Controls.Add(_I2CM_2)
		Me.Frame17.Controls.Add(_I2CM_1)
		Me.Frame17.Controls.Add(_I2CM_0)
		Me.Frame7.Controls.Add(StreamICRW)
		Me.Frame7.Controls.Add(I2CWRBuf)
		Me.Frame7.Controls.Add(I2CWRLen)
		Me.Frame7.Controls.Add(Label17)
		Me.Frame7.Controls.Add(Label24)
		Me.Frame7.Controls.Add(Label25)
		Me.Frame6.Controls.Add(I2CRDLen)
		Me.Frame6.Controls.Add(I2CRDBuf)
		Me.Frame6.Controls.Add(Label26)
		Me.Frame6.Controls.Add(Label27)
		Me.Frame6.Controls.Add(Label30)
		Me._SSTab1_TabPage3.Controls.Add(Frame8)
		Me._SSTab1_TabPage3.Controls.Add(Frame9)
		Me._SSTab1_TabPage3.Controls.Add(Frame10)
		Me.Frame8.Controls.Add(WrDataLen)
		Me.Frame8.Controls.Add(WrDataBuf)
		Me.Frame8.Controls.Add(WrDataAddr)
		Me.Frame8.Controls.Add(eepromWrDate)
		Me.Frame8.Controls.Add(Label38)
		Me.Frame8.Controls.Add(Label37)
		Me.Frame8.Controls.Add(Label36)
		Me.Frame8.Controls.Add(Label33)
		Me.Frame9.Controls.Add(eepromRdDate)
		Me.Frame9.Controls.Add(RdDataAddr)
		Me.Frame9.Controls.Add(RdDataBuf)
		Me.Frame9.Controls.Add(RdDataLen)
		Me.Frame9.Controls.Add(Label39)
		Me.Frame9.Controls.Add(Label35)
		Me.Frame9.Controls.Add(Label34)
		Me.Frame9.Controls.Add(Label32)
		Me.Frame10.Controls.Add(_eppromtype_12)
		Me.Frame10.Controls.Add(_eppromtype_11)
		Me.Frame10.Controls.Add(_eppromtype_10)
		Me.Frame10.Controls.Add(_eppromtype_9)
		Me.Frame10.Controls.Add(_eppromtype_8)
		Me.Frame10.Controls.Add(_eppromtype_7)
		Me.Frame10.Controls.Add(_eppromtype_6)
		Me.Frame10.Controls.Add(_eppromtype_5)
		Me.Frame10.Controls.Add(_eppromtype_4)
		Me.Frame10.Controls.Add(_eppromtype_3)
		Me.Frame10.Controls.Add(_eppromtype_2)
		Me.Frame10.Controls.Add(_eppromtype_1)
		Me.Frame10.Controls.Add(_eppromtype_0)
		Me._SSTab1_TabPage4.Controls.Add(Frame11)
		Me.Frame11.Controls.Add(Frame14)
		Me.Frame11.Controls.Add(Frame12)
		Me.Frame11.Controls.Add(Frame13)
		Me.Frame11.Controls.Add(Label42)
		Me.Frame11.Controls.Add(Label43)
		Me.Frame11.Controls.Add(Label44)
		Me.Frame14.Controls.Add(_Led_0)
		Me.Frame14.Controls.Add(_Led_1)
		Me.Frame14.Controls.Add(_Led_2)
		Me.Frame14.Controls.Add(_Led_3)
		Me.Frame14.Controls.Add(_Led_4)
		Me.Frame14.Controls.Add(_Led_5)
		Me.Frame14.Controls.Add(_Led_6)
		Me.Frame14.Controls.Add(_Led_7)
		Me.Frame14.Controls.Add(Label40)
		Me.Frame12.Controls.Add(_swit_0)
		Me.Frame12.Controls.Add(_swit_1)
		Me.Frame12.Controls.Add(_swit_2)
		Me.Frame12.Controls.Add(_swit_3)
		Me.Frame12.Controls.Add(_swit_4)
		Me.Frame12.Controls.Add(_swit_5)
		Me.Frame12.Controls.Add(_swit_6)
		Me.Frame12.Controls.Add(_swit_7)
		Me.Frame12.Controls.Add(evtbtrefresh)
		Me.Frame12.Controls.Add(Label41)
		Me.Frame13.Controls.Add(_memadd0_0)
		Me.Frame13.Controls.Add(_memadd1_1)
		Me._SSTab1_TabPage5.Controls.Add(Frame15)
		Me.Frame15.Controls.Add(Frame16)
		Me.Frame15.Controls.Add(StreamSPIRW)
		Me.Frame15.Controls.Add(SPIWRBuf)
		Me.Frame15.Controls.Add(SPIWRLen)
		Me.Frame15.Controls.Add(_Label31_0)
		Me.Frame15.Controls.Add(_Label28_0)
		Me.Frame15.Controls.Add(Label29)
		Me.Frame15.Controls.Add(_Label19_0)
		Me.Frame15.Controls.Add(_Label18_0)
		Me.Frame16.Controls.Add(_SPIMSB_0)
		Me.Frame16.Controls.Add(_SPILSB_1)
		Me.I2CM.SetIndex(_I2CM_3, CType(3, Short))
		Me.I2CM.SetIndex(_I2CM_2, CType(2, Short))
		Me.I2CM.SetIndex(_I2CM_1, CType(1, Short))
		Me.I2CM.SetIndex(_I2CM_0, CType(0, Short))
		Me.Label18.SetIndex(_Label18_0, CType(0, Short))
		Me.Label19.SetIndex(_Label19_0, CType(0, Short))
		Me.Label28.SetIndex(_Label28_0, CType(0, Short))
		Me.Label31.SetIndex(_Label31_0, CType(0, Short))
		Me.Led.SetIndex(_Led_0, CType(0, Short))
		Me.Led.SetIndex(_Led_1, CType(1, Short))
		Me.Led.SetIndex(_Led_2, CType(2, Short))
		Me.Led.SetIndex(_Led_3, CType(3, Short))
		Me.Led.SetIndex(_Led_4, CType(4, Short))
		Me.Led.SetIndex(_Led_5, CType(5, Short))
		Me.Led.SetIndex(_Led_6, CType(6, Short))
		Me.Led.SetIndex(_Led_7, CType(7, Short))
		Me.SPILSB.SetIndex(_SPILSB_1, CType(1, Short))
		Me.SPIMSB.SetIndex(_SPIMSB_0, CType(0, Short))
		Me.eppromtype.SetIndex(_eppromtype_12, CType(12, Short))
		Me.eppromtype.SetIndex(_eppromtype_11, CType(11, Short))
		Me.eppromtype.SetIndex(_eppromtype_10, CType(10, Short))
		Me.eppromtype.SetIndex(_eppromtype_9, CType(9, Short))
		Me.eppromtype.SetIndex(_eppromtype_8, CType(8, Short))
		Me.eppromtype.SetIndex(_eppromtype_7, CType(7, Short))
		Me.eppromtype.SetIndex(_eppromtype_6, CType(6, Short))
		Me.eppromtype.SetIndex(_eppromtype_5, CType(5, Short))
		Me.eppromtype.SetIndex(_eppromtype_4, CType(4, Short))
		Me.eppromtype.SetIndex(_eppromtype_3, CType(3, Short))
		Me.eppromtype.SetIndex(_eppromtype_2, CType(2, Short))
		Me.eppromtype.SetIndex(_eppromtype_1, CType(1, Short))
		Me.eppromtype.SetIndex(_eppromtype_0, CType(0, Short))
		Me.memadd0.SetIndex(_memadd0_0, CType(0, Short))
		Me.memadd1.SetIndex(_memadd1_1, CType(1, Short))
		Me.swit.SetIndex(_swit_0, CType(0, Short))
		Me.swit.SetIndex(_swit_1, CType(1, Short))
		Me.swit.SetIndex(_swit_2, CType(2, Short))
		Me.swit.SetIndex(_swit_3, CType(3, Short))
		Me.swit.SetIndex(_swit_4, CType(4, Short))
		Me.swit.SetIndex(_swit_5, CType(5, Short))
		Me.swit.SetIndex(_swit_6, CType(6, Short))
		Me.swit.SetIndex(_swit_7, CType(7, Short))
		CType(Me.swit, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.memadd1, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.memadd0, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.eppromtype, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.SPIMSB, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.SPILSB, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.Led, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.Label31, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.Label28, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.Label19, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.Label18, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.I2CM, System.ComponentModel.ISupportInitialize).EndInit()
		Me.SSTab1.ResumeLayout(False)
		Me._SSTab1_TabPage0.ResumeLayout(False)
		Me.Frame1.ResumeLayout(False)
		Me.Frame2.ResumeLayout(False)
		Me._SSTab1_TabPage1.ResumeLayout(False)
		Me.Frame3.ResumeLayout(False)
		Me.Frame4.ResumeLayout(False)
		Me._SSTab1_TabPage2.ResumeLayout(False)
		Me.Frame5.ResumeLayout(False)
		Me.Frame17.ResumeLayout(False)
		Me.Frame7.ResumeLayout(False)
		Me.Frame6.ResumeLayout(False)
		Me._SSTab1_TabPage3.ResumeLayout(False)
		Me.Frame8.ResumeLayout(False)
		Me.Frame9.ResumeLayout(False)
		Me.Frame10.ResumeLayout(False)
		Me._SSTab1_TabPage4.ResumeLayout(False)
		Me.Frame11.ResumeLayout(False)
		Me.Frame14.ResumeLayout(False)
		Me.Frame12.ResumeLayout(False)
		Me.Frame13.ResumeLayout(False)
		Me._SSTab1_TabPage5.ResumeLayout(False)
		Me.Frame15.ResumeLayout(False)
		Me.Frame16.ResumeLayout(False)
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class