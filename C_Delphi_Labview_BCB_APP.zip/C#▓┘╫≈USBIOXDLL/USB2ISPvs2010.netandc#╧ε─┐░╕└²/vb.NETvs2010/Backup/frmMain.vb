Option Strict Off
Option Explicit On
Friend Class frmMain
	Inherits System.Windows.Forms.Form
	
	Dim hopen As Integer
	
	
	Private Sub eepromRdDate_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles eepromRdDate.Click
		Dim mDataAddr As Integer
		Dim mLen As Integer
		'UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
        Dim buffer(mMAX_BUFFER_LENGTH - 1) As Byte
		mLen = HexToBcd(RdDataLen.Text)
		
		If (RdDataAddr.Text = "") Then
			MsgBox("���������ݵ�Ԫ��ʼ��ַ��", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			Exit Sub
		End If
		If (mLen <= 0) Then
			MsgBox("�������ȡ���ȣ�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			Exit Sub
		End If
		mDataAddr = HexToBcd(RdDataAddr.Text)
		Dim buff As String
		Dim i As Integer
		If (mOpen = True) Then
			'UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If (USBIO_ReadEEPROM(mIndex, Module1.eepromid, mDataAddr, mLen, buffer)) Then
				For i = 0 To mLen - 1
                    buff = buff & Hex2bit(buffer(i)) & " "
				Next i
				RdDataBuf.Text = buff
			Else
				MsgBox("��E2PROM����ʧ�ܣ�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			End If
			RdDataLen.Text = Hex(mLen)
		Else
			MsgBox("�豸δ�򿪣�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
		End If
	End Sub
	
	Private Sub eepromWrDate_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles eepromWrDate.Click
		Dim mData As Byte
		Dim mDataAddr As Integer
		Dim mLen As Integer
		'UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
        Dim buffer(mMAX_BUFFER_LENGTH - 1) As Byte
		
		mLen = HexToBcd((WrDataLen.Text))
		If (WrDataAddr.Text = "") Then
			MsgBox("���������ݵ�Ԫ��ʼ��ַ��", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			Exit Sub
		End If
		If (mLen <= 0 Or WrDataBuf.Text = "") Then
			MsgBox("������Ҫд�������,���ȣ�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			Exit Sub
		End If
		
		If (mLen > (Len(WrDataBuf.Text) \ 2)) Then '�����볤�Ⱥ����ݳ�����ȡСֵ
			mLen = Len(WrDataBuf.Text) \ 2
		End If
		
		mDataAddr = HexToBcd((WrDataAddr.Text))
		Call mStrtoVal((WrDataBuf.Text), buffer, mLen) '�������ʮ�����Ƹ�ʽ�ַ�����ת����ֵ����
		
		If (mOpen = True) Then
			'UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If (USBIO_WriteEEPROM(mIndex, Module1.eepromid, mDataAddr, mLen, buffer) = False) Then
				MsgBox("��E2PROM����ʧ�ܣ�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			End If
			WrDataLen.Text = Hex(mLen)
		Else
			MsgBox("�豸δ�򿪣�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
		End If
	End Sub
	
	Private Sub eppRead0_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles eppRead0.Click
		Dim mLen As Integer
		'UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
		Dim buffer(mMAX_BUFFER_LENGTH - 1) As Byte
		
		mLen = HexToBcd((eppLen0.Text))
		If (mLen <= 0) Then
			MsgBox("�������ȡ����", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			Exit Sub
		End If
		Dim buff As String
		Dim i As Integer
		If (mOpen = True) Then
			'UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If (USBIO_EppReadData(mIndex, buffer, mLen)) Then
				buff = ""
				For i = 0 To mLen - 1 Step 1
					buff = buff & Hex2bit(buffer(i)) & " "
				Next 
				eppData0.Text = buff
			Else
				MsgBox("EPP��ʽ������ʧ�ܣ� ", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			End If
			eppLen0.Text = Hex(mLen)
		Else
			MsgBox("�豸δ�򿪣�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
		End If
	End Sub
	
	Private Sub eppRead1_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles eppRead1.Click
		Dim mLen As Integer
		'UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
		'Dim buffer As arrRBuffer
		Dim buffer(mMAX_BUFFER_LENGTH - 1) As Byte
		
		mLen = HexToBcd((eppLen1.Text))
		If (mLen <= 0) Then
			MsgBox("�������ȡ���ݵĳ���", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			Exit Sub
		End If
		Dim buff As String
		Dim i As Object
		Dim j As Integer
		If (mOpen = True) Then
			'UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If (USBIO_EppReadAddr(mIndex, buffer, mLen)) Then
				j = 0
				For i = 0 To mLen - 1
					'UPGRADE_WARNING: Couldn't resolve default property of object i. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					buff = buff & Hex2bit(buffer(i)) & " "
				Next 
				eppData1.Text = buff
			Else
				MsgBox("EPP�����ݿ�1ʧ�ܣ� ", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			End If
			eppLen1.Text = Hex(mLen)
		Else
			MsgBox("�豸δ�򿪣�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
		End If
	End Sub
	
	'UPGRADE_WARNING: Event eppromtype.CheckedChanged may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"'
	Private Sub eppromtype_CheckedChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles eppromtype.CheckedChanged
		If eventSender.Checked Then
			Dim Index As Short = eppromtype.GetIndex(eventSender)
			Select Case Index
				Case 0
					Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C01
				Case 1
					Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C02
				Case 2
					Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C04
				Case 3
					Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C08
				Case 4
					Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C16
				Case 5
					Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C32
				Case 6
					Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C64
				Case 7
					Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C128
				Case 8
					Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C256
				Case 9
					Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C512
				Case 10
					Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C1024
				Case 11
					Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C2048
				Case 12
					Module1.eepromid = USBIOXDLL.EEPROM_TYPE.ID_24C4096
			End Select
		End If
	End Sub
	
	Private Sub eppWrite0_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles eppWrite0.Click
		Dim mLen As Integer
		'UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
        Dim buffer(mMAX_BUFFER_LENGTH - 1) As Byte
		
		mLen = HexToBcd((eppLen0.Text))
		If (mLen <= 0 Or Len(eppData0.Text) = 0) Then
			MsgBox("������Ҫд������,���ȣ�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			Exit Sub
		End If
		If (mLen > Len(eppData0.Text) \ 2) Then
			mLen = Len(eppData0.Text) \ 2
		End If
		Call mStrtoVal((eppData0.Text), buffer, mLen) '�������ʮ�����Ƹ�ʽ�ַ�����ת����ֵ����
		
		If (mOpen = True) Then
			'UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If (USBIO_EppWriteData(mIndex, buffer, mLen) = False) Then
				MsgBox("EPPд���ݿ�0ʧ�ܣ�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			End If
			eppLen0.Text = Hex(mLen)
		Else
			MsgBox("�豸δ�򿪣�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
		End If
	End Sub
	
	Private Sub eppWrite1_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles eppWrite1.Click
		Dim mLen As Integer
		'UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
        Dim buffer(mMAX_BUFFER_LENGTH - 1) As Byte
		
		mLen = HexToBcd((eppLen1.Text))
		
		If (mLen <= 0 Or Len(eppData1.Text) = 0) Then
			MsgBox("������д���ݺͳ��ȣ�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			Exit Sub
		End If
		
		If (mLen > Len(eppData1.Text) \ 2) Then
			mLen = Len(eppData1.Text) \ 2
		End If
		
		Call mStrtoVal((eppData1.Text), buffer, mLen) '�������ʮ�����Ƹ�ʽ�ַ�����ת����ֵ����
		If (mOpen = True) Then
			'UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If (USBIO_EppWriteAddr(mIndex, buffer, mLen) = False) Then
				MsgBox("EPPд���ݿ�1ʧ�ܣ�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			End If
			eppLen1.Text = Hex(mLen)
		Else
			MsgBox("�豸δ�򿪣�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
		End If
	End Sub
	
	Private Sub evtbtrefresh_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles evtbtrefresh.Click
		Dim mBuf(0) As Byte
		Dim mLen As Integer
		
		If mOpen = True Then
			mLen = 1
			If (memadd0(0).Checked = True) Then
                If (USBIO_MemReadAddr0(mIndex, mBuf, mLen) = False) Then
                    MsgBox("MEM��ַ��ʽ�����뿪��״̬ʧ�ܣ� ", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
                    Exit Sub
                End If
			ElseIf (memadd1(1).Checked = True) Then 
                If (USBIO_MemReadAddr1(mIndex, mBuf, mLen) = False) Then
                    MsgBox("MEM��ַ��ʽ1�����뿪��״̬ʧ�ܣ� ", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
                    Exit Sub
                End If
			End If
			'��ť״̬��ʾ
			If ((mBuf(0) And 1) = 0) Then
				swit(0).CheckState = System.Windows.Forms.CheckState.Checked
			Else
				swit(0).CheckState = System.Windows.Forms.CheckState.Unchecked
			End If
			If ((mBuf(0) And 2) = 0) Then
				swit(1).CheckState = System.Windows.Forms.CheckState.Checked
			Else
				swit(1).CheckState = System.Windows.Forms.CheckState.Unchecked
			End If
			If ((mBuf(0) And 4) = 0) Then
				swit(2).CheckState = System.Windows.Forms.CheckState.Checked
			Else
				swit(2).CheckState = System.Windows.Forms.CheckState.Unchecked
			End If
			If ((mBuf(0) And 8) = 0) Then
				swit(3).CheckState = System.Windows.Forms.CheckState.Checked
			Else
				swit(3).CheckState = System.Windows.Forms.CheckState.Unchecked
			End If
			If ((mBuf(0) And 16) = 0) Then
				swit(4).CheckState = System.Windows.Forms.CheckState.Checked
			Else
				swit(4).CheckState = System.Windows.Forms.CheckState.Unchecked
			End If
			If ((mBuf(0) And 32) = 0) Then
				swit(5).CheckState = System.Windows.Forms.CheckState.Checked
			Else
				swit(5).CheckState = System.Windows.Forms.CheckState.Unchecked
			End If
			If ((mBuf(0) And 64) = 0) Then
				swit(6).CheckState = System.Windows.Forms.CheckState.Checked
			Else
				swit(6).CheckState = System.Windows.Forms.CheckState.Unchecked
			End If
			If ((mBuf(0) And 128) = 0) Then
				swit(7).CheckState = System.Windows.Forms.CheckState.Checked
			Else
				swit(7).CheckState = System.Windows.Forms.CheckState.Unchecked
			End If
		Else
			MsgBox("�豸δ�򿪣�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
		End If
	End Sub
	
	Private Sub frmMain_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		mIndex = 0
		'SSTab1.TabVisible(0) = False
		'SSTab1.TabVisible(1) = False
		'SSTab1.TabVisible(2) = False
		'SSTab1.TabVisible(3) = False
		'SSTab1.TabVisible(1) = False
		'SSTab1.TabVisible(4) = False
		hopen = USBIO_OpenDevice(mIndex)
		If (hopen = INVALID_HANDLE_VALUE) Then
			mOpen = False
		Else
			mOpen = True
		End If
		'�����豸���֪ͨ
		'UPGRADE_WARNING: Add a delegate for AddressOf mUSBIO_NOTIFY_ROUTINE Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="E9E157F7-EF0C-4016-87B7-7D7FBBC6EE08"'
        If USBIO_SetDeviceNotify(mIndex, vbNullString, AddressOf mUSBIO_NOTIFY_ROUTINE) = False Then
            MsgBox("�����豸���֪ͨʧ��", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
        End If
        enablebtn((mOpen))
    End Sub
	
	Private Sub frmMain_FormClosed(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        USBIO_SetDeviceNotify(mIndex, vbNullString, Nothing)
		If (mOpen = True) Then
			USBIO_CloseDevice((mIndex))
			
		End If
	End Sub
	
	
	
	
	'UPGRADE_WARNING: Event Led.CheckStateChanged may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"'
	Private Sub Led_CheckStateChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Led.CheckStateChanged
		Dim Index As Short = Led.GetIndex(eventSender)
		Dim mBuf(0) As Byte
		Dim mLen As Integer
		If (mOpen = True) Then
			mLen = 1
			mBuf(0) = CByte((Led(0).CheckState * (2 ^ 7)) + (Led(1).CheckState * (2 ^ 6)) + (Led(2).CheckState * (2 ^ 5)) + (Led(3).CheckState * (2 ^ 4)) + (Led(4).CheckState * (2 ^ 3)) + (Led(5).CheckState * (2 ^ 2)) + (Led(6).CheckState * (2 ^ 1)) + (Led(7).CheckState * (2 ^ 0))) '��ϰ�ť��ֵ
			If (memadd0(0).Checked = True) Then '��ַ0
                If (USBIO_MemWriteAddr0(mIndex, mBuf, mLen) = False) Then
                    MsgBox("����LED״ֵ̬ʧ�ܣ�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
                End If
			ElseIf (memadd1(1).Checked = True) Then 
                If (USBIO_MemWriteAddr1(mIndex, mBuf, mLen) = False) Then
                    MsgBox("����LED״ֵ̬ʧ�ܣ�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
                End If
			End If
		Else
			MsgBox("�豸δ�򿪣�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
		End If
	End Sub
	
	
	Private Sub memRead0_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles memRead0.Click
		Dim mLen As Integer
		'UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
        Dim buffer(mMAX_BUFFER_LENGTH - 1) As Byte
		
		mLen = HexToBcd((memLen0.Text))
		
		If (mLen <= 0) Then
			MsgBox("�������ȡ����", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			Exit Sub
		End If
		
		Dim buff As String
		Dim i As Integer
		If (mOpen = True) Then
			On Error Resume Next
			'UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If (USBIO_MemReadAddr0(mIndex, buffer, mLen)) Then
				buff = ""
				For i = 0 To mLen - 1 Step 1
					System.Windows.Forms.Application.DoEvents()
                    buff = buff & Hex2bit(buffer(i)) & " "
				Next i
				memData0.Text = buff
			Else
				MsgBox("MEM�����ݿ�0ʧ�ܣ� ", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			End If
			memLen0.Text = Hex(mLen)
		Else
			MsgBox("�豸δ�򿪣�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
		End If
	End Sub
	
	Private Sub memRead1_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles memRead1.Click
		Dim mLen As Integer
		'UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
        Dim buffer(mMAX_BUFFER_LENGTH - 1) As Byte
		
		mLen = HexToBcd((memLen1.Text))
		If (mLen <= 0) Then
			MsgBox("����������ݳ���", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			Exit Sub
		End If
		
		Dim buff As String
		Dim i As Integer
		If (mOpen = True) Then
			'UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If (USBIO_MemReadAddr1(mIndex, buffer, mLen)) Then
				For i = 0 To mLen - 1
                    buff = buff & Hex2bit(buffer(i)) & " "
				Next i
				memData1.Text = buff
			Else
				MsgBox("MEM�����ݿ�1ʧ�ܣ� ", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			End If
			memLen1.Text = Hex(mLen)
		Else
			MsgBox("�豸δ�򿪣�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
		End If
	End Sub
	
	Private Sub memWrite0_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles memWrite0.Click
		Dim mLen As Integer
		'UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
        Dim buffer(mMAX_BUFFER_LENGTH - 1) As Byte
		
		mLen = HexToBcd((memLen0.Text))
		
		If (mLen <= 0 Or Len(memData0.Text) = 0) Then
			MsgBox("������Ҫд������,���ȣ�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			Exit Sub
		End If
		
		If (mLen > Len(memData0.Text) / 2) Then
			mLen = Len(memData0.Text) / 2
		End If
		
		Call mStrtoVal((memData0.Text), buffer, mLen) '�������ʮ�����Ƹ�ʽ�ַ�����ת����ֵ����
		If (mOpen = True) Then
			'UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If (USBIO_MemWriteAddr0(mIndex, buffer, mLen) = False) Then
				MsgBox("MEMд���ݿ�0ʧ�ܣ�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			End If
			memLen0.Text = Hex(mLen)
		Else
			MsgBox("�豸δ�򿪣�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
		End If
	End Sub
	
	Private Sub memWrite1_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles memWrite1.Click
		Dim mLen As Integer
		'UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
        Dim buffer(mMAX_BUFFER_LENGTH - 1) As Byte
		
		mLen = HexToBcd((memLen1.Text))
		
		If (mLen <= 0 Or Len(memData1.Text) = 0) Then
			MsgBox("������Ҫд�������,���ȣ�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			Exit Sub
		End If
		
		If (mLen > Len(memData1.Text) / 2) Then
			mLen = Len(memData1.Text) / 2
		End If
		
		Call mStrtoVal((memData1.Text), buffer, mLen) '�������ʮ�����Ƹ�ʽ�ַ�����ת����ֵ����
		If (mOpen = True) Then
			'UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If (USBIO_MemWriteAddr1(mIndex, buffer, mLen) = False) Then
				MsgBox("MEMд���ݿ�0ʧ�ܣ�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			End If
			memLen1.Text = Hex(mLen)
		Else
			MsgBox("�豸δ�򿪣�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
		End If
	End Sub
	
	Private Sub Option1_Click(ByRef Index As Short)
		
	End Sub
	
	Private Sub SSTab1_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles SSTab1.SelectedIndexChanged
		Static PreviousTab As Short = SSTab1.SelectedIndex()
		
		If (mOpen = True) And (SSTab1.SelectedIndex = 4) Then
			Call evtbtrefresh_Click(evtbtrefresh, New System.EventArgs())
			Call Led_CheckStateChanged(Led.Item(0), New System.EventArgs())
		End If
		
		PreviousTab = SSTab1.SelectedIndex()
	End Sub
	
	Private Sub StreamICRW_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles StreamICRW.Click
		Dim mWRLen As Integer
		Dim mRdLen As Integer
		'UPGRADE_WARNING: Arrays in structure iBuff may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
		'Dim iBuff As arrRBuffer
		Dim iBuff (mMAX_BUFFER_LENGTH - 1) As Byte
		'UPGRADE_WARNING: Arrays in structure buffer may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
        Dim buffer(mMAX_BUFFER_LENGTH - 1) As Byte
		
		mWRLen = HexToBcd((I2CWRLen.Text))
		mRdLen = HexToBcd((I2CRDLen.Text))
		
		'----------------------------------------
		If (I2CM(0).Checked = True) Then
			If (USBIO_SetStream(mIndex, &H80) = False) Then
				MsgBox("����I2Cʱ�� = 20KHzʧ�ܣ� ", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
				Exit Sub
			End If
		ElseIf (I2CM(1).Checked = True) Then 
			If (USBIO_SetStream(mIndex, &H81) = False) Then
				MsgBox("����I2Cʱ�� = 100KHzʧ�ܣ� ", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
				Exit Sub
			End If
		ElseIf (I2CM(2).Checked = True) Then 
			If (USBIO_SetStream(mIndex, &H82) = False) Then
				MsgBox("����I2Cʱ�� = 400KHzʧ�ܣ� ", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
				Exit Sub
			End If
		ElseIf (I2CM(3).Checked = True) Then 
			If (USBIO_SetStream(mIndex, &H83) = False) Then
				MsgBox("����I2Cʱ�� = 750KHzʧ�ܣ� ", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
				Exit Sub
			End If
		End If
		'----------------------------------------
		
		If (mWRLen > 0 And I2CWRBuf.Text = "") Then
			MsgBox("������Ҫд������,���ȣ�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			Exit Sub
		End If
		If ((mWRLen = 0) And (mRdLen = 0)) Then
			MsgBox("���������������ĳ��ȣ�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			Exit Sub
		End If
		If (mWRLen > Len(Trim(I2CWRBuf.Text)) \ 2) Then
			mWRLen = Len(Trim(I2CWRBuf.Text)) \ 2
		End If
		
		Call mStrtoVal((I2CWRBuf.Text), buffer, mWRLen) '�������ʮ�����Ƹ�ʽ�ַ�����ת����ֵ����
		
		Dim buff As String
		Dim i As Integer
		If (mOpen = True) Then
			'UPGRADE_WARNING: Couldn't resolve default property of object iBuff. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			'UPGRADE_WARNING: Couldn't resolve default property of object buffer. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If (USBIO_StreamI2C(mIndex, mWRLen, buffer, mRdLen, iBuff) = False) Then
				MsgBox("I2C��ģʽ��д����ʧ�ܣ�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			Else
				If (mRdLen > 0) Then '�����ݷ���
					For i = 0 To mRdLen - 1
						buff = buff & Hex2bit(iBuff(i)) & " "
					Next 
					I2CRDBuf.Text = buff
				End If
			End If
			I2CWRLen.Text = Hex(mWRLen)
			I2CRDLen.Text = Hex(mRdLen)
		Else
			MsgBox("�豸δ�򿪣�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
		End If
	End Sub
	
	Private Sub StreamSPIRW_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles StreamSPIRW.Click
		Dim mWRLen As Integer
		'Dim mRdLen As Long
		'UPGRADE_WARNING: Arrays in structure ioBuff may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
        Dim ioBuff(mMAX_BUFFER_LENGTH - 1) As Byte
		'Dim iBuff As arrRBuffer
		'Dim buffer As arrRBuffer
		
		mWRLen = HexToBcd((SPIWRLen.Text))
		'mRdLen = HexToBcd(I2CRDLen.Text)
		Dim mTheFirst As Boolean
		mTheFirst = True
		
		'If (mTheFirst) Then
		'  If (USBIO_SetStream(mIndex, &H81) = False) Then
		'    MsgBox "����SPIģʽʧ��!", vbExclamation, "USB2ISP DEMO"
		'  Else
		'    mTheFirst = False
		'Exit Sub
		'    End If
		'End If
		
		'----------------------------------------
		If (SPIMSB(0).Checked = True) Then
			If (USBIO_SetStream(mIndex, &H81) = False) Then
				MsgBox("����SPI��λ��ǰģʽʧ�ܣ� ", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
				Exit Sub
			End If
		ElseIf (SPILSB(1).Checked = True) Then 
			If (USBIO_SetStream(mIndex, &H1) = False) Then
				MsgBox("����SPI��λ��ǰģʽʧ�ܣ� ", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
				Exit Sub
			End If
		End If
		'----------------------------------------
		
		If (mWRLen > 0 And SPIWRBuf.Text = "") Then
			MsgBox("������Ҫ׼������������ֽ�����", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			Exit Sub
		End If
		'If ((mWRLen = 0) And (mRdLen = 0)) Then
		'  MsgBox "���������������ĳ��ȣ�", vbExclamation, "USB2ISP DEMO"
		'  Exit Sub
		'End If
		
		
		If (mWRLen > Len(Trim(SPIWRBuf.Text)) \ 2) Then
			mWRLen = Len(Trim(SPIWRBuf.Text)) \ 2
		End If
		
		Call mStrtoVal((SPIWRBuf.Text), ioBuff, mWRLen) '�������ʮ�����Ƹ�ʽ�ַ�����ת����ֵ����
		
		Dim buff As String
		Dim i As Integer
		If (mOpen = True) Then
			'UPGRADE_WARNING: Couldn't resolve default property of object ioBuff. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If (USBIO_StreamSPI4(mIndex, &H80, mWRLen, ioBuff) = False) Then
				MsgBox("SPI��ģʽ��д����ʧ�ܣ�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
			Else
				If (mWRLen > 0) Then '�����ݷ���
					For i = 0 To mWRLen - 1
                        buff = buff & Hex2bit(ioBuff(i)) & " "
					Next 
					SPIWRBuf.Text = buff
				End If
			End If
			SPIWRLen.Text = Hex(mWRLen)
			'I2CRDLen.Text = Hex(mRdLen)
		Else
			MsgBox("�豸δ�򿪣�", MsgBoxStyle.Exclamation, "USB2ISP DEMO")
		End If
	End Sub
	
	Private Sub USBIO_NOTIFY_ROUTINE_KeyUp(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles USBIO_NOTIFY_ROUTINE.KeyUp
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000 '�豸���֪ͨ��������
		Dim iEventStatus As Integer
		iEventStatus = KeyCode '����¼�
		If (iEventStatus = USBIO_DEVICE_ARRIVAL) Then ' �豸�����¼�,�Ѿ�����
			If (USBIO_OpenDevice(mIndex) = INVALID_HANDLE_VALUE) Then
				MsgBox("���豸ʧ��!", MsgBoxResult.OK, "USB2ISP DEMO")
				mOpen = False
			Else
				mOpen = True '�򿪳ɹ�
			End If
		ElseIf (iEventStatus = USBIO_DEVICE_REMOVE) Then  ' �豸�γ��¼�,�Ѿ��γ�
			USBIO_CloseDevice((mIndex))
			mOpen = False
		End If
		enablebtn((mOpen)) '�豸��,��ť����,�豸û��,��ť����
	End Sub
	
	Public Sub enablebtn(ByVal bEnable As Boolean) 'bEnable=true :�����尴ť���� ;=false:enable:�����尴ť����
		With Me
			
			.eppRead0.Enabled = bEnable
			.eppWrite0.Enabled = bEnable
			.eppRead1.Enabled = bEnable
			.eppWrite1.Enabled = bEnable
			
			.memRead0.Enabled = bEnable
			.memWrite0.Enabled = bEnable
			.memRead1.Enabled = bEnable
			.memWrite1.Enabled = bEnable
			
			.StreamICRW.Enabled = bEnable
			
			.StreamSPIRW.Enabled = bEnable
			
			
			.eepromRdDate.Enabled = bEnable
			.eepromWrDate.Enabled = bEnable
			
			.evtbtrefresh.Enabled = bEnable
			.Led(0).Enabled = bEnable
			.Led(1).Enabled = bEnable
			.Led(2).Enabled = bEnable
			.Led(3).Enabled = bEnable
			.Led(4).Enabled = bEnable
			.Led(5).Enabled = bEnable
			.Led(6).Enabled = bEnable
			.Led(7).Enabled = bEnable
			
			If (bEnable = True) Then '���������ʾ
				Me.Text = "USB2ISP **�豸�Ѳ���"
				
			Else
				Me.Text = "USB2ISP **�豸�Ѱγ�"
				
			End If
		End With
		
		If (bEnable = True) Then '����I/O�����ѳ�ʼ��,ˢ��LED,�����뿪��״̬
			Call Led_CheckStateChanged(Led.Item(0), New System.EventArgs())
			Call Led_CheckStateChanged(Led.Item(1), New System.EventArgs())
			Call Led_CheckStateChanged(Led.Item(2), New System.EventArgs())
			Call Led_CheckStateChanged(Led.Item(3), New System.EventArgs())
			Call Led_CheckStateChanged(Led.Item(4), New System.EventArgs())
			Call Led_CheckStateChanged(Led.Item(5), New System.EventArgs())
			Call Led_CheckStateChanged(Led.Item(6), New System.EventArgs())
			Call Led_CheckStateChanged(Led.Item(7), New System.EventArgs())
			Call evtbtrefresh_Click(evtbtrefresh, New System.EventArgs())
		End If
	End Sub
End Class